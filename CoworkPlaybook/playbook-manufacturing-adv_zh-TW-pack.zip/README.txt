Cowork 練習手冊 — 離線包
========================

1. 開啟 playbook-manufacturing-adv.html，內容（含截圖）已全部內嵌，離線可直接瀏覽。
2. 範例檔放在 samples_mfgx/ 底下。
3. 這個產業的素材要「課前先放進 OneDrive 與信箱」，練習時 Cowork 會自己去找。開始前請先讀目錄裡的〈課前環境準備指南.md〉。
