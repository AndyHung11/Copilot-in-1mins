Cowork Playbook - offline pack
==============================

1. Open playbook-manufacturing-adv.html - screenshots are embedded, so it works offline.
2. Sample files are in samples_mfgx/.
3. Put them into OneDrive and your mailbox first - Cowork finds them itself. Read the setup guide in the folder before you start.
