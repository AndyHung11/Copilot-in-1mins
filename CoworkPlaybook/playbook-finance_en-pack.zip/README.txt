Cowork Playbook - offline pack
==============================

1. Open playbook-finance.html - screenshots are embedded, so it works offline.
2. Sample files are in samples_fin/.
3. Upload them into the conversation when a step asks for them.
