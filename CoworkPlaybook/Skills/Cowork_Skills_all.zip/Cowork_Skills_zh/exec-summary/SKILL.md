---
name: exec-summary
description: |
  將冗長文件、郵件討論串或逐字稿濃縮成一頁式主管摘要。
  當使用者說「幫我做 TL;DR」、「給我主管摘要」、「幫主管摘要這份內容」、「一頁摘要」、「幫我濃縮」、「給忙碌讀者的精簡版」、"TL;DR this", "give me the exec summary", "summarize this for
  leadership", "one-page summary", "condense this", or "make this shorter for a busy
  reader" 時使用。
  不要用於摘要會議逐字稿 — 請使用 meeting-intel。
  不要用於整個收件匣摘要 — 請使用 inbox-triage 或 daily-briefing。
cowork:
  category: writing
  icon: DocumentText
---

## 概觀

接收一段冗長內容（文件、討論串、逐字稿、報告），產出面向忙碌高階讀者的一頁式主管摘要：內容是什麼、為何重要、需要哪些決策、建議的下一步。

## 使用時機

- 使用者分享長檔案或貼上冗長討論串，並想掌握重點
- 任何成品的 "TL;DR"
- 從較長來源準備給主管閱讀的簡報摘要

## 不適用時機

- 特定會議逐字稿 → 使用 `meeting-intel`
- 跨郵件/Teams 的多來源綜整 → 使用 `daily-briefing` 或 `weekly-wrap`
- 從零開始撰寫*新的*主管更新（沒有來源）→ 使用 `stakeholder-comms`

## 快速開始

```
使用者: 「幫我做 TL;DR」（附上檔案或指定文件）
1. 找出來源 — 上傳的檔案、Web URL 或貼上的文字
2. 閱讀來源（檔案使用 Read tool，SharePoint 使用 ReadFileContent，URL 使用 web_fetch）
3. 擷取：核心主張、關鍵證據、決策/請求、風險
4. 將一頁式摘要以 markdown 內嵌呈現
```

## 核心指示

### 步驟 1：定位來源
優先順序：
1. **訊息中的附件檔案** — 直接對路徑使用 `Read`
2. **訊息中貼上的文字** — 直接使用
3. **提及的 M365 檔案** — 使用 `SearchM365` 或 `ReadFileContent`
4. **URL** — 使用 `web_fetch`
5. 如果以上都沒有，請使用者分享內容

### 步驟 2：完整閱讀
- 超過 10 頁的 PDF，使用 `Read` 搭配 `pages` 參數，並逐段走完整份文件
- SharePoint 文件：若可用，使用 `ReadFileContent` 搭配 `download_url`
- 冗長 Teams 討論串：使用 `ListChatMessages` 並串接內容
- 閱讀整個來源 — 不要只根據第一頁摘要

### 步驟 3：擷取結構

整理到工作筆記：
- **核心主張** — 最重要的單一重點（一句話）
- **為何重要** — 業務影響與利害關係
- **關鍵證據** — 3–5 個支持事實/數字/引述
- **決策或請求** — 對讀者的要求是什麼
- **風險 / 未決議題** — 可能出錯之處
- **下一步** — 建議行動

### 步驟 4：輸出

以內嵌 markdown 呈現 — 主管摘要是用來閱讀，不是下載；除非使用者明確要求 Word 文件。使用此結構：

```markdown
# <Document title> — 主管摘要

**結論：** <one-sentence core claim>

## 為何重要
<2–3 sentence stakes/context>

## 重點
- <point 1 with number/fact>
- <point 2>
- <point 3>

## 決策 / 請求
- <what is being requested>

## 風險
- <key risk>

## 建議下一步
<one sentence>
```

目標：250 字以內。若來源有關鍵數字，盡可能引用來源行號或頁碼。

### 步驟 5：提供檔案轉換

顯示內嵌摘要後，詢問："Want this as a Word doc or PDF?" 只有在使用者同意時，才叫用 `docx` 或 `pdf` skills。

## 護欄

- 絕不編造數字、姓名或引述 — 每個事實都必須可追溯至來源
- 如果來源有缺口或矛盾，請在風險區段揭露，不要粉飾
- 維持一頁（≤250 words）— 這就是價值主張。如果內容無法壓縮到這個程度，請說明並詢問要優先保留什麼
- 對於敏感文件（財務、人資），除非使用者表明受眾為內部，否則姓名一律泛化
