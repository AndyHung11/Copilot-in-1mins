---
name: oof-prep
description: |
  為使用者準備休假：草擬 OOF 自動回覆、建立交接文件，並標記 PTO 期間需要婉拒或委派的會議。
  當使用者要求「幫我準備 PTO」、「我要休假」、「設定我的 OOF」、「我下週不在」、「休假交接」、「離開前交接」、"prep me for PTO", "going on vacation", "set up my OOF",
  "I'm out next week", "out of office prep", 或 "handoff before I leave" 時使用。
  請勿用於一天病假代班 — 直接使用 SetAutoReply 設定 OOF 即可。
  請勿用於永久職務轉換 — 請改用 stakeholder-comms。
cowork:
  category: productivity
  icon: Calendar
---

## 概觀

三段式 PTO 準備：(1) 為內部與外部對象草擬 OOF 自動回覆，
(2) 產生交接文件，摘要進行中的工作與關鍵聯絡人，
(3) 掃描 PTO 期間的會議，標記哪些應婉拒、委派或保留。

## 使用時機

- 使用者表示即將 PTO / 休假 / 請假
- 離開辦公室 2+ 個工作天
- 需要交接給代理人員

## 不適用時機

- 單日病假 → 直接呼叫 `SetAutoReply`
- 永久離職 / 職務變更 → 使用 `stakeholder-comms`
- OOF 已啟用 → 使用 `GetAutoReplySettings` / `DisableAutoReply`

## 快速開始

```
使用者：「幫我準備 5 月 30 日到 6 月 6 日的 PTO」
1. 詢問代理聯絡人與任何關鍵背景（一次彙整提問）
2. 草擬 OOF（內部 + 外部）— 顯示給使用者審閱
3. 對 PTO 期間使用 ListCalendarView → 標記會議（婉拒 / 委派 / 保留）
4. 建立交接文件：進行中專案、關鍵聯絡人、資料位置
5. 提議：啟用 OOF、寄送婉拒說明、將交接內容張貼到團隊頻道
```

## 核心指示

### 步驟 1：釐清最少必要背景

提出 ONE 個彙整式 `AskUserQuestion`，涵蓋：
- 代理聯絡人（緊急事項應轉給誰）
- 使用者想完全不回覆，或願意查看郵件
- 要自動婉拒會議，還是只先標記

不要來回多次提問 — 在一張卡片中一次收集完整資訊。

### 步驟 2：草擬 OOF 訊息

使用 `SetAutoReply` 搭配 `status="scheduled"`、PTO 開始/結束時間，以及：
- **內部訊息：** 語氣溫暖，提及代理聯絡人的姓名與返回日期
- **外部訊息：** 簡短、專業、包含返回日期與 "for urgent matters contact <X>"

在呼叫 `SetAutoReply` 前，先向使用者顯示草稿。沒有確認前，絕不啟用 OOF。

### 步驟 3：掃描行事曆

`ListCalendarView(start=<PTO start>, end=<PTO end>)` — 對每個活動分類：
- **婉拒** — 例行週期同步、選擇性會議、使用者可缺席的任何會議
- **委派** — 代理聯絡人可以出席的會議
- **保留在行事曆上（但發出訊號）** — 使用者主辦的會議；轉寄給代理人
- **重要 — 需要行動** — 使用者必須在 PTO 前/後處理的會議

以 `render-ui` 表格呈現。請勿自動婉拒 — 先向使用者顯示建議並取得核准。

### 步驟 4：交接文件

建立包含下列區段的 markdown 文件：

```markdown
# 交接 — <name> OOF <start> 至 <end>

## 代理聯絡人
<Name, email, focus areas>

## 進行中專案
- <Project> — 目前狀態、下一個檢查點、關鍵聯絡人

## 需要留意的重要郵件串
- <Email subject> — 如果 X 發生時該怎麼做

## 可以忽略的事項
- <Bucket> — 我不在期間不會有影響

## 資料位置
- <Files, channels, dashboards>
```

資料來源：近期寄件、過去一週已接受的會議、活躍 Teams 聊天。
預設以 markdown 內嵌儲存；可提議另存成檔案或張貼到團隊頻道。

### 步驟 5：確認後執行

只有在使用者審閱三項產出後：
- 呼叫 `SetAutoReply` 排程 OOF
- 針對婉拒項目：對每個核准的會議使用 `DeclineEvent`，並附上簡短留言
- 針對委派轉寄：使用 `ForwardEvent`

## 護欄

- 未顯示草稿並取得確認前，絕不啟用 OOF
- 絕不自動婉拒會議 — 一律先顯示清單供使用者核准
- 外部 OOF 不得提及代理聯絡人，除非使用者確認（隱私）
- 如果使用者在 PTO 期間主辦週期性系列會議，建議轉移主辦權，預設不要取消
