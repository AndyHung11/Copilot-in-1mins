---
name: newsletter-builder
description: |
  為內部或外部受眾建立結構化的電子報草稿。
  當使用者說「撰寫電子報」、「團隊更新郵件」、「每月摘要」、「公司電子報」、「內部溝通」、
  "write newsletter", "team update email", "monthly digest",
  "company newsletter", or "internal comms" 時使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: content-studio
---

# 電子報草稿產生器
以合適的結構與具吸引力的內容產生引人入勝的電子報。

## 此技能的功能

建立電子報草稿，包含：
- 吸引目光的主旨
- 清楚的段落結構
- 易於瀏覽的格式
- 行動呼籲
- 互動元素

## 使用時機

- 每週／每月團隊更新
- 全公司溝通
- 客戶電子報
- 產品更新
- 社群摘要

## 必要資訊

1. 電子報類型（內部／外部）
2. 受眾
3. 頻率（每週、每月等）
4. 要納入的重點主題／更新
5. 語氣（正式、親切、充滿活力）
6. 任何固定單元

## 套用的電子報最佳做法

- **主旨:** 價值清楚，少於 50 chars
- **預覽文字:** 補充主旨
- **易於瀏覽:** 標題、項目符號、短段落
- **一個主要 CTA:** 不讓讀者負擔過重
- **行動裝置優先:** 多數人會在手機上閱讀

## 輸出格式

# 電子報草稿: {Edition/Date}

## 主旨選項
1. {Option 1 - benefit-focused}
2. {Option 2 - curiosity-driven}
3. {Option 3 - news-focused}

**預覽文字:** {The text that appears after subject in inbox}

---

## 電子報內容

### 標頭
{Newsletter Name} | {Date/Edition}

---

### 👋 您好 {Name/Team},

{Brief, warm opening. 1-2 sentences that set the tone and preview what's inside.}

---

### 📣 重大消息／焦點
**{Headline}**

{The most important update or story. 2-3 paragraphs max. Include why it matters to the reader.}

{CTA if applicable: Learn more → }

---

### 📊 更新與亮點

**{Update 1 Title}**
{Brief description. 2-3 sentences.}

**{Update 2 Title}**
{Brief description. 2-3 sentences.}

**{Update 3 Title}**
{Brief description. 2-3 sentences.}

---

### 🎉 成果與表揚

- {Shoutout or celebration 1}
- {Shoutout or celebration 2}
- {Milestone or achievement}

---

### 📅 即將到來

| 日期 | 活動 |
|------|-------|
| {date} | {event} |
| {date} | {event} |
| {date} | {event} |

---

### 💡 快速提示／你知道嗎？

> {Useful tip, fact, or insight relevant to your audience}

---

### 📚 資源／連結

- [{Resource 1}]({link})
- [{Resource 2}]({link})
- [{Resource 3}]({link})

---

### 💬 意見交流區

{Question to engage readers or request for input}

[回覆分享你的想法 →]

---

### 結語

{Brief sign-off. Thank them, preview next edition, or inspiring close.}

敬上,
{Name/Team}

---

## 頁尾
{Unsubscribe link if external} | {Contact info} | {Social links}

---

## 要追蹤的指標
- 開信率（目標: >40% internal, >20% external）
- 點擊率（目標: >10%）
- 回覆率
- 取消訂閱

## 寄送前檢查清單
- [ ] 已測試主旨
- [ ] 所有連結可正常使用
- [ ] 圖片可載入
- [ ] 已檢查行動裝置預覽
- [ ] 已寄送測試信給自己
- [ ] 已排程在最佳時間寄送