---
name: teams-digest
description: |
  彙整你在 Teams 上可能錯過的頻道貼文與聊天訊息。
  當使用者說「Teams 我漏了什麼」、「Teams 摘要」、「頻道更新」、「幫我補 Teams 進度」、
  「未讀 Teams 訊息」、「Teams 摘要報告」、"what did I miss in Teams", "Teams summary", "channel updates",
  "catch me up on Teams", "unread Teams messages", or "Teams digest" 時使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: teams-hub
  m365-services: [Teams, Graph]
---

# Teams 未讀摘要
取得跨頻道與聊天的 Teams 活動摘要。

## M365 整合

- **Microsoft Teams:** 頻道貼文、聊天訊息、回應
- **Microsoft Graph:** 活動摘要、提及、回覆

## 此技能的功能

彙整：
- 依重要性排序的未讀頻道貼文
- 需要注意的直接訊息
- 對你的 @提及與回覆
- 重要決策與公告
- 對話中的待辦事項

## 使用時機

- 從休假或請假返回時
- 早晨補進度例行作業
- 連續開會之後
- 每日結束前回顧
- 團隊會議前

## 工作流程

1. **掃描活動**
   - 檢查你所屬的所有頻道
   - 檢閱直接訊息與群組聊天
   - 找出 @提及與回覆

2. **排定優先順序**
   - 優先處理緊急／重要訊息
   - 找出需要回覆的訊息
   - 最後處理僅供參考事項

3. **彙整摘要**
   - 擷取重點
   - 識別待辦事項
   - 記錄已做成的決策

## 輸出格式

# Teams 摘要

**期間:** {timeframe, e.g., "Last 24 hours" or "Since Monday"}
**上次檢查:** {timestamp}

---

## 🔴 需要你注意

### @提及
| 時間 | 頻道／聊天 | 來自 | 訊息 |
|------|--------------|------|---------|
| {time} | {location} | {person} | {summary + link} |

### 等待回覆的直接訊息
| 來自 | 預覽 | 時間 |
|------|---------|------|
| {name} | {message preview} | {time} |

### 你貼文的回覆
| 對話串 | 最新回覆 | 來自 |
|--------|--------------|------|
| {topic} | {summary} | {name} |

---

## 📢 各頻道重要更新

### #{channel-name-1}
**活動量:** {High/Medium/Low} ({n} messages)

**重點貼文:**
- **{Author}:** {Summary of important post}
  - 回應: {👍 n, etc.}
  - {Link to message}

- **{Author}:** {Summary of another post}
  - {Link}

**已做成的決策:**
- {Decision 1}
- {Decision 2}

---

### #{channel-name-2}
**活動量:** {level}

**重點貼文:**
- {summaries}

---

## 💬 群組聊天

### {Chat name or participants}
**訊息數:** {n} new
**摘要:** {What was discussed}
**待辦事項:** {Any tasks mentioned}

---

## 📋 找到的待辦事項

| 項目 | 來源 | 指派給 | 截止日期 |
|------|--------|-------------|----------|
| {task} | #{channel} | {you/person} | {if mentioned} |
| {task} | {chat} | {person} | {date} |

---

## 📊 活動摘要

| 頻道 | 新貼文 | 你的參與 |
|---------|-----------|-------------------|
| #{channel1} | {n} | {replied/reacted/none} |
| #{channel2} | {n} | {status} |
| #{channel3} | {n} | {status} |

---

## 🎯 建議行動

1. **回覆 {person}** 在 #{channel} 關於 {topic}
2. **確認收到** {important announcement}
3. **追蹤** {thread}

---

## ℹ️ 僅供參考（低優先順序）

{Brief list of lower-priority updates that don't require action}

- #{channel}: {brief summary}
- #{channel}: {brief summary}