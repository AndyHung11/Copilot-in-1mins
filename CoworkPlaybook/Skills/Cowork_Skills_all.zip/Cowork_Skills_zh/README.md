# Copilot Cowork 技能包（繁體中文）

這裡是 19 個 Copilot Cowork 自訂技能的繁體中文版 SKILL.md。

## 怎麼用
1. 每個資料夾就是一個技能，裡面的 `SKILL.md` 就是技能本體。
2. 把整個資料夾放進 Cowork 的技能目錄，或在 Cowork 中直接上傳該 `SKILL.md`。
3. 資料夾名稱必須與檔案內 `name:` 欄位一致，否則技能會載入失敗。

## 關於中文版
- `name:` 一律維持英文 kebab-case —— 那是技能的識別碼，Cowork 不接受中文或大寫。
- `description:` 同時保留原文的英文觸發詞並補上中文觸發詞，所以中英文都叫得動。
- 工具名稱、參數、欄位名、檔案路徑一律維持英文，因為那些是實際要呼叫的東西。

## 技能清單
- `30-60-90-plan`
- `contract-review`
- `cowork-cost-estimator`
- `cowork-library-search`
- `data-storyteller`
- `exec-summary`
- `file-organizer`
- `frontend-design`
- `hr-engagement-strategy`
- `inbox-triage`
- `meeting-followup`
- `newsletter-builder`
- `onboarding-checklist`
- `oof-prep`
- `permissions-audit`
- `sharepoint-finder`
- `snow-incident-rca`
- `teams-digest`
- `weekly-wrap`
