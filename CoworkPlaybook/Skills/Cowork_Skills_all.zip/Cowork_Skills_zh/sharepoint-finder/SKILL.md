---
name: sharepoint-finder
description: |
  搜尋 SharePoint 與 OneDrive 以尋找文件、檔案和資訊。
  當使用者詢問「找文件」、「搜尋 SharePoint」、「檔案在哪裡」、「幫我找」、「找簡報」、「找到試算表」、"find document", "search SharePoint", "where is the file",
  "look for", "find the presentation", or "locate the spreadsheet" 時使用。
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
  plugin: document-intelligence
  m365-services: [SharePoint, OneDrive, Graph, Search]
---

# SharePoint 檔案搜尋
跨 SharePoint 網站與 OneDrive 搜尋，以定位檔案和資訊。

## M365 整合

- **SharePoint:** 網站內容、文件庫、清單
- **OneDrive:** 個人檔案與共用項目
- **Microsoft Search:** 跨 M365 的整合搜尋
- **Graph:** 檔案中繼資料、共用資訊、近期活動

## 此 Skill 的功能

協助尋找：
- 依名稱、內容或主題尋找文件
- 依類型尋找檔案（簡報、試算表等）
- 最近或常用的檔案
- 與特定人員共用或由其共用的檔案
- 特定網站或文件庫內的內容

## 使用時機

- 想不起檔案儲存在哪裡
- 尋找某個主題的文件
- 尋找某人共用的檔案
- 定位文件的最新版本
- 搜尋範本或範例

## 搜尋策略

1. **依名稱：** 完整或部分檔名
2. **依內容：** 文件內的字詞或片語
3. **依中繼資料：** 作者、日期、檔案類型
4. **依位置：** 特定網站或文件庫
5. **依活動：** 最近修改或共用

## 輸出格式

# 搜尋結果

## 查詢
**尋找：** {user's search intent}
**搜尋字詞：** {actual search query used}
**範圍：** {All M365 / SharePoint / OneDrive / Specific site}

---

## 🎯 最佳符合項目

### 1. {Document Title}
| 屬性 | 值 |
|----------|-------|
| **類型** | {Word, Excel, PowerPoint, PDF, etc.} |
| **位置** | {Site > Library > Folder} |
| **修改時間** | {date}，由 {person} 修改 |
| **大小** | {size} |

**預覽：** {First few lines of content or description}

**動作：** [開啟]({link}) | [共用]({link}) | [複製連結]({link})

---

### 2. {Document Title}
{Same structure}

---

### 3. {Document Title}
{Same structure}

---

## 📁 相關位置

這些位置可能有你要找的內容：

| 網站/文件庫 | 描述 | 連結 |
|--------------|-------------|------|
| {Site name} | {what it contains} | [開啟]({link}) |
| {Library name} | {description} | [開啟]({link}) |

---

## 🕐 近期活動

你或你的團隊最近處理過且符合此搜尋的檔案：

| 檔案 | 動作 | 時間 | 人員 |
|------|--------|------|-------|
| {file} | {Modified/Viewed/Shared} | {time} | {person} |

---

## 🔍 搜尋提示

如果這些結果不是你需要的，請嘗試：

1. **更具體：** 加上 "{suggested term}"
2. **依類型：** "filetype:pptx {topic}"
3. **依作者：** "author:{name}"
4. **依日期：** "modified:last week"
5. **依位置：** 在 {suggested site} 內搜尋

---

## 沒有結果？

如果檔案沒有出現在搜尋中：
- 它可能在私人 OneDrive（未與你共用）
- 它可能是新建立的（搜尋索引可能延遲）
- 檢查你是否有該網站/文件庫的存取權
- 嘗試其他拼字或相關詞

---

## 快速動作

- 🆕 **建立新文件** 於 {suggested location}
- 📤 **要求存取權** 至 {restricted location}
- 👤 **詢問 {person}** 可能誰有這個檔案
