---
name: inbox-triage
description: |
  將未讀郵件分類到 Reply / FYI / Delegate / Ignore 四個桶，並附上理由。
  當使用者說「幫我分流收件匣」、「整理未讀郵件」、「哪些信要先回」、「清理我的收件匣」、「排定郵件優先順序」、「逐封看未讀」、"triage my inbox", "sort my unread mail", "what should I reply to",
  "clean up my inbox", "prioritize my emails", or "go through my unread" 時使用。
  不要用於搜尋特定郵件 — 直接使用 SearchM365。
  不要用於大量草擬回覆 — 此 skill 只做分類；由使用者選擇要處理哪些
  郵件。
cowork:
  category: productivity
  icon: TaskListLtr
---

## 概觀

讀取使用者收件匣中的未讀郵件，將每封訊息分類到四個行動桶之一，並以優先排序表格呈現。使用者決定要處理哪些；此 skill 不會自動回覆、自動刪除或自動歸檔。

## 分類桶

| 桶 | 意義 |
|--------|---------|
| **Reply** | 直接要求使用者回應，等待其回覆 |
| **FYI** | 資訊性內容，無需行動但值得閱讀 |
| **Delegate** | 較適合由其他人處理（在輸出中註明姓名） |
| **Ignore** | 電子報、自動通知、低訊號 — 可安全封存 |

## 使用時機

- 早上清理收件匣
- 休假後或會議密集的一天之後
- 使用者被未讀數量壓得喘不過氣

## 不適用時機

- 尋找某一封特定郵件 → 直接使用 `SearchM365`
- 跨郵件 + 行事曆 + Teams 的每日簡報 → 使用 `daily-briefing`
- 設定篩選器/規則 → 直接使用 Outlook 規則工具

## 快速開始

```
使用者: 「幫我分流收件匣」
1. ListMessages(unread_only=true, top=50)
2. 逐封依寄件者角色、收件者模式、內文意圖分類
3. 依桶分組呈現表格，Reply 優先
4. 提供下一步：開啟第一個 Reply 項目、草擬回覆、封存 Ignore
```

## 核心指示

### 步驟 1：擷取未讀郵件
- `ListMessages(unread_only=true, top=50)`
- 如果有 `next_link` 且使用者還有更多郵件，最多分頁到 100 封 — 超過則詢問是否要全部處理

### 步驟 2：分類每封訊息

依序套用這些啟發式規則：

1. **Reply**，如果：
   - 使用者在 `to` 中（不只是 `cc`）
   - 內文包含直接問題、請求，或指向使用者的 `?`
   - 寄件者是使用者的主管、隔級主管或重要利害關係人

2. **Delegate**，如果：
   - 寄件者要求的事項通常由已知團隊成員處理
   - 如果使用者有直屬部屬，使用 `GetDirectReportsDetails` — 依姓名建議
   - 否則留空 — 不要捏造姓名

3. **FYI**，如果：
   - 使用者只在 `cc` 中，或這是轉寄給使用者了解的討論串
   - 狀態更新、公告、唯讀背景資訊

4. **Ignore**，如果：
   - 寄件者是已知自動寄送地址（no-reply、notifications、newsletters）
   - 行銷或外部大量發送
   - 使用者已回覆過的行事曆邀請

### 步驟 3：呈現輸出

使用 `render-ui` 顯示含表格的卡片：

| 桶 | 寄件者 | 主旨 | 原因 |
|--------|------|---------|-----|
| Reply | Piotr Dragan | Q2 review prep | 直接請求，主管 |
| Delegate | … | … | 例行供應商追蹤 |
| FYI | … | … | 僅被副本 |
| Ignore | … | … | 行銷 |

排序為 Reply 優先，其次 Delegate、FYI、Ignore。包含像 `[msg_3]` 這樣的訊息別名，讓使用者可點入查看。

### 步驟 4：下一步

顯示表格後，提供：
- "Want me to draft replies for the Reply bucket?"
- "Want me to archive the Ignore bucket?"（每封郵件都需要明確確認）

## 護欄

- 絕不自動封存、自動回覆或自動刪除 — 只做分類
- 絕不捏造轉派對象姓名 — 只建議透過人員工具解析到的直屬部屬/團隊成員
- 若寄件者是使用者的主管或隔級主管，一律分類為 Reply 或 FYI（絕不 Ignore）
- 若不確定該歸到哪兩個桶，選擇較謹慎者（Reply 優先於 FYI，FYI 優先於 Ignore）
