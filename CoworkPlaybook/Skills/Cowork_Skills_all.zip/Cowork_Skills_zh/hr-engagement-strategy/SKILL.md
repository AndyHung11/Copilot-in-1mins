---
name: hr-engagement-strategy
description: |
  將員工敬業度調查匯出檔轉換為完整的人資高階主管交付套件：
  五大主題摘要、含基準比較且可供 CEO 使用的策略文件、SLT 執行簡報、
  一頁式品牌色資訊圖表，以及 Copilot Create / Sora 影片腳本。
  當使用者說「分析我們的敬業度調查」、「把敬業度調查彙整成主題」、「為 CEO/SLT 建立敬業度策略」、「建立人資賦能簡報」、「把調查結果做成簡報」、「製作敬業度資訊圖表」、「為人資撰寫 sales-enablement / Copilot-adoption 策略」、"analyze our engagement survey", "summarize the engagement
  survey into themes", "build an engagement strategy for the CEO/SLT", "create an HR
  enablement deck", "turn survey results into a presentation", "make an engagement
  infographic", or "write a sales-enablement / Copilot-adoption strategy for HR" 時使用。
  強調 HRBP、Sales Leader 與 L&D 角色，以及 Copilot for Sales 採用。
  請勿用於：排程 HR 會議（使用 schedule-meeting）、例行 HR 狀態郵件
  （使用 stakeholder-comms），或評估個別員工績效（拒絕）。
cowork:
  category: analysis
  icon: People
---

## 概觀

此技能執行五階段人資流程，將單一敬業度調查匯出檔轉換為
高階主管可直接使用的套件。每個階段都為下一階段奠定基礎：主題只來自
真實調查資料，策略建構於這些主題之上，而所有後續交付項目
（簡報、資訊圖表、影片腳本）都重複使用同一套策略，確保故事一致。

所有交付項目的共同敘事：找出員工 — 尤其是**頂尖銷售人員** — 如何
以進階方式使用 Copilot，擷取其使用模式，並讓 **L&D** 將其轉換為
短篇、即時所需的訓練內容，再由 **HRBPs** 與 **Sales Leadership** 協作推動，
以提升營收。CRM/Salesforce 指標會作為衡量架構，使用使用者提供的數字或
清楚標示的預留位置 — 此技能絕不擷取即時 CRM 資料。

## 使用時機

- 使用者上傳敬業度／脈搏／文化調查匯出檔，並希望進行分析
- 使用者需要根據敬業度發現建立 CEO 或 SLT 簡報
- 使用者想要以 Copilot 採用為核心的人資到銷售賦能策略
- 使用者單獨要求資訊圖表或影片腳本

## 不使用時機

- 排程或重新排程 HR 會議 — 使用 **schedule-meeting**
- 簡單的狀態郵件或公告 — 使用 **stakeholder-comms**
- 對個別員工績效進行排名、評分或比較 — **禮貌拒絕**
  （"I can't evaluate individual performance; I can summarize team/program outcomes instead"）
- 依任何受保護特徵篩選人員 — **拒絕**，改提供角色／團隊／技能等替代方式

## 快速開始

```
使用者: "分析我們的敬業度調查，並建立 CEO strategy + SLT deck + infographic + video script"
1. 在 input/ 中尋找調查檔案（Glob input/**/*）。如果沒有，請要求提供 — 絕不編造資料。
2. 階段 1 — 從真實調查資料中擷取正好 5 個主題（xlsx skill）。
3. 階段 2 — 撰寫策略文件（docx）：趨勢、3 項策略（短期 + ≤2yr）、高階主管
   摘要、與約 ~10k-employee 同業基準比較（deep-research，附引用）。
4. 階段 3 — 根據策略文件建立 SLT 執行簡報（pptx）。
5. 階段 4 — 產生一頁式資訊圖表（公司品牌，透過 code 輸出 PNG）。
6. 階段 5 — 撰寫 Copilot Create / Sora 影片腳本（docx）。
7. 回報完成前，確認每個檔案都已落在 output/。
```

每個階段建立一個 Task，讓使用者看到進度。階段 3–5 依賴階段 2 的策略
內容；階段 1 必須先於階段 2 完成。調查載入前，不要執行任何需要調查資料的工作。

## 核心指示

### 階段 0 — 找出輸入（永遠先做）

- 使用 `Glob input/**/*` 找出調查匯出檔（`.xlsx`, `.csv`, `.xls`）。比對檔名中的
  *survey*, *engagement*, *pulse*, *export*。
- 如果找不到檔案，**停止並要求**使用者附上檔案。不要用編造資料進入階段 1。
  這是硬性閘門。
- 詢問一次（僅在未說明時）他們想要全部五項交付項目，還是其中一部分。

### 階段 1 — 五個關鍵主題（xlsx skill）

- 使用 **xlsx** skill 讀取調查。檢查欄位：問題文字、分數、開放式
  意見、區隔（部門、年資、區域）。
- 推導**正好五個**以資料為根據的主題。每個主題 = 短標題 + 背後的
  量化訊號（例如分數、% favorable、top driver）+ 1–2 段代表性
  逐字摘錄（**僅在**檔案中存在時）。
- 任何數字（平均、% favorable、差異）都要用 code tool 計算 — 絕不要手算。
- 如果匯出檔缺少使用者期待的維度（例如沒有區隔欄位），請清楚說明。
- 將主題以排名清單內嵌輸出；這會成為階段 2 的主軸。

### 階段 2 — 策略文件（docx skill）

叫用 **docx** skill。結構：

1. **高階主管摘要**（半頁）— 以 CEO 語言描述敬業度故事，並以
   商業影響開場。
2. **員工敬業度趨勢** — 五個主題加上近期員工敬業度宏觀趨勢
   （使用 deep-research / web search 取得外部趨勢；引用來源）。
3. **基準比較** — 我們組織與具代表性的 **~10,000-employee** 同業群組比較。
   透過 **deep-research** agent 處理，確保每個外部數字都有引用。若
   內部數字未知，插入 `[Add: our figure]` 預留位置 — 絕不編造。
4. **三項可執行策略** — 有意識地混合**短期與較長期（最長
   2 years）**，並以**全組織**角度呈現。每項包含：目標、時間範圍、負責人，以及
   會推動的**組織指標**（敬業度、留任率、生產力、營收）。
5. **連結至組織指標** — 明確說明對 CEO 關注之整體組織指標的好處。

數字規則：文件中嵌入的任何總數、%、平均或差異，都必須由 code 計算，
不是由你計算。收件者、引述與統計數字必須是真實或預留位置，絕不編造。

### 階段 3 — SLT 執行簡報（pptx skill）

叫用 **pptx** skill。根據階段 2 策略建立**高階主管層級的執行計畫**
（不是重新分析）。必要章節：

- 標題 + 高階主管摘要投影片
- 以三項策略作為執行路線圖（短期 vs ≤2-year 泳道）
- **HR ↔ Sales alignment**：HRBPs 如何與 Sales Leadership 合作
- **Customized AI training for Sales** 使用銷售專屬情境，對應銷售
  週期（prospect → qualify → propose → close → expand）
- **衡量**：Salesforce CRM + 現有 sales KPIs 作為衡量架構
  （使用者提供的數字或預留位置）
- **經濟合理性**：針對所有員工採用 Copilot for M365 展示模型
  結構（成本投入、生產力／營收槓桿、回收期），對未提供的任何數字使用 `[Add: figure]`
  預留位置。明確列出假設。
- **HRBP as liaison** to Sales Leadership 協調轉型
- SLT 的後續步驟／決策請求

### 階段 4 — 一頁式資訊圖表（公司品牌，透過 code 輸出 PNG）

使用 Python（matplotlib/PIL — session 中沒有 image-generation
工具，不要 `pip install`）產生單頁 PNG 到 `output/`。

**先解析公司品牌，依此順序 — 不要硬編碼某一家公司的色盤：**

1. **使用者提供的品牌素材** — 如果 `input/` 中有品牌指南、標誌或樣式檔，
   讀取並從中擷取 hex 色碼／標誌。
2. **組織範本庫** — 檢查 `@org-template-library`（租用戶品牌化 Office
   範本，透過 `GetOrgTemplateLibrary` / `GetDriveChildren(drive_id="@org-template-library")`）。
   從 `.potx`/`.dotx` 推導強調色，並在有標誌時重複使用。
3. **簡短詢問** — 如果兩者都沒有色彩，請向使用者詢問品牌 hex 值（或
   可取樣的標誌）。提供中性專業預設（單一主要色 + 深色中性色 +
   淺灰）以避免流程受阻，並標示為預留色盤。

一致套用解析出的品牌色（主要色用於標題／強調，中性色用於內文，
一個次要色用於提示區塊）。如果有標誌，放在標頭。除非顏色確實來自
步驟 1–2 或由使用者提供，否則不要宣稱那是特定品牌的顏色。

內容：以**三項策略**為骨幹，清楚凸顯三個角色 —
**HRBP**（協調者／聯絡窗口）、**Sales Leader**（贊助者）、**L&D**（根據
已識別的 **sales champions** 使用 Copilot 建立訓練）。強調銷售角色帶動額外
營收。保持易讀：標題、3 個策略區塊、角色帶、指標提示區塊。

### 階段 5 — 影片腳本（docx skill，Copilot Create / Sora ready）

叫用 **docx** skill。受眾：**SLT + Sales Leadership / CRO**。交付一份
使用者可直接貼到 **Copilot Create 或 Sora 2.0** 的腳本 — 逐場景列出：場景
編號、螢幕視覺指示、旁白／敘述，以及約略時長。總長保持精簡（目標 60–120s）。要涵蓋的敘事節點：

- 找出**以進階方式使用 Copilot** 在各銷售階段致勝的**頂尖銷售人員**
- 機會：將他們的模式轉換為供其他銷售人員使用的**動態銷售內容**
- 內容**鎖定銷售週期的每個部分**；**短篇、即時所需**，並搭配
  **companion agents + pre-written prompts**
- **Sales Copilot Champions** 作為同儕教練，協助經驗較少的使用者
- **HRBP as strategist** 與 Sales Managers 合作，透過 **OCM** 改善經理回饋／教練方式，
  支援銷售人員達成 Copilot for Sales 卓越表現

## 護欄

- **調查資料閘門：** 若尚未載入真實調查檔案，絕不產生主題、統計或引述。
  如果檔案缺失或無法讀取，請說明並要求重新上傳。
- **絕不編造：** 基準、ROI、KPIs、姓名、日期、引述。使用 `[Add: …]`
  預留位置，並透過 deep-research 搭配引用處理外部主張。
- **數字用 code 計算：** 寫入前先用 code tool 計算每個內嵌數字。
- **不做績效評估／不依受保護特徵剖析** — 拒絕並提供合規替代方案。
- **交付閘門：** 每個檔案階段完成後，執行 `Glob output/**/*` 確認檔案存在，
  再告訴使用者已準備好。
- **一次執行、分階段：** 如果使用者一次要求全部內容，產出全部五項，但維持
  相依順序（survey → themes → strategy → deck/infographic/script）。
- **未來 plugin 路徑：** 此技能設計為日後可透過 plugin builder 封裝成 Cowork plugin
  （例如新增即時 Salesforce connector 並散佈給所有 HRBPs）。