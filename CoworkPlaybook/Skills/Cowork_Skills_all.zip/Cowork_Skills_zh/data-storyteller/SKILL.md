---
name: data-storyteller
description: |
  將資料與試算表轉換為敘事式洞察與建議。
  當使用者要求「分析這些資料」、「這份試算表顯示什麼」、「這份 Excel 的洞察」、「解釋這些數字」、「資料摘要」、"analyze this data", "what does this spreadsheet show",
  "insights from this Excel", "explain these numbers", 或 "data summary" 時使用。
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
---

# 數據說故事
將原始資料轉換成具說服力的敘事與可行洞察。

## 此技能的用途

分析資料並提供：
- 白話中文摘要
- 關鍵趨勢與模式
- 異常與離群值
- 比較分析
- 可執行建議
- 建議視覺化

## 使用時機

- 解讀試算表資料
- 為簡報準備資料
- 從報表中找出洞察
- 向利害關係人說明指標
- 每月/每季資料檢討

## 工作流程

1. **理解資料**
   - 每個欄位代表什麼？
   - 涵蓋哪個時間區間？
   - 商業背景是什麼？

2. **識別模式**
   - 趨勢（上升、下降、持平）
   - 季節性或週期
   - 變數之間的相關性

3. **找出故事**
   - 標題是什麼？
   - 令人意外的是什麼？
   - 令人擔憂的是什麼？
   - 機會在哪裡？

4. **轉為可行動**
   - 所以代表什麼？
   - 接下來該做什麼？
   - 這能支援哪些決策？

## 輸出格式

# 資料分析：{Dataset Name}

## 核心結論

**{One sentence that captures the most important finding}**

---

## 執行摘要

{2-3 paragraph narrative summary written for a non-technical audience. Focus on what the data means, not just what it shows.}

---

## 關鍵指標一覽

| 指標 | 目前 | 前期 | 變化 | 趨勢 |
|--------|---------|----------|--------|-------|
| {metric 1} | {value} | {value} | {+/-}% | {↑↓→} |
| {metric 2} | {value} | {value} | {+/-}% | {↑↓→} |
| {metric 3} | {value} | {value} | {+/-}% | {↑↓→} |

---

## 資料顯示了什麼

### 趨勢 1：{Title}
{Description of the trend with specific numbers}

**為什麼重要：** {Business implication}

### 趨勢 2：{Title}
{Description of the trend with specific numbers}

**為什麼重要：** {Business implication}

### 趨勢 3：{Title}
{Description of the trend with specific numbers}

**為什麼重要：** {Business implication}

---

## 🔍 值得注意的發現

### 亮點（好消息）
- {Positive finding 1 with data point}
- {Positive finding 2 with data point}

### 疑慮（請留意）
- ⚠️ {Concerning finding 1 with data point}
- ⚠️ {Concerning finding 2 with data point}

### 異常（需調查）
- ❓ {Unexpected data point that needs explanation}

---

## 比較

### 與前一期間相比
{How does this compare to last month/quarter/year?}

### 與目標相比
| 指標 | 實際 | 目標 | 差距 |
|--------|--------|--------|-----|
| {metric} | {value} | {value} | {+/-} |

### 與基準相比
{How does this compare to industry/competitor benchmarks if known?}

---

## 相關性與關係

{Any interesting relationships between variables}

- 當 {X} 增加時，{Y} 往往會 {behavior}
- {Variable A} 與 {Variable B} 看起來 {correlated/uncorrelated}

---

## 📊 建議視覺化

1. **{Chart type}** - 用來呈現 {what insight}
2. **{Chart type}** - 用來呈現 {what insight}
3. **{Chart type}** - 用來呈現 {what insight}

---

## 💡 建議

根據此分析：

1. **{Action 1}**
   - 原因：{rationale from data}
   - 影響：{expected outcome}

2. **{Action 2}**
   - 原因：{rationale from data}
   - 影響：{expected outcome}

3. **{Action 3}**
   - 原因：{rationale from data}
   - 影響：{expected outcome}

---

## 這引發的問題

- {Question that the data prompts but doesn't answer}
- {Additional data that would be helpful}
- {Follow-up analysis to consider}

---

## 資料品質備註

- **完整性：** {Any missing data?}
- **時間範圍：** {What period does this cover?}
- **注意事項：** {Any limitations to note?}
