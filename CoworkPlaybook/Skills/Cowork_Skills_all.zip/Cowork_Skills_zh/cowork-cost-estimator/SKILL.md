---
name: cowork-cost-estimator
description: |
  估算目前登入之單一使用者每月與每年的 Microsoft Copilot Cowork 授權成本。依工作者類別分類該使用者，使用正確的提示組合預設值填寫 Cowork 成本估算試算表，重新計算公式，並交付成本摘要卡、已填妥的 Excel 檔案，以及可直接傳送的系統管理員報告。

  當使用者要求「估算我的 Cowork 費用」、「Cowork 大概要多少錢」、「計算我的 Copilot Credits」、「我使用 Cowork 要付多少錢」、「Cowork 預算是多少」、「Cowork 成本計算器」、「模擬 Cowork 情境」、「Cowork 授權成本」、「每位使用者 Cowork 要多少錢」、"estimate my Cowork cost", "how much would Cowork cost",
  "calculate my Copilot Credits", "how much would I pay for Cowork",
  "what is the Cowork budget", "cost calculator for Cowork",
  "model Cowork scenarios", "Cowork licensing cost",
  "how much does Cowork cost per user" 時使用。

  請勿用於一般 Microsoft 365 訂閱價格、Azure 成本管理、Power BI 授權問題，或非 Cowork AI 工具成本分析（GitHub Copilot、Azure OpenAI）。
cowork:
  category: analysis
  icon: Calculator
---

# Copilot Cowork 成本估算器

使用 Microsoft Cowork 價格計算器試算表，估算目前登入之單一使用者每月 Copilot Credit 消耗量與 USD 成本。

## 不適用情境

- 一般 Microsoft 365 或 Azure 價格問題 — 直接依產品頁面回答
- 非 Cowork AI 授權（GitHub Copilot、Azure OpenAI、Copilot for M365）— 直接回答
- 實際發票對帳或歷史支出報告 — 使用帳務入口網站

## 工作流程

### 步驟 1 — 先詢問三個問題（阻擋）

此技能一律只估算 **單一使用者 — 目前登入的使用者**。在其他動作之前，先詢問這三個問題（使用 `AskUserQuestion`）。這些問題會控管後續工作流程 — 不得略過：

1. **估算器檔案** — 請使用者上傳 Cowork 估算器活頁簿（`CustomerCoworkEstimator.xlsx`）。先檢查 `input/`；若檔案已在其中，請直接使用並略過此問題。否則請等待上傳後再繼續 — 若檔案遺失，不得以代表性或占位資料替代。
2. **計算期間** — 詢問估算應涵蓋多少天。提供 **30 days**（一個月）、**90 days**（一季）與 **365 days**（一年）作為選項，並透過 "Other" 接受自訂天數。若使用者拒絕選擇，預設為 30 days。將此值稱為 `N`，並在步驟 3–4 全程沿用。
3. **每月限制** — 詢問系統管理員為該使用者設定的每月 Copilot Credit 限制（上限）。限制一律以 **每月 Copilot Credits** 表示（絕不以 USD 表示）。透過 "Other" 接受自訂數字，並允許選擇 "No limit / not sure" 以略過。將此值稱為 `L`。若已提供，於步驟 4 用它與估算的每月 Credits 比較；若略過，則省略限制比較。

接著從情境中解析其餘輸入，不再提問：

1. **使用者身分**：從系統情境讀取目前登入使用者的姓名、職稱與部門。
2. **範圍**：一律剛好 1 位使用者 — 目前登入的使用者。不要在此處處理團隊或整個組織的估算。
3. **工作者類別對應** — 將目前登入使用者的職稱關鍵字對應至計算器的四個類別之一，且只能對應一個：

   | 職稱關鍵字 | 類別 | 計算器列 |
   |--------------------|----------|----------------|
   | Architect, Engineer, Developer, SRE, DevOps, Data Scientist, IT, Technical | Technical Workers | D14 |
   | Sales, Account Executive, Customer Success, Account Manager, Pre-Sales, SE | Customer-Facing Knowledge Workers | D13 |
   | Manager, Director, VP, Head of, Principal, C-suite, Partner, GM, Lead | Managers & Senior Leaders | D15 |
   | 所有其他職務（analyst, coordinator, HR, legal, finance, marketing, ops） | Corporate Knowledge Workers | D12 |

### 步驟 2 — 填入計算器

使用 `openpyxl` 開啟 `input/CustomerCoworkEstimator.xlsx`，並將使用者人數寫入 Budget 工作表：

- `D12` = Corporate Knowledge Workers count
- `D13` = Customer-Facing Knowledge Workers count
- `D14` = Technical Workers count
- `D15` = Managers & Senior Leaders count

除非使用者明確提供覆寫值，否則保留所有預設提示組合值（D23:F26）與每次提示的 Credits 值（D33:D35）。

樣式慣例：
- 輸入儲存格：依財務模型慣例使用藍色字型（RGB `0000FF`、粗體）
- 在每個已填入列旁的 H 欄新增簡短註解（例如 `← 1 user: Rajesh Jayaraj, Cloud Solution Architect`）
- 將 H 欄加寬至 52 個字元，讓註解清楚可讀

將輸出儲存至 `output/CoworkEstimator_<FirstName>.xlsx`（使用目前登入使用者的名字）。

### 步驟 3 — 重新計算並抽查

執行 `python scripts/recalc.py output/CoworkEstimator_<FirstName>.xlsx`，並確認 `status: success` 且公式錯誤為零。

回報前，先以手動計算驗證關鍵計算值：
- `G25`（Technical Workers credits/user）= `(D25×D33) + (E25×D34) + (F25×D35)`
- `D41`（每月總 Credits）= `SUMPRODUCT(D12:D15, G23:G26)`
- `D42`（每月 USD）= `D41 / 100`
- `D43`（每位使用者/月成本）= `D42 / SUM(D12:D15)`

接著按步驟 1 要求的期間 `N` 天進行按比例換算。計算器的數字涵蓋完整月份；請使用 365 天年度換算，讓 `N = 365` 可對齊年度總額：
- 每日 Credits = `(D41 × 12) / 365`
- **期間 Credits** = 每日 Credits × `N`
- **期間 USD** = 期間 Credits / 100
保留每月與每年數字作為參考點；不要覆寫試算表的每月公式來做此事 — 請另外計算期間值。

### 步驟 4 — 顯示結果卡片（一律在畫面上）

**一律呈現畫面上的 `render_ui` 摘要卡**（使用 `render-ui` skill）。這張圖形卡片是**使用者看到的主要輸出** — 每次執行都要呈現，且必須在步驟 5 產生 Word 報告之前呈現。絕不能略過卡片並直接跳到報告。卡片包含：
- 使用者分類：角色 → 工作者類別
- **計算期間**：`N` days（依步驟 1 選擇）
- **要求期間的成本**：`N` 天內的 Copilot Credits 與 USD
- 估計每月 Credits
- 每月成本（估計）
- 年度成本（估計）
- 使用的提示組合（每月 Light / Medium / Heavy）
- **每月限制**（僅在已提供 `L` 時）：Credit 上限、**估計每月 Credits** 與該上限的比較，以及**剩餘**（或**超出**）Credits。請與*每月*估算值（`D41`）比較 — 絕不要與 `N` 天期間數值比較，因為那是不同單位。若估算超過限制，請清楚標示。

**在同一張卡片中包含圖表**，讓結果可一眼看懂（使用 `render-ui` skill 的圖表元素）：
- **已提供每月限制（`L`）** → 使用 `Chart.Gauge` 顯示**估計每月 Credits 相對於限制 `L`**，讓使用者立即看出是否在上限內或已超出。
- **無限制** → 使用 `Chart.Donut` 顯示**依提示類型區分的 Credits**（Light / Medium / Heavy），凸顯 Heavy 提示的成本驅動因素。
- 以 Credits（或 USD）值標示每個區段，並在每次執行中保持提示類型顏色順序一致。

**限制狀態顏色（僅在已提供 `L` 時）** — 依估計每月 Credits 與 `L` 的比較，為儀表值、限制指標及任何狀態徽章著色：
- **綠色** — 在限制內：估算值 ≤ `L` 的 80%
- **琥珀色** — 接近限制：估算值介於 `L` 的 80% 到 100% 之間（含）
- **紅色** — 超過限制：估算值 > `L`

在顏色旁以文字說明狀態（例如 "Within limit", "Approaching limit", "Over limit"），讓內容不只依賴顏色也能正確解讀。

卡片後接續：
1. 檔案參照：`output/CoworkEstimator_<FirstName>.xlsx`
2. 一行關鍵洞察：指出單一最大成本驅動因素（通常是 Technical Workers 的 Heavy 提示）
3. 揭露說明：無法透過 Microsoft 365 APIs 存取實際工作階段記錄 — 使用 Microsoft Frontier 預設提示組合作為代理值
4. 情境提議："Want me to run Light-skew and Heavy-skew scenarios to see the cost range?"

### 步驟 5 — 產生系統管理員報告（僅限 Word 文件）

卡片出現在畫面後，產生可分享的報告，且**只能是 Word 文件**（`.docx`）— 不要產生 PDF、HTML、內嵌副本或郵件版本。使用 `docx` skill 產生 `output/CoworkCostReport_<FirstName>.docx` — 這是一頁式整潔報告，使用者可轉寄給其系統管理員（例如用於申請預算或 Credit 限制決策），內容包含：

- **標頭**：標題（"Microsoft Copilot Cowork — Cost Estimate"）、準備者（目前登入使用者的姓名、職稱、部門）與日期。
- **目的行**：一句話說明分享原因（例如預算核准 / 每月限制檢閱）。
- **摘要表**：使用者（角色 + 工作者類別）、計算期間（`N` days）、期間估計成本、估計每月 Credits、每月成本（估計）與年度成本（估計）。
- **限制狀態重點提示**（僅在已提供 `L` 時）：每月上限、估計每月 Credits 與上限、剩餘/超出，以及狀態文字 — 依相同的 80% / 80–100% / 超出上限門檻，以綠色 / 琥珀色 / 紅色呈現。
- **假設與揭露**：使用的提示組合，以及 Frontier 預設代理值說明（無法透過 M365 APIs 存取工作階段記錄；這是方向性估算，不是帳務承諾）。
- **請求動作**：簡短結尾句（例如「請核准上述每月限制 / 預算」）。

文件建立後，向使用者確認 Word 報告已儲存在 `output/`，可分享給其系統管理員（透過附加到郵件或 Teams 訊息）。不要草擬或傳送郵件，也不要以其他格式產生報告 — Word 文件是唯一的報告成品。

## 輸出格式

| 成品 | 位置 | 說明 |
|----------|----------|-------------|
| Excel 檔案 | `output/CoworkEstimator_<FirstName>.xlsx` | 已填妥計算器，包含藍色輸入儲存格與 H 欄註解 |
| 摘要卡 | 內嵌（`render_ui`） | **一律顯示。** 期間成本（N 天內）、估計每月 Credits、每月 USD、年度 USD，以及圖表（使用量對限制儀表，或提示類型環圈圖） |
| 系統管理員報告 | `output/CoworkCostReport_<FirstName>.docx` | 唯一報告成品 — 可分享給系統管理員的 Word 一頁式報告（無 PDF/HTML/email 版本） |
| 情境提議 | 內嵌文字 | 提議模擬樂觀與保守的提示組合 |

## 價格參考（Microsoft Frontier 預設值，5/27/2026）

**每次提示的 Credits（計算器步驟 3）：**

| 提示類型 | Credits | Cost @ list price |
|-------------|---------|-------------------|
| Light | 125 | $1.25 |
| Medium | 500 | $5.00 |
| Heavy | 1,200 | $12.00 |

Conversion rate: **100 Copilot Credits = $1 USD**（list price）。Model baseline: Anthropic Opus 4.8。

**每位使用者預設每月提示組合（計算器步驟 2）：**

| Category | Light | Medium | Heavy | Credits/user/mo |
|----------|-------|--------|-------|-----------------|
| Corporate Knowledge Workers | 22 | 11 | 5 | 14,250 |
| Customer-Facing Knowledge Workers | 17 | 13 | 5 | 14,625 |
| Technical Workers | 12 | 9 | 14 | 22,800 |
| Managers & Senior Leaders | 13 | 6 | 3 | 8,225 |

## 防護原則

- 絕不捏造使用者人數、提示量或成本數字 — 只能使用使用者提供的資訊，或試算表中的 Frontier 預設值。
- 不要將計算值硬式編碼到 Excel 輸出中 — 保留 Excel 公式，讓檔案維持可編輯。
- 一律揭露這是方向性預算估算，不是帳務承諾。
- 一律揭露無法透過 Microsoft 365 APIs 存取實際工作階段記錄；預設提示組合會作為代理值使用。
- 一律先要求使用者上傳 `CustomerCoworkEstimator.xlsx`（除非它已在 `input/` 中）— 這是阻擋問題；不得以代表性或占位資料替代。
- 絕不捏造計算期間 — 使用使用者提供的天數；只有在使用者拒絕選擇時，才預設為 30 days。
- 絕不捏造每月限制 — 只使用使用者提供的上限。若使用者略過，請省略限制比較與限制儀表，不要假設預設上限。
- 提供限制時，一律一致地標示狀態顏色與文字：綠色 ≤ 上限的 80%，琥珀色 80–100%，紅色為超過上限 — 並一律以文字說明狀態，不只依賴顏色。
- 一律先在畫面上顯示圖形化 `render_ui` 摘要卡 — 這是主要面向使用者的輸出，每次執行都必須出現，絕不能略過而直接產生報告。
- 系統管理員報告只能產生為 Word 文件（`output/CoworkCostReport_<FirstName>.docx`）— 絕不能是 PDF、HTML、內嵌副本或郵件。不要草擬或傳送郵件；由使用者自行分享 Word 檔案。
- 此技能僅適用單一使用者 — 一律估算目前登入使用者，並將其分類到剛好一個工作者類別。不要處理團隊或整個組織的估算。
- 每月限制一律以 Copilot Credits 表示（絕不以 USD 表示）— 不要轉換或重新詮釋。只將它與估計*每月* Credits 比較，不要與期間數字比較。
- "Estimated monthly Credits" 與 "Monthly cost (est)" 是依預設提示組合推估，不是實際使用量 — 請標示為估計值，且絕不呈現為已量測的消耗。
- 一律將系統管理員報告製作成使用者可檢閱的交付檔案；不要自動傳送給系統管理員或猜測收件者。只有在使用者指定收件者後，才建立郵件草稿，並讓它保持草稿狀態由使用者自行傳送。
