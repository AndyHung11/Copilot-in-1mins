---
name: file-organizer
description: |
  建議 OneDrive 與 SharePoint 檔案的整理與清理方式。
  當使用者要求「整理我的檔案」、「清理 OneDrive」、「檔案結構」、
  「資料夾整理」、「整理雜亂檔案」、「整理文件」、"organize my files", "clean up OneDrive", "file structure",
  "folder organization", "declutter files", or "organize documents" 時使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: document-intelligence
  m365-services: [OneDrive, SharePoint, Graph]
---

# 檔案整理建議
分析並建議如何整理您的 M365 檔案。

## M365 整合

- **OneDrive:** 個人檔案分析
- **SharePoint:** 文件庫整理
- **Microsoft Graph:** 檔案中繼資料、活動

## 此技能的功能

提供：
- 目前狀態分析
- 重複檔案偵測
- 舊檔/停用檔案識別
- 資料夾結構建議
- 命名慣例建議
- 清理行動計畫

## 適用情境

- OneDrive 雜亂且難以瀏覽
- 從頭開始整理
- 年度檔案清理
- 移轉檔案之前
- 設定新的專案結構

## 輸出格式

# 檔案整理報告

## 目前狀態分析

### 位置：{OneDrive or SharePoint site}

| 指標 | 值 |
|--------|-------|
| **檔案總數** | {count} |
| **總大小** | {GB} |
| **資料夾** | {count} |
| **最大資料夾深度** | {levels} |
| **根目錄中的檔案** | {count} ⚠️ {if high} |

---

## 📊 檔案分布

### 依類型
| 類型 | 數量 | 大小 | 佔總量百分比 |
|------|-------|------|------------|
| 文件（.docx, .pdf） | {n} | {size} | {%} |
| 試算表（.xlsx） | {n} | {size} | {%} |
| 簡報（.pptx） | {n} | {size} | {%} |
| 圖片 | {n} | {size} | {%} |
| 其他 | {n} | {size} | {%} |

### 依時間
| 時間 | 數量 | 建議 |
|-----|-------|----------------|
| < 30 days | {n} | 使用中 - 保持整理 |
| 30-90 days | {n} | 檢閱相關性 |
| 90-365 days | {n} | 封存候選項目 |
| > 1 year | {n} | 封存或刪除 |

### 依大小（最大檔案）
| 檔案 | 大小 | 位置 | 上次存取 |
|------|------|----------|---------------|
| {filename} | {size} | {path} | {date} |
| {filename} | {size} | {path} | {date} |
| {filename} | {size} | {path} | {date} |
