---
name: meeting-followup
description: |
  從使用者最近一次會議擷取行動項目與決策，並草擬寄給與會者的
  後續追蹤郵件。當使用者說「寄出我上一通電話的後續追蹤」、「幫我草擬上一場會議摘要」、「追蹤那場會議」、「寄出站會的行動項目」、「寫一封會議摘要信給與會者」、"send the follow-up from my last call",
  "draft a recap of my last meeting", "follow up on that meeting", "send action items from
  the standup", or "write a recap email to attendees" 時使用。
  不要用於主動會議準備 — 請改用 meeting-intel 或 schedule-meeting。
  不要用於與特定會議無關的一般利害關係人更新 — 請改用
  stakeholder-comms。
cowork:
  category: communication
  icon: Mail
---

## 概觀

找出使用者最近完成的會議，從其逐字稿擷取決策與行動項目（若沒有逐字稿，則從該時段周邊的聊天/郵件背景擷取），接著草擬一封給與會者的摘要郵件，供使用者檢閱並寄出。

## 使用時機

- 使用者剛結束一通電話，想寄送摘要
- 使用者說「後續追蹤」、「摘要」、「行動項目」但沒有指名會議
- 使用者想提醒與會者各自承諾的事項

## 不適用時機

- 為即將到來的會議做準備 → 使用 `meeting-intel`
- 與會議無關的一般團隊更新 → 使用 `stakeholder-comms`
- 排定新會議 → 使用 `schedule-meeting`

## 快速開始

```
使用者: 「寄出我上一通電話的後續追蹤」
1. ListCalendarView 查過去 6 小時 → 選取最近結束的會議
2. ListMeetingTranscripts 該會議 → 若可用則 GetMeetingTranscript
3. 若沒有逐字稿：搜尋該時段周邊的 Teams/郵件背景
4. 擷取：決策、行動項目（負責人 + 到期日）、未決問題
5. 使用 CreateDraftMessage 草擬給與會者的郵件，顯示供檢閱
```

## 核心指示

### 步驟 1：識別會議
- 從使用者情境解析目前時間
- 呼叫 `ListCalendarView`，start = 8 hours ago，end = now，`is_organizer=false` 不設定（兩者都包含）
- 選取使用者曾參加且最近結束的事件（略過已拒絕/已取消）
- 若有多場近期會議，使用 `AskUserQuestion` 並以候選會議作為選項詢問使用者

### 步驟 2：取得內容
- 如果事件有 `onlineMeeting.joinUrl`，呼叫 `ListMeetingTranscripts`，再呼叫 `GetMeetingTranscript`
- 如果沒有逐字稿：呼叫 `SearchM365`，搭配 `sources=["teams","email"]`，範圍限定當天，並以會議主旨作為查詢
- 如果仍找不到內容：告知使用者你找不到內容，並提供只根據會議主旨 + 與會者草擬的選項

### 步驟 3：擷取結構
從逐字稿或背景內容擷取：
- **決策** — 已達成共識的事項
- **行動項目** — 負責人、任務、到期日（若有提到）
- **未決問題** — 仍未解決的事項
- **下一步** — 後續會議或檢查點

絕不捏造負責人或日期。若不清楚，標示為 `[owner TBD]`。

### 步驟 4：草擬郵件
使用 `CreateDraftMessage`，並設定：
- **To:** 原始與會者（排除使用者）
- **Subject:** `Recap: <meeting subject>`
- **Body** 結構：
  ```
  謝謝大家參加今天的 <meeting>。以下是簡短摘要。

  決策
  - ...

  行動項目
  - <Owner>: <task> — <due date>

  未決問題
  - ...

  若我有遺漏任何事項，請告訴我。
  ```

將草稿顯示給使用者，讓他們在寄出前編輯。除非使用者明確說 "send it"，否則不要呼叫 `SendDraftMessage`。

## 護欄

- 絕不編造來源中沒有的行動項目、負責人或日期
- 一律建立草稿（`CreateDraftMessage`）— 絕不直接寄出
- 如果會議是私人/1:1，草擬前先確認，確保使用者想留下書面紀錄
- 遮蔽任何敏感人事討論（薪酬、績效）— 改為提醒使用者
