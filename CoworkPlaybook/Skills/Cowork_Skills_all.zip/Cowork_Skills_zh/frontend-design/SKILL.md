---
name: frontend-design
description: 建立有鮮明觀點、可上線使用的高品質前端介面。當使用者要求設計或實作 Web component、頁面、landing site、dashboard、marketing site 或任何 UI 介面時使用此技能；也可在使用者說「設計一個網頁元件」、「做一個落地頁」、「設計 dashboard」、「重做這個 UI」、「建立行銷網站」時使用。產生可運作的程式碼，並做出有意識的美學選擇，避免看起來像預設 AI-template。
---

這個技能會產出看起來像經過設計、而不是被生成出來的前端程式碼。每個輸出都應該有清楚的美學識別、精緻的執行，以及值得再看一眼的細節。

使用者會描述想要建置的內容 — 一個元件、一個頁面、整個應用程式 — 也可能包含受眾、品牌、框架或限制條件等背景。如果沒有指定品牌或語氣，請自行選擇方向並貫徹；不要預設成中性的範本。

## 前置準備：確立方向

撰寫任何程式碼之前，先在內部回答四個問題：

- **目的**：這個介面用來做什麼，使用者是誰？他們應該採取什麼行動？
- **語氣**：選一個並貫徹。選項包括 — 編輯/印刷風（editorial/print-inspired）、粗野主義/原始 HTML（brutalist/raw HTML）、瑞士字體風（swiss/typographic）、復古終端機（retro-terminal）、柔和擬物（soft neumorphic）、玻璃擬態/極光（glassmorphic/aurora）、蒸氣波（vaporwave）、新藝術（art nouveau）、bauhaus 幾何（bauhaus geometric）、手繪/草圖（hand-drawn/sketchy）、賽博龐克（cyberpunk）、等寬實用風（monospace utilitarian）、奢華/大量襯線（luxury/serif-heavy）、勒索信拼貼（ransom-note collage）、等角/3D（isometric/3D）、環境/自然靈感（ambient/nature-inspired）。若兩者能互相強化，可以混合兩種；絕不要混合三種。
- **限制**：框架、瀏覽器目標、無障礙底線（除非另有指示，最低為 WCAG AA）、效能預算、響應式斷點。
- **記憶點**：訪客會記住並向朋友描述的那一個元素是什麼？每個設計都需要一個招牌動作 — 字體上的巧思、不尋常的版面原語、意料之外的互動、醒目的配色。

**CRITICAL**：意圖明確勝過強度堆疊。精準執行的克制設計，比粗糙執行的高聲量設計更有力量。選定路線，並把它做到位。

## 輸出要求

每個交付項目都必須：

- **可運作**：是不需修改即可執行的真實程式碼 — 沒有 pseudocode，沒有 `// TODO: implement`
- **無障礙**：語意化 HTML、可用鍵盤操作、對比足夠、焦點狀態經過設計（不是瀏覽器預設）
- **響應式**：採 mobile-first，或基於設計選擇明確只支援桌面；絕不能是「意外在手機上壞掉」
- **一致**：整個輸出使用一套設計系統、一種動態語言、一致的語氣
- **精緻**：小細節 — 標題字距、視覺對齊、hover 狀態、空狀態、載入狀態 — 都是有意安排，而不是省略

## 工藝準則

- **字體**：字體是最響亮的設計選擇。創意地使用 Google Fonts、Fontshare 或系統備援字體。將有個性的展示字體與易讀的內文字體配對 — 例如 Fraunces + Inter Tight、PP Editorial New + JetBrains Mono、Instrument Serif + Geist、Söhne + Tiempos。推動 variable font 軸線（weight、optical size、slant）。使用真正的排版細節：懸掛標點、真正的小型大寫、在適合處使用表格數字、連字、長文內容的首字放大。避開安全預設 — 單獨使用 Inter、Roboto、Arial、Helvetica 且沒有觀點。

- **色彩**：一個主色、一到兩個強調色，以及刻意選定的中性色。把所有顏色定義為 CSS custom properties。亮色、暗色或雙色 — 一開始就決定。考慮不尋常的色盤：溫暖米白 + 墨黑 + 一個高飽和強調色；深海軍藍 + 奶油色 + 黃銅色；近黑 + 酸性綠；沙色 + 陶土色 + 海洋色。避開 AI 痕跡：白底上的靛紫漸層、slate-50 背景搭 slate-900 文字和 blue-600 按鈕。

- **版面與構圖**：網格存在的目的，是被有意識地使用 — 用來對齊，或被刻意打破。嘗試不對稱、刻意重疊、裁出容器外的超大字、帶有編輯感的側欄、長文的 baseline grid。寬裕留白或受控密度 — 選一個。避免那種「三欄式功能卡片網格」的預設感
