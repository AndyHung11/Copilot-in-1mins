---
name: weekly-wrap
description: |
  彙整使用者過去一週寄出的郵件、已接受的會議與 Teams 貼文，
  形成週五狀態筆記。當使用者說「幫我整理這週」、「每週回顧」、「寫我的每週狀態」、「我這週做了什麼」、「週五狀態筆記」、「摘要我的一週」、"wrap my week", "weekly wrap", "write my
  weekly status", "what did I do this week", "Friday status note", or "summarize my week" 時使用。
  不要用於每日摘要 — 請改用 daily-briefing。
  不要用於前瞻性規劃 — 此 skill 只做回顧。
cowork:
  category: productivity
  icon: Flag
---

## 概觀

擷取使用者本工作週在 Outlook（已傳送郵件）、行事曆（已接受會議）與 Teams（頻道 + 聊天貼文）的活動，然後產出結構化狀態筆記，使用者可張貼到團隊頻道、寄給主管，或保留作為個人紀錄。

## 使用時機

- 週末撰寫狀態更新
- 回顧自己完成了哪些事
- 從一週活動建立主管更新或團隊摘要

## 不適用時機

- "What did I miss today" / 早晨簡報 → 使用 `daily-briefing`
- 多週或季度報告 → 使用 `stakeholder-comms`
- 單一會議摘要 → 使用 `meeting-followup`

## 快速開始

```
使用者: 「幫我整理這週」
1. 計算週範圍（Monday 00:00 → now），使用使用者時區
2. 平行執行：
   - ListMessages，使用 folder_id=sentitems, received_after=<Monday>
   - ListCalendarView 使用相同時間範圍，is_organizer filter both ways
   - SearchM365 sources=["teams"], from_user=<user email>, after=<Monday>
3. 將結果分組為主題（專案、議題、人員）
4. 產出結構化週五狀態筆記
```

## 核心指示

### 步驟 1：解析週範圍
- 使用使用者目前的本地時間
- 一週從使用者時區的 Monday 00:00 開始，到 now 結束
- 如果是週一早上，詢問使用者指的是上週還是目前這個不完整週

### 步驟 2：平行蒐集資料
同時執行以下三個工具呼叫：
- `ListMessages(folder_id="sentitems", received_after=<Monday ISO>, top=100)`
- `ListCalendarView(start=<Monday>, end=<now>, top=50)` — 只保留使用者已參加的事件（未拒絕）
- `SearchM365(sources=["teams"], from_user=<user email>, after=<Monday>, response_length="long")`

若任何工具回傳 `next_link`，請接續處理。

### 步驟 3：分類並分組
依主題分組活動。從重複主旨、與會者重疊或頻道名稱偵測主題。
常見桶：
- **已交付 / 有進展的專案**
- **重要會議**
- **已做成的決策**
- **互動過的人員**

### 步驟 4：輸出格式

```markdown
# <Mon date> – <Fri date> 週

## 重點亮點
- 3–5 個項目，列出最重要的事

## 我做了什麼
- 依專案/主題分組

## 值得一提的會議
- 只列有結果的會議（不含例行同步）

## 下週
- 2–3 件延續事項（只有在可從未結討論明顯看出時）
```

預設以內嵌 markdown 呈現。若使用者要求檔案或想分享，提供草擬 Teams 貼文（`PostMessage`）或郵件（`CreateDraftMessage`）— 未經檢閱絕不送出。

## 護欄

- 絕不包含私人約會（sensitivity=private）— 只顯示為時間區塊
- 絕不在公開摘要中包含人事/HR/薪酬討論
- 絕不捏造成果 — 如果那週活動較少，就如實說明
- 預設使用內嵌 markdown；只有在明確要求時才建立檔案或傳送訊息
