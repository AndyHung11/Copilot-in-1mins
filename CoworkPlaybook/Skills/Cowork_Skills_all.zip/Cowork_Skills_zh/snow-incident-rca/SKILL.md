---
name: snow-incident-rca
description: |
  從 ServiceNow 事件資料產生 Root Cause Analysis 報告。
  當使用者要求「產生 RCA」、「根本原因分析」、「分析這個事件」、
  「RCA 報告」、「事件事後檢討」、「5 whys 分析」、「這個事件的原因是什麼」、"generate RCA", "root cause analysis", "analyze this incident",
  "RCA report", "incident postmortem", "5 whys analysis", or "what caused this incident" 時使用。
  使用者可透過貼上、附加匯出檔，或描述事件來提供事件資料。
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
  requires-connector: false
---

# ServiceNow 事件 RCA 產生器

從 ServiceNow 事件資料產生完整 Root Cause Analysis 報告 - 不需要伺服器部署。

## 運作方式

1. 使用者提供事件資料（貼上、附加或描述）
2. 技能分析資料
3. 產生包含 CMDB 參照的格式化 RCA 報告

## 不需要伺服器

此技能會使用您直接提供的資料：
- 從 ServiceNow 貼上事件詳細資料
- 附加匯出的 CSV/Excel
- 從 ServiceNow 表單複製
- 口頭描述事件

## 適用情境

- 事件後檢閱
- 重大事件分析
- 問題管理
- 合規文件
- 服務改善

## 如何提供資料

### 選項 1：貼上事件欄位
從 ServiceNow 複製這些欄位：
- Incident Number
- Short Description
- Description
- Priority / Impact / Urgency
- State
- Opened / Resolved dates
- Assignment Group / Assigned To
- Configuration Item (CI)
- Resolution Notes
- Work Notes（關鍵項目）

### 選項 2：附加匯出檔
從 ServiceNow 匯出為 CSV 或 Excel，並附加該檔案。

### 選項 3：描述事件
告訴我：
- 發生了什麼事？
- 何時開始/結束？
- 影響了什麼？
- 如何解決？
- 涉及哪些系統/CI？

## 工作流程

1. **剖析事件資料**
   - 擷取關鍵欄位
   - 識別受影響的 CI
   - 記錄時間軸

2. **結構化分析**
   - 影響評估
   - 時間軸重建
   - CI 關係對應

3. **產生 RCA**
   - 5 Whys 架構
   - 促成因素
   - 建議

4. **輸出報告**
   - 格式化 markdown
   - 可直接用於文件

## 輸出格式

# Root Cause Analysis 報告

## 事件概觀

| 欄位 | 值 |
|-------|-------|
| **Incident Number** | {from provided data} |
| **Short Description** | {from provided data} |
| **Priority** | {P1/P2/P3/P4/P5} |
| **Impact** | {1-High/2-Medium/3-Low} |
| **Urgency** | {1-High/2-Medium/3-Low} |
| **State** | {New/In Progress/Resolved/Closed} |
| **Opened** | {date/time} |
| **Resolved** | {date/time} |
| **Duration** | {calculated} |
| **Assignment Group** | {group name} |
| **Assigned To** | {person} |
| **Caller/Affected User** | {user} |

---

## 影響摘要

### 業務影響
- **受影響使用者：** {number or scope}
- **受影響服務：** {list services}
- **受影響業務流程：** {processes}
- **財務影響：** {if known}

### 技術影響
- **受影響系統：** {list}
- **資料影響：** {none/read-only/data loss}
- **整合影響：** {downstream effects}

---

## Configuration Item（受影響的 CI）

| 屬性 | 值 |
|-----------|-------|
| **CI Name** | {from data or ask user} |
| **CI Class** | {Server/Application/Database/Network/Service} |
| **Environment** | {Production/Staging/Dev} |
| **Business Service** | {service name} |
| **Support Group** | {owning team} |

### CMDB 關係
若使用者提供 CI 關係：

**上游（此 CI 相依於）：**
- {Parent CI 1}
- {Parent CI 2}

**下游（相依於此 CI）：**
- {Child CI 1}
- {Child CI 2}

---

## 時間軸

| 時間 | 事件 | 來源 |
|------|-------|--------|
| {time} | 第一個症狀/警示 | {monitoring/user report} |
| {time} | 事件建立 | ServiceNow |
| {time} | 團隊投入處理 | Assignment |
| {time} | 找出根本原因 | Investigation |
| {time} | 套用修正 | Work notes |
| {time} | 服務復原 | Verification |
| {time} | 事件解決 | ServiceNow |

---

## 根本原因分析

### 發生了什麼事
{Detailed description of the incident based on provided data}

### 直接原因
{The direct trigger that caused the incident}

### 促成因素
| 因素 | 類別 | 詳細資料 |
|--------|----------|---------|
| {factor 1} | {Process/Tech/People/External} | {description} |
| {factor 2} | {category} | {description} |
| {factor 3} | {category} | {description} |

### 5 Whys 分析

1. **為什麼 {incident symptom} 發生？**
   → 因為 {immediate cause}

2. **為什麼 {immediate cause} 會發生？**
   → 因為 {contributing factor 1}

3. **為什麼 {contributing factor 1} 會發生？**
   → 因為 {contributing factor 2}

4. **為什麼 {contributing factor 2} 會發生？**
   → 因為 {underlying cause}

5. **為什麼 {underlying cause} 會發生？**
   → 因為 **{ROOT CAUSE}**

### 根本原因陳述
**{Clear, concise statement of the fundamental root cause}**

---

## 解決方案

### 修復方式
{Description of the resolution from provided data}

### 解決方案類別
- [ ] 組態變更
- [ ] 程式碼修正
- [ ] 基礎架構變更
- [ ] 重新啟動/reboot
- [ ] 復原
- [ ] 廠商修正
- [ ] 流程變更
- [ ] 其他：{specify}

### 驗證
{How was the fix verified to be working?}

---

## 建議

### 立即行動（本週）
| # | 行動 | 負責人 | 優先順序 | 到期日 |
|---|--------|-------|----------|-----|
| 1 | {specific action} | {assign} | High | {date} |
| 2 | {specific action} | {assign} | High | {date} |

### 短期改善（本月）
| # | 改善 | 類別 | 工作量 |
|---|-------------|----------|--------|
| 1 | {improvement} | {Process/Tech/Monitoring} | {H/M/L} |
| 2 | {improvement} | {category} | {effort} |

### 長期改善（本季）
| # | 改善 | 類別 | 工作量 |
|---|-------------|----------|--------|
| 1 | {strategic improvement} | {category} | {effort} |

---

## 預防

### 如何防止再次發生
1. {Prevention measure 1}
2. {Prevention measure 2}
3. {Prevention measure 3}

### 監控改善
| 監控項目 | 警示門檻 | 負責人 |
|-----------------|-----------------|-------|
| {metric} | {threshold} | {team} |

### 流程變更
- {Process change 1}
- {Process change 2}

---

## 相關記錄

### Problem Ticket
**建立 Problem？** Yes / No
**Problem Statement：** {if yes, suggested problem description}

### Change Requests
若需要變更以防止再次發生：
| 變更 | 類型 | 風險 | 目標日期 |
|--------|------|------|-------------|
| {change} | {Normal/Standard/Emergency} | {H/M/L} | {date} |

### Knowledge Article
**建立 KB？** Yes / No
**Suggested Title：** {title}
**Key Points：** {what to document}

---

## 經驗教訓

1. **做得好的地方：**
   - {positive aspect of response}
   - {another positive}

2. **可改善之處：**
   - {improvement area}
   - {another area}

3. **關鍵收穫：**
   {Single most important lesson from this incident}

---

## 附錄

### Work Notes 摘要
{Key work notes from incident if provided}

### 參照附件
{List any attachments or evidence}

### 參與人員
| 角色 | 姓名 |
|------|------|
| Incident Manager | {name} |
| Technical Lead | {name} |
| Resolver | {name} |

---

## 簽核

| 角色 | 姓名 | 日期 |
|------|------|------|
| RCA 作者 | | |
| 技術檢閱者 | | |
| 服務負責人 | | |

---

*由 Copilot Cowork 的 ServiceNow RCA Skill 產生*

## 範例提示

"Generate RCA for this incident: [paste incident details]"

"Create root cause analysis - incident INC0010001, server crashed due to memory leak, affected 500 users for 2 hours"

"Analyze this incident and create RCA report [attach CSV export]"

"5 whys analysis for a database outage that happened yesterday"
