---
name: permissions-audit
description: |
  審閱檔案與 SharePoint 網站的分享與權限。
  當使用者要求「誰有存取權」、「檢查權限」、「分享稽核」、「誰可以看到這個檔案」、「審閱存取權」、「權限報告」、"who has access", "check permissions", "sharing audit",
  "who can see this file", "review access", 或 "permissions report" 時使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: document-intelligence
  m365-services: [SharePoint, OneDrive, Graph, Entra ID]
---

# 權限稽核

審閱並回報檔案與網站的分享權限。

## M365 整合

- **SharePoint:** 網站權限、文件庫設定
- **OneDrive:** 個人分享設定
- **Microsoft Graph:** 分享連結、存取詳細資料
- **Entra ID:** 群組成員資格、來賓使用者

## 此技能的用途

分析並回報：
- 誰有檔案/資料夾/網站的存取權
- 存取類型（檢視、編輯、擁有者）
- 外部分享狀態
- 分享連結（匿名、全組織）
- 權限繼承
- 潛在安全疑慮

## 使用時機

- 分享敏感文件前
- 定期安全性審閱
- 員工離職移交流程
- 合規稽核
- 調查非預期存取

## 輸出格式

# 權限稽核報告

## 稽核目標

| 屬性 | 值 |
|----------|-------|
| **項目** | {file/folder/site name} |
| **類型** | {File/Folder/Document Library/Site} |
| **位置** | {path} |
| **擁有者** | {name} |
| **建立日期** | {date} |
| **上次修改** | {date} |

---

## 存取摘要

| 存取類型 | 數量 |
|-------------|-------|
| 擁有者 | {n} |
| 編輯者 | {n} |
| 檢視者 | {n} |
| 外部使用者 | {n} |
| 分享連結 | {n} |

**整體風險等級：** {🟢 Low / 🟡 Medium / 🔴 High}

---

## 直接存取

### 擁有者（完全控制）
| 使用者/群組 | 類型 | 來源 |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

### 編輯者（可編輯）
| 使用者/群組 | 類型 | 來源 |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

### 檢視者（可檢視）
| 使用者/群組 | 類型 | 來源 |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

---

## 🔗 分享連結

| 連結類型 | 範圍 | 建立者 | 到期日 |
|-----------|-------|------------|------------|
| {Anyone/Organization/Specific people} | {View/Edit} | {name} | {date or Never} |

### ⚠️ 匿名連結
{List of "Anyone with the link" shares - security concern}

---

## 👥 外部分享

### 來賓使用者
| 電子郵件 | 存取層級 | 邀請者 | 日期 |
|-------|--------------|------------|------|
| {email} | {level} | {name} | {date} |

### 外部網域
| 網域 | 使用者 | 風險 |
|--------|-------|------|
| {domain.com} | {n} | {assessment} |

---

## 🏢 群組存取

| 群組 | 成員 | 存取層級 |
|-------|---------|--------------|
| {group name} | {n} 位成員 | {level} |

**值得注意的群組成員資格：**
- {Group} 包含 {notable members}

---

## 📊 權限繼承

```
{Site/Library}
├── 📁 {Folder 1} - 繼承
│   └── 📄 {File} - 繼承
├── 📁 {Folder 2} - ⚠️ 唯一權限
│   └── 📄 {File} - 繼承自資料夾
└── 📄 {File} - ⚠️ 唯一權限
```

---

## ⚠️ 安全疑慮

### 高優先順序
- 🔴 {Concern - e.g., "Anonymous link to sensitive file"}
- 🔴 {Concern}

### 中優先順序
- 🟡 {Concern - e.g., "External user with edit access"}
- 🟡 {Concern}

### 建議
1. **{Action}** - {reason}
2. **{Action}** - {reason}
3. **{Action}** - {reason}

---

## 最近權限變更

| 日期 | 變更 | 執行者 |
|------|--------|---------|
| {date} | {what changed} | {who} |

---

## 合規備註

- **外部分享：** {Enabled/Disabled} at site level
- **來賓存取原則：** {policy status}
- **敏感度標籤：** {if applied}
- **保留原則：** {if applied}

---

## 快速動作

- 🔒 **移除** {items} 的外部存取權
- ⏱️ **為分享連結設定到期日**
- 👤 **移除** {user} 的存取權
- 📧 **通知擁有者** 關於 {concern}
