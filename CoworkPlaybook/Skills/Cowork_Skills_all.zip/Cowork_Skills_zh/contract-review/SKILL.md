---
name: contract-review
description: |
  分析合約與協議的關鍵條款、風險與義務。
  當使用者要求「幫我審閱這份合約」、「分析這份協議」、「檢查合約條款」、「找出責任條款」、「摘要這份 NDA」、「合約風險」、"review this contract", "analyze agreement", "check contract terms",
  "find liability clause", "summarize this NDA", 或 "contract risks" 時使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
---

# 合約審閱

分析合約以萃取關鍵條款、識別風險並摘要義務。

## 此技能的用途

審閱合約並提供：
- 執行摘要
- 關鍵條款萃取
- 重要日期與期限
- 風險識別
- 義務追蹤
- 不尋常或令人疑慮的條款

## 使用時機

- 審閱供應商協議
- 簽署前分析 NDA
- 檢查客戶合約
- 支援續約決策
- 盡職調查審閱

## 工作流程

1. **文件分析**
   - 識別合約類型
   - 萃取涉及方
   - 找出有效日期與期限

2. **關鍵條款萃取**
   - 付款條件
   - 交付項目與範圍
   - 終止條件
   - 續約條款

3. **風險評估**
   - 責任條款
   - 賠償
   - 責任限制
   - IP 所有權
   - 保密範圍

4. **義務對應**
   - 我方義務
   - 對方義務
   - 期限與里程碑

## 輸出格式

# 合約審閱摘要

## 文件概覽
| 欄位 | 值 |
|-------|-------|
| **合約類型** | {NDA, MSA, SOW, License, etc.} |
| **雙方** | {Party A} 與 {Party B} |
| **生效日期** | {date} |
| **期限** | {duration} |
| **準據法** | {jurisdiction} |

---

## 執行摘要

{2-3 sentence summary of what this contract does and its key implications}

---

## 關鍵條款

### 財務條款
| 條款 | 詳細資料 |
|------|---------|
| **總價值** | {amount} |
| **付款條件** | {Net 30, milestone-based, etc.} |
| **逾期費用** | {if applicable} |
| **價格調整** | {annual increase clause if any} |

### 範圍與交付項目
- {Deliverable 1}
- {Deliverable 2}
- {Deliverable 3}

### 期限與終止
- **初始期限：** {duration}
- **自動續約：** {Yes/No, terms}
- **任意終止：** {notice period}
- **有因終止：** {conditions}

---

## ⚠️ 風險評估

### 高風險項目
| 條款 | 位置 | 疑慮 | 建議 |
|--------|----------|---------|----------------|
| {clause} | Section {n} | {why it's risky} | {suggested action} |

### 中風險項目
| 條款 | 位置 | 疑慮 |
|--------|----------|---------|
| {clause} | Section {n} | {concern} |

### 不尋常條款
- {Any non-standard clauses worth noting}

---

## 📋 我方義務

| 義務 | 期限 | 條款 |
|------------|----------|---------|
| {obligation 1} | {date/trigger} | §{n} |
| {obligation 2} | {date/trigger} | §{n} |
| {obligation 3} | {date/trigger} | §{n} |

---

## 📋 對方義務

| 義務 | 期限 | 條款 |
|------------|----------|---------|
| {obligation 1} | {date/trigger} | §{n} |
| {obligation 2} | {date/trigger} | §{n} |

---

## 重要日期

| 日期 | 事件 | 需要採取的行動 |
|------|-------|-----------------|
| {date} | {event} | {action} |
| {date} | 續約通知期限 | 決定續約或終止 |
| {date} | 合約到期 | {action} |

---

## 談判重點

簽署前可考慮談判下列項目：

1. **{Item 1}:** {current state} → {suggested change}
2. **{Item 2}:** {current state} → {suggested change}
3. **{Item 3}:** {current state} → {suggested change}

---

## 與標準條款比較

| 條款 | 本合約 | 市場標準 | 評估 |
|--------|---------------|-----------------|------------|
| 責任上限 | {amount} | {typical} | {favorable/unfavorable} |
| 賠償 | {scope} | {typical} | {favorable/unfavorable} |
| IP 所有權 | {terms} | {typical} | {favorable/unfavorable} |

---

## ⚠️ 免責聲明

本分析僅供參考，不構成法律意見。
