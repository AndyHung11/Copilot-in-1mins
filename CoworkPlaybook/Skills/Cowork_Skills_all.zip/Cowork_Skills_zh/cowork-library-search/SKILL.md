---
name: cowork-library-search
description: |
  搜尋 ABS GSA SharePoint 網站上的 Copilot Cowork Library，並傳回相符項目，以及指向存放附加技能檔案之 SharePoint 項目頁面的 "Download" 連結。
  支援的篩選條件：category（Skill / Plugin / Prompt）、persona（Knowledge workers, Sales, Management, Executives, Operations 等）、industry（Cross Industry, Legal, Retail 等）、customer-ready 旗標（true/false）、符合 Title 或 Description 的關鍵字，以及用於近期內容的 modified-after 日期（"what's new this week"）。
  當使用者說「搜尋 cowork library」、「在 gallery 找技能」、「有哪些 sales 可用的 plugins」、「列出 executives 的 prompts」、「尋找會議相關 cowork 項目」、「顯示 customer-ready skills」、「retail 的 cowork gallery 有什麼」、「有 managers 用的 plugins 嗎」、「查詢 [topic] 相關 library items」、「這週 cowork library 有什麼新內容」、"search the cowork library", "find skills in the gallery", "what plugins are available for sales", "list prompts for executives", "find cowork items about meetings", "show customer-ready skills", "what's in the cowork gallery for retail", "any plugins for managers", "look up library items about [topic]", or "what's new in the cowork library this week" 時使用。
  請勿使用此技能來 (a) 列出使用者的個人 skills — 請使用 `skills` skill；(b) 描述內建系統 skills — 直接回答；(c) 一般性搜尋 OneDrive 或 SharePoint 檔案 — 改用 `SearchM365` 搭配 `sources=["files"]`。此技能僅限於 Copilot Cowork Library SharePoint 清單。
cowork:
  category: research
  icon: Search
---

# Cowork Library 搜尋

搜尋 Copilot Cowork Library SharePoint 清單，並傳回相符項目與下載連結。

## Library 位置

- **網站:** ABS - Global Solution Architects
- **網站 ID:** `microsoft.sharepoint-df.com,243ad53f-1b98-4147-8162-7b1557299391,8b86e36e-e48e-4fda-9fe8-c1d6eab2b3ab`
- **清單:** Copilot Cowork Library
- **清單 ID:** `list_7` (alias) / `6c667e0a-5882-453e-9127-d70532841e28` (GUID)
- **Gallery URL:** https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/Cowork%20Full%20Gallery.aspx
- **項目檢視模式:** `https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/DispForm.aspx?ID={id}` — 這是 "Download" 目標（可存取附加技能檔案的 SharePoint 頁面）。

## 工作流程

### 步驟 1 — 擷取條件

將使用者要求剖析為結構化篩選條件。支援的條件：

| 條件 | 值 |
|-----------|--------|
| `category` | `Skill`, `Plugin`, `Prompt` |
| `persona` | `Knowledge workers`, `Sales`, `Management`, `Executives`, `Operations`, etc. |
| `industry` | `Cross Industry`, `Legal`, `Retail`, etc. |
| `customer_ready` | `true` / `false` |
| `keyword` | 自由文字 — 與 `Title` 和 `Description` 進行比對（不分大小寫） |
| `modified_after` | ISO 日期（例如 `2026-05-20`）— 只保留 `Modified >= date` 的項目 |

如果使用者只提供主題片語（例如 "find something for meeting follow-ups"），請視為 `keyword`。對於相對近期的說法（"this week", "last 7 days", "since Monday"），請使用使用者的本地時區解析為絕對 ISO 日期，再作為 `modified_after`。如果條件含糊，選擇合理的預設值並繼續 — 不要因要求釐清而中斷。

### 步驟 2 — 查詢清單

使用 `ListListItems` 擷取項目，然後在用戶端篩選。拉取較大的頁面（top=100）— library 規模很小。

```
ListListItems(
  site_id="microsoft.sharepoint-df.com,243ad53f-1b98-4147-8162-7b1557299391,8b86e36e-e48e-4fda-9fe8-c1d6eab2b3ab",
  list_id="list_7",
  top=100
)
```

如果分頁傳回 `next_link`，請先沿著它取得完整集合，再套用篩選條件。

### 步驟 3 — 套用篩選條件

針對每個項目，讀取 `fields` 區塊；只有在**所有**指定條件都相符時才保留該項目：

- `Category` 等於要求的 category（不分大小寫）
- `Persona` 等於要求的 persona（不分大小寫）
- `Industry` 等於要求的 industry（不分大小寫）
- `CustomerReady` 等於要求的布林值
- `keyword` 出現在 `Title` 或 `Description` 任一欄位中（不分大小寫的子字串比對）
- `Modified`（ISO datetime）≥ `modified_after`

如果沒有相符項目，請清楚說明，並建議放寬一項條件（例如移除 industry 篩選或放寬日期範圍）。

### 步驟 4 — 呈現結果

對於有 2 個以上相符項目的結果集，預設透過 `render_ui` 呈現 **Adaptive Card**。如果只有一個相符項目，則退回單行 markdown（單列資料不需要卡片）。

**卡片呈現（2 個以上相符項目）:**

1. 先叫用 `render-ui` skill，載入 schema 與驗證規則，然後呼叫 `render_ui`。
2. 依下列方式建立卡片本文：
   - 開頭 `TextBlock`（`size: Large`, `weight: Bolder`）標題為 `"Cowork Library — N 筆相符"`。
   - 第二個 `TextBlock`（`isSubtle: true`, `wrap: true`）摘要說明已套用的篩選條件，例如 _"篩選條件: category = Skill · persona = Knowledge workers"_。
   - 每個結果一個 `Container`，以 `separator: true` 分隔，每個 Container 包含：
     - 一個 `ColumnSet`，含兩欄：第 1 欄（`width: stretch`）放標題（`TextBlock`, `weight: Bolder`, `size: Medium`）與描述（`TextBlock`, `wrap: true`，以省略符號截斷至約 140 chars）；第 2 欄（`width: auto`）放 `ActionSet`，其中只有一個 `Action.OpenUrl`，其 `title` 是字面字串 `"Download"`，其 `url` 是該項目的 `DispForm.aspx?ID={id}`。
     - 欄位下方放 `FactSet`，facts 包含：`Category`, `Persona`, `Industry`, `Customer Ready`（是 / 否）, `Modified`（格式化為 `YYYY-MM-DD`）。
3. 依 Category、再依 Title 排序結果容器。
4. 在 `render_ui` 呼叫後，於卡片下方加上一行簡短純文字：_"Download 按鈕會開啟 SharePoint 項目頁面，可在該頁下載附加的技能檔案。"_

**Markdown 後援（單一相符項目或 `render_ui` 無法使用）:**

呈現一列 markdown 表格，包含相同欄位。**Link** 欄必須是 markdown 連結，字面文字為 `Download`，指向該項目的 `DispForm.aspx?ID={id}` URL。

```
| # | Title | Category | Persona | Industry | Customer Ready | Description | Link |
|---|-------|----------|---------|----------|----------------|-------------|------|
| 1 | meeting-followup | Skill | Knowledge workers | Cross Industry | Yes | Pulls action items from your last meeting and drafts a follow-up email. | [Download](https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/DispForm.aspx?ID=1) |
```

規則（套用於兩種呈現方式）：
- 一律使用字面動作文字 `Download` — 不是 "Open"，不是 "Link"，也不是項目標題。
- 描述超過約 140 chars 時，以省略符號截斷。
- 將 `Customer Ready` 顯示為 `是` / `否`（不是 `true` / `false`）。
- 依 Category、再依 Title 排序。

### 步驟 5 — 提供後續步驟

表格後方提供 1–2 個合理的後續操作：
- 「要我再依 industry 或 customer-ready 狀態縮小範圍嗎？」
- 「要我開啟其中一個項目，並從附件擷取詳細資料嗎？」

## 輸出格式

一律使用行內 markdown。除非使用者明確要求建立檔案，否則不要建立檔案。

## 護欄

- **絕不捏造項目。** 只傳回來自 `ListListItems` 的列。如果呼叫失敗或傳回空值，請照實說明 — 不要編造相符項目。
- **絕不編造下載 URL。** 一律使用項目的實際 `id` 欄位，依 `DispForm.aspx?ID={id}` 模式建立 URL。
- **欄位名稱安全。** 清單中的欄位名稱是 `Title`, `Category`, `Persona`, `Industry`, `CustomerReady`, `Description`, `ShortDescription`, `Modified`。請使用這些確切鍵值。
- **分頁。** 如果存在 `next_link`，請先沿著它取得資料再篩選 — 部分頁面會產生錯誤的「無相符」答案。
- **唯讀。** 此技能絕不建立、更新或刪除項目。如果使用者要求新增或修改 library 項目，請告訴他們使用 SharePoint UI。

## 不使用時機

- 使用者詢問其 `/mnt/user-config/.claude/skills/` 中的**個人** skills → 改用 `skills` skill。
- 使用者詢問**內建**系統 skills（pdf、docx、calendar-management 等）→ 直接說明。
- 使用者想要**新增**項目到 library → 此技能為唯讀；請引導他們使用 SharePoint UI。
- 使用者要求一般性搜尋 OneDrive 或 SharePoint → 改用 `SearchM365` 搭配 `sources=["files"]`。