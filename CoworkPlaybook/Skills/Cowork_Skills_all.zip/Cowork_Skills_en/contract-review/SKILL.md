---
name: contract-review
description: |
  Analyzes contracts and agreements for key terms, risks, and obligations.
  Use when user asks "review this contract", "analyze agreement", "check contract terms",
  "find liability clause", "summarize this NDA", or "contract risks".
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
---

# Contract Review

Analyze contracts to extract key terms, identify risks, and summarize obligations.

## What This Skill Does

Reviews contracts to provide:
- Executive summary
- Key terms extraction
- Important dates and deadlines
- Risk identification
- Obligation tracking
- Unusual or concerning clauses

## When to Use

- Reviewing vendor agreements
- Analyzing NDAs before signing
- Checking customer contracts
- Renewal decision support
- Due diligence reviews

## Workflow

1. **Document Analysis**
   - Identify contract type
   - Extract parties involved
   - Find effective dates and term

2. **Key Terms Extraction**
   - Payment terms
   - Deliverables and scope
   - Termination conditions
   - Renewal provisions

3. **Risk Assessment**
   - Liability clauses
   - Indemnification
   - Limitation of liability
   - IP ownership
   - Confidentiality scope

4. **Obligation Mapping**
   - Your obligations
   - Their obligations
   - Deadlines and milestones

## Output Format

# Contract Review Summary

## Document Overview
| Field | Value |
|-------|-------|
| **Contract Type** | {NDA, MSA, SOW, License, etc.} |
| **Parties** | {Party A} and {Party B} |
| **Effective Date** | {date} |
| **Term** | {duration} |
| **Governing Law** | {jurisdiction} |

---

## Executive Summary

{2-3 sentence summary of what this contract does and its key implications}

---

## Key Terms

### Financial Terms
| Term | Details |
|------|---------|
| **Total Value** | {amount} |
| **Payment Terms** | {Net 30, milestone-based, etc.} |
| **Late Fees** | {if applicable} |
| **Price Escalation** | {annual increase clause if any} |

### Scope & Deliverables
- {Deliverable 1}
- {Deliverable 2}
- {Deliverable 3}

### Term & Termination
- **Initial Term:** {duration}
- **Auto-Renewal:** {Yes/No, terms}
- **Termination for Convenience:** {notice period}
- **Termination for Cause:** {conditions}

---

## ⚠️ Risk Assessment

### High Risk Items
| Clause | Location | Concern | Recommendation |
|--------|----------|---------|----------------|
| {clause} | Section {n} | {why it's risky} | {suggested action} |

### Medium Risk Items
| Clause | Location | Concern |
|--------|----------|---------|
| {clause} | Section {n} | {concern} |

### Unusual Terms
- {Any non-standard clauses worth noting}

---

## 📋 Your Obligations

| Obligation | Deadline | Section |
|------------|----------|---------|
| {obligation 1} | {date/trigger} | §{n} |
| {obligation 2} | {date/trigger} | §{n} |
| {obligation 3} | {date/trigger} | §{n} |

---

## 📋 Their Obligations

| Obligation | Deadline | Section |
|------------|----------|---------|
| {obligation 1} | {date/trigger} | §{n} |
| {obligation 2} | {date/trigger} | §{n} |

---

## Important Dates

| Date | Event | Action Required |
|------|-------|-----------------|
| {date} | {event} | {action} |
| {date} | Renewal notice deadline | Decide to renew or terminate |
| {date} | Contract expiration | {action} |

---

## Negotiation Points

Consider negotiating these items before signing:

1. **{Item 1}:** {current state} → {suggested change}
2. **{Item 2}:** {current state} → {suggested change}
3. **{Item 3}:** {current state} → {suggested change}

---

## Comparison to Standard Terms

| Clause | This Contract | Market Standard | Assessment |
|--------|---------------|-----------------|------------|
| Liability Cap | {amount} | {typical} | {favorable/unfavorable} |
| Indemnification | {scope} | {typical} | {favorable/unfavorable} |
| IP Ownership | {terms} | {typical} | {favorable/unfavorable} |

---

## ⚠️ Disclaimer

This analysis is for informational purposes only and does not constitute leg