---
name: oof-prep
description: |
  Prepares the user for time off: drafts an out-of-office auto-reply, creates a handoff
  document, and flags meetings during the PTO window for decline or delegation.
  Use when user asks to "prep me for PTO", "going on vacation", "set up my OOF",
  "I'm out next week", "out of office prep", or "handoff before I leave".
  Do NOT use for one-day sick coverage — just set OOF directly with SetAutoReply.
  Do NOT use for permanent role transitions — use stakeholder-comms instead.
cowork:
  category: productivity
  icon: Calendar
---

## Overview

Three-part PTO prep: (1) draft an OOF auto-reply for internal and external audiences,
(2) generate a handoff document summarizing in-flight work and key contacts,
(3) scan meetings in the PTO window and flag which to decline, delegate, or keep.

## When to Use

- User announces they're going on PTO / vacation / leave
- 2+ business days out of office
- Need a handoff for coverage

## When NOT to Use

- Single sick day → just call `SetAutoReply` directly
- Permanent leave / role change → use `stakeholder-comms`
- Already-active OOF → use `GetAutoReplySettings` / `DisableAutoReply`

## Quick Start

```
User: "prep me for PTO May 30 – June 6"
1. Ask for coverage contact and any critical context (one batched question)
2. Draft OOF (internal + external) — show for review
3. ListCalendarView for PTO window → flag meetings (decline / delegate / keep)
4. Build handoff doc: in-flight projects, key contacts, where things live
5. Offer to: enable OOF, send decline notes, post handoff to team channel
```

## Core Instructions

### Step 1: Clarify minimal context

Ask ONE batched `AskUserQuestion` covering:
- Coverage contact (who to point urgent issues to)
- Whether they want strict no-reply or willing to monitor email
- Whether to auto-decline meetings or just flag them

Do not ask multiple round-trips — gather everything in one card.

### Step 2: Draft OOF message

Use `SetAutoReply` with `status="scheduled"`, the PTO start/end, and:
- **Internal message:** warm tone, mentions coverage contact by name, return date
- **External message:** brief, professional, return date, "for urgent matters contact <X>"

Show drafts to user before calling `SetAutoReply`. Never enable OOF without confirmation.

### Step 3: Scan calendar

`ListCalendarView(start=<PTO start>, end=<PTO end>)` — for each event classify:
- **Decline** — recurring routine syncs, optional meetings, anything the user could miss
- **Delegate** — meetings where the coverage contact can attend
- **Keep on calendar (but signal)** — meetings the user organizes; forward to delegate
- **Important — needs action** — meetings the user must handle before/after PTO

Render as a `render-ui` table. Do NOT auto-decline — show recommendations for user approval.

### Step 4: Handoff document

Create a markdown doc with sections:

```markdown
# Handoff — <name> OOF <start> to <end>

## Coverage contact
<Name, email, focus areas>

## In-flight projects
- <Project> — current state, next checkpoint, key contact

## Critical threads to watch
- <Email subject> — what to do if X happens

## Things you can ignore
- <Bucket> — won't matter while I'm out

## Where things live
- <Files, channels, dashboards>
```

Populate from: recent sent mail, accepted meetings the past week, active Teams chats.
Save inline as markdown by default; offer to save as a file or post in a team channel.

### Step 5: Execute on confirmation

Only after the user reviews all three artifacts:
- Call `SetAutoReply` to schedule OOF
- For declines: use `DeclineEvent` with a brief comment for each approved one
- For delegate forwards: use `ForwardEvent`

## Guardrails

- Never enable OOF without showing the draft and getting confirmation
- Never auto-decline meetings — always show the list for approval first
- For external OOF, do NOT name the coverage contact unless user confirms (privacy)
- If the user organizes a recurring series during PTO, suggest forwarding ownership, never cancel by default
