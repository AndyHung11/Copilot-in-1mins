---
name: 30-60-90-plan
description: |
  Creates a structured 30-60-90 day onboarding plan for new hires.
  Use when user asks "create 30-60-90 plan", "onboarding milestones",
  "new hire goals", "ramp-up plan", or "first 90 days plan".
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: onboarding-accelerator
---

# 30-60-90 Day Plan

Generate a structured onboarding plan with clear milestones for the first 90 days.

## What This Skill Does

Creates a phased onboarding plan with:
- Learning objectives for each phase
- Key milestones and deliverables
- Success metrics
- Check-in schedule
- Resources and training

## When to Use

- Manager preparing for new hire
- New employee creating their own plan
- HR standardizing onboarding
- Promoting/transitioning employee to new role

## Required Information

1. Role and level
2. Department/team
3. Key responsibilities
4. Critical skills to develop
5. Key stakeholders to meet

## Workflow

1. **Understand the Role**
   - Review job responsibilities
   - Identify critical success factors
   - Note team dynamics and dependencies

2. **Structure Each Phase**
   - Days 1-30: Learn & Absorb
   - Days 31-60: Contribute & Apply
   - Days 61-90: Own & Deliver

3. **Define Milestones**
   - Specific, measurable goals
   - Key meetings and relationships
   - Training completions
   - First deliverables

4. **Create Check-in Schedule**
   - Weekly 1:1s with manager
   - 30/60/90 day reviews
   - Stakeholder feedback points

## Output Format

# 30-60-90 Day Plan: {Name} - {Role}

## Overview
**Start Date:** {date}
**Manager:** {name}
**Department:** {team}

---

## Days 1-30: Learn & Absorb
**Theme:** Understand the landscape

### Goals
- [ ] Complete all required training
- [ ] Meet with key stakeholders
- [ ] Understand team processes and tools
- [ ] Shadow team members on key workflows

### Key Meetings
| Who | Purpose | By When |
|-----|---------|---------|
| {stakeholder} | Understand {area} | Week 1 |

### Deliverables
- Complete onboarding checklist
- Document initial questions and observations
- Attend all team rituals

### Success Metrics
- Training completion: 100%
- Stakeholder meetings: {n} completed
- Systems access: Fully set up

---

## Days 31-60: Contribute & Apply
**Theme:** Add value with guidance

### Goals
- [ ] Take ownership of first project/task
- [ ] Contribute to team discussions
- [ ] Identify improvement opportunities
- [ ] Build cross-functional relationships

### Deliverables
- Complete first independent deliverable
- Present learnings to team
- Document process improvements

### Success Metrics
- First project delivered
- Positive stakeholder feedback
- Active participation in meetings

---

## Days 61-90: Own & Deliver
**Theme:** Drive results independently

### Goals
- [ ] Own area of responsibility fully
- [ ] Deliver measurable impact
- [ ] Mentor or help others
- [ ] Propose strategic improvements

### Deliverables
- Lead a project or initiative
- Present 90-day accomplishments
- Create 6-month goals

### Success Metrics
- Independent ownership demonstrated
- Quantifiable impact delivered
- Clear path forward established

---

## Check-in Schedule
| Date | Type | Focus |
|------|------|-------|
| Week 1 | Daily sync | Questions, blockers |
| Week 2-4 | Weekly 1:1 | Progress, support |
| Day 30 | 30-day review | Phase 1 assessment |
| Day 60 | 60-day review | Phase 2 assessment |
| Day 90 | 90-day review | Full assessment |
