---
name: exec-summary
description: |
  Condenses a long document, email thread, or transcript into a one-page executive summary.
  Use when user asks to "TL;DR this", "give me the exec summary", "summarize this for
  leadership", "one-page summary", "condense this", or "make this shorter for a busy
  reader".
  Do NOT use for summarizing a meeting transcript — use meeting-intel.
  Do NOT use for inbox-wide summaries — use inbox-triage or daily-briefing.
cowork:
  category: writing
  icon: DocumentText
---

## Overview

Takes a long piece of content (document, thread, transcript, report) and produces a one-page
executive summary aimed at a busy senior reader: what, why it matters, decisions needed,
recommended next step.

## When to Use

- User shares a long file or pastes a long thread and wants the gist
- "TL;DR" of any artifact
- Preparing a brief from a longer source for leadership consumption

## When NOT to Use

- Meeting transcript specifically → use `meeting-intel`
- Multi-source synthesis across emails/Teams → use `daily-briefing` or `weekly-wrap`
- Drafting a *new* exec update from scratch (no source) → use `stakeholder-comms`

## Quick Start

```
User: "TL;DR this" (with attached file or referenced doc)
1. Identify the source — uploaded file, web URL, or pasted text
2. Read it (Read tool for files, ReadFileContent for SharePoint, web_fetch for URLs)
3. Extract: core claim, key evidence, decisions/asks, risks
4. Render the one-page summary inline as markdown
```

## Core Instructions

### Step 1: Locate the source
Priority order:
1. **Attached files** in the message — use `Read` directly on the path
2. **Pasted text** in the message — use it directly
3. **Referenced M365 file** — use `SearchM365` or `ReadFileContent`
4. **URL** — use `web_fetch`
5. If none of the above, ask the user to share the content

### Step 2: Read fully
- For PDFs over 10 pages, use `Read` with `pages` parameter and iterate through the document
- For SharePoint docs: `ReadFileContent` with `download_url` if available
- For long Teams threads: `ListChatMessages` and concatenate
- Read the WHOLE source — don't summarize from the first page

### Step 3: Extract the structure

Pull these into working notes:
- **Core claim** — the single most important point (one sentence)
- **Why it matters** — business impact, stakes
- **Key evidence** — 3–5 supporting facts/numbers/quotes
- **Decisions or asks** — what's being requested of the reader
- **Risks / open issues** — what could go wrong
- **Next step** — recommended action

### Step 4: Output

Render as inline markdown — exec summaries are read, not downloaded, unless user explicitly
asks for a Word doc. Use this structure:

```markdown
# <Document title> — Executive Summary

**Bottom line:** <one-sentence core claim>

## Why it matters
<2–3 sentence stakes/context>

## Key points
- <point 1 with number/fact>
- <point 2>
- <point 3>

## Decisions / asks
- <what is being requested>

## Risks
- <key risk>

## Recommended next step
<one sentence>
```

Target: under 250 words. If the source has critical numbers, cite them with the source line
or page where possible.

### Step 5: Offer file conversion

After showing the inline summary, ask: "Want this as a Word doc or PDF?" Only invoke `docx`
or `pdf` skills if the user says yes.

## Guardrails

- Never fabricate numbers, names, or quotes — every fact must trace to the source
- If the source has gaps or contradictions, surface them in the Risks section, don't paper over
- Keep to one page (≤250 words) — that's the value proposition. If the content can't be
  compressed that much, say so and ask what to prioritize
- For sensitive documents (financials, HR), keep names generic unless the user signals
  the audience is internal
