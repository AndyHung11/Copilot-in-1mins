---
name: meeting-followup
description: |
  Pulls action items and decisions from the user's most recent meeting and drafts a
  follow-up email to attendees. Use when user asks to "send the follow-up from my last call",
  "draft a recap of my last meeting", "follow up on that meeting", "send action items from
  the standup", or "write a recap email to attendees".
  Do NOT use for proactive meeting prep — use meeting-intel or schedule-meeting instead.
  Do NOT use for generic stakeholder updates not tied to a specific meeting — use
  stakeholder-comms instead.
cowork:
  category: communication
  icon: Mail
---

## Overview

Identifies the user's most recently completed meeting, extracts decisions and action items
from its transcript (or, if no transcript exists, from chat/email context around it), then
drafts a recap email to the attendees for the user to review and send.

## When to Use

- User just finished a call and wants to send a recap
- User says "the follow-up", "the recap", "the action items" without naming a meeting
- User wants attendees reminded of what they committed to

## When NOT to Use

- Preparing FOR an upcoming meeting → use `meeting-intel`
- Generic team update untied to a meeting → use `stakeholder-comms`
- Scheduling a new meeting → use `schedule-meeting`

## Quick Start

```
User: "send the follow-up from my last call"
1. ListCalendarView for past 6 hours → pick most recent ended meeting
2. ListMeetingTranscripts for that meeting → GetMeetingTranscript if available
3. If no transcript: search Teams/email around that window for context
4. Extract: decisions, action items (owner + due date), open questions
5. Draft email with CreateDraftMessage to attendees, show for review
```

## Core Instructions

### Step 1: Identify the meeting
- Resolve current time from user context
- Call `ListCalendarView` with start = 8 hours ago, end = now, `is_organizer=false` not set (include both)
- Pick the most recently-ended event the user was an attendee of (skip declined/cancelled)
- If multiple recent meetings, ask the user which one via `AskUserQuestion` with the candidates as options

### Step 2: Get content
- If the event has `onlineMeeting.joinUrl`, call `ListMeetingTranscripts` then `GetMeetingTranscript`
- If no transcript: call `SearchM365` with `sources=["teams","email"]`, scoped to the day, with the meeting subject as query
- If still nothing: tell the user you couldn't find content and offer to draft from the meeting subject + attendees only

### Step 3: Extract structure
Pull from the transcript or context:
- **Decisions** — what was agreed
- **Action items** — owner, task, due date (if mentioned)
- **Open questions** — things still unresolved
- **Next steps** — follow-on meetings or checkpoints

Never invent owners or dates. If unclear, mark as `[owner TBD]`.

### Step 4: Draft email
Use `CreateDraftMessage` with:
- **To:** original attendees (excluding the user)
- **Subject:** `Recap: <meeting subject>`
- **Body** structure:
  ```
  Thanks everyone for joining today's <meeting>. Quick recap below.

  Decisions
  - ...

  Action items
  - <Owner>: <task> — <due date>

  Open questions
  - ...

  Let me know if I missed anything.
  ```

Show the draft to the user and let them edit before sending. Do NOT call `SendDraftMessage`
unless the user explicitly says "send it".

## Guardrails

- Never fabricate action items, owners, or dates not present in the source
- Always create a draft (`CreateDraftMessage`) — never send directly
- If the meeting was private/1:1, confirm before drafting to ensure user wants a written record
- Redact any sensitive personnel discussion (compensation, performance) — flag to user instead
