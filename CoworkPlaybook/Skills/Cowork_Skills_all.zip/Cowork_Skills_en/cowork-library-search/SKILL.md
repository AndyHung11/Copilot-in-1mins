---
name: cowork-library-search
description: |
  Searches the Copilot Cowork Library on the ABS GSA SharePoint site and returns matching items with a "Download" link to the SharePoint item page where the attached skill file lives.
  Filters supported: category (Skill / Plugin / Prompt), persona (Knowledge workers, Sales, Management, Executives, Operations, etc.), industry (Cross Industry, Legal, Retail, etc.), customer-ready flag (true/false), keyword that matches Title or Description, and modified-after date for recency ("what's new this week").
  Use when the user asks to "search the cowork library", "find skills in the gallery", "what plugins are available for sales", "list prompts for executives", "find cowork items about meetings", "show customer-ready skills", "what's in the cowork gallery for retail", "any plugins for managers", "look up library items about [topic]", or "what's new in the cowork library this week".
  Do NOT use this skill to (a) list the user's personal skills — use the `skills` skill; (b) describe built-in system skills — answer directly; (c) search OneDrive or SharePoint files in general — use `SearchM365` with `sources=["files"]` instead. This skill is scoped only to the Copilot Cowork Library SharePoint list.
cowork:
  category: research
  icon: Search
---

# Cowork Library Search

Search the Copilot Cowork Library SharePoint list and return matching items with download links.

## Library Location

- **Site:** ABS - Global Solution Architects
- **Site ID:** `microsoft.sharepoint-df.com,243ad53f-1b98-4147-8162-7b1557299391,8b86e36e-e48e-4fda-9fe8-c1d6eab2b3ab`
- **List:** Copilot Cowork Library
- **List ID:** `list_7` (alias) / `6c667e0a-5882-453e-9127-d70532841e28` (GUID)
- **Gallery URL:** https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/Cowork%20Full%20Gallery.aspx
- **Item view pattern:** `https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/DispForm.aspx?ID={id}` — this is the "Download" target (the SharePoint page where the attached skill file is accessible).

## Workflow

### Step 1 — Capture criteria

Parse the user's request into a structured filter. Supported criteria:

| Criterion | Values |
|-----------|--------|
| `category` | `Skill`, `Plugin`, `Prompt` |
| `persona` | `Knowledge workers`, `Sales`, `Management`, `Executives`, `Operations`, etc. |
| `industry` | `Cross Industry`, `Legal`, `Retail`, etc. |
| `customer_ready` | `true` / `false` |
| `keyword` | Free text — matched (case-insensitive) against `Title` and `Description` |
| `modified_after` | ISO date (e.g. `2026-05-20`) — keep only items with `Modified >= date` |

If the user provided only a topic phrase (e.g. "find something for meeting follow-ups"), treat it as `keyword`. For relative recency phrasings ("this week", "last 7 days", "since Monday"), resolve to an absolute ISO date using the user's local time zone, then use as `modified_after`. If criteria are ambiguous, pick a sensible default and proceed — do not block with a clarification.

### Step 2 — Query the list

Use `ListListItems` to retrieve items, then filter client-side. Pull a generous page (top=100) — the library is small.

```
ListListItems(
  site_id="microsoft.sharepoint-df.com,243ad53f-1b98-4147-8162-7b1557299391,8b86e36e-e48e-4fda-9fe8-c1d6eab2b3ab",
  list_id="list_7",
  top=100
)
```

If pagination returns `next_link`, follow it until the full set is retrieved before applying filters.

### Step 3 — Apply filters

For each item, read the `fields` block and keep the item only if **all** specified criteria match:

- `Category` equals the requested category (case-insensitive)
- `Persona` equals the requested persona (case-insensitive)
- `Industry` equals the requested industry (case-insensitive)
- `CustomerReady` equals the requested boolean
- `keyword` appears in either `Title` or `Description` (case-insensitive substring match)
- `Modified` (ISO datetime) is ≥ `modified_after`

If no items match, say so plainly and suggest relaxing one criterion (e.g. dropping the industry filter or widening the date window).

### Step 4 — Present results

Default to an **Adaptive Card** rendering via `render_ui` for any result set with 2 or more matches. Fall back to a plain markdown line for a single match (a card for one row is overkill).

**Card rendering (2+ matches):**

1. Invoke the `render-ui` skill first so the schema and validation rules are loaded, then call `render_ui`.
2. Build the card body as follows:
   - A leading `TextBlock` (`size: Large`, `weight: Bolder`) with the title `"Cowork Library — N match(es)"`.
   - A second `TextBlock` (`isSubtle: true`, `wrap: true`) summarising the applied filters, e.g. _"Filters: category = Skill · persona = Knowledge workers"_.
   - One `Container` per result, separated with `separator: true`, each containing:
     - A `ColumnSet` with two columns: column 1 (`width: stretch`) holds the title (`TextBlock`, `weight: Bolder`, `size: Medium`) and the description (`TextBlock`, `wrap: true`, truncated to ~140 chars with ellipsis); column 2 (`width: auto`) holds an `ActionSet` with a single `Action.OpenUrl` whose `title` is the literal string `"Download"` and whose `url` is the item's `DispForm.aspx?ID={id}`.
     - Underneath the columns, a `FactSet` with facts: `Category`, `Persona`, `Industry`, `Customer Ready` (Yes / No), `Modified` (formatted as `YYYY-MM-DD`).
3. Sort the result containers by Category, then Title.
4. After the `render_ui` call, add one short line of plain text below the card: _"The Download button opens the SharePoint item page where the attached skill file can be downloaded."_

**Markdown fallback (single match or `render_ui` unavailable):**

Render a one-row markdown table with the same columns. The **Link** column MUST be a markdown link with the literal text `Download`, pointing at the item's `DispForm.aspx?ID={id}` URL.

```
| # | Title | Category | Persona | Industry | Customer Ready | Description | Link |
|---|-------|----------|---------|----------|----------------|-------------|------|
| 1 | meeting-followup | Skill | Knowledge workers | Cross Industry | Yes | Pulls action items from your last meeting and drafts a follow-up email. | [Download](https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/DispForm.aspx?ID=1) |
```

Rules (apply to both renderings):
- Always use the literal action text `Download` — not "Open", not "Link", not the item title.
- Truncate descriptions over ~140 chars with an ellipsis.
- Show `Customer Ready` as `Yes` / `No` (not `true` / `false`).
- Sort by Category, then Title.

### Step 5 — Offer next steps

After the table, offer 1–2 logical follow-ups:
- "Want me to narrow this further by industry or customer-ready status?"
- "Want me to open one of these items and pull details from the attachment?"

## Output Format

Always inline markdown. Do not create a file unless the user explicitly asks for one.

## Guardrails

- **Never fabricate items.** Only return rows that came back from `ListListItems`. If the call fails or returns empty, say so — do not invent matches.
- **Never invent download URLs.** Always construct the URL from the item's actual `id` field using the `DispForm.aspx?ID={id}` pattern.
- **Field-name safety.** Field names in the list are `Title`, `Category`, `Persona`, `Industry`, `CustomerReady`, `Description`, `ShortDescription`, `Modified`. Use these exact keys.
- **Pagination.** If `next_link` is present, follow it before filtering — partial pages produce wrong "no match" answers.
- **Read-only.** This skill never creates, updates, or deletes items. If the user asks to add or modify a library item, tell them to use the SharePoint UI.

## When NOT to Use

- User asks about their **personal** skills in `/mnt/user-config/.claude/skills/` → use the `skills` skill instead.
- User asks about **built-in** system skills (pdf, docx, calendar-management, etc.) → describe those directly.
- User wants to **add** an item to the library → this skill is read-only; direct them to the SharePoint UI.
- User asks to search OneDrive or SharePoint generally → use `SearchM365` with `sources=["files"]` instead.
