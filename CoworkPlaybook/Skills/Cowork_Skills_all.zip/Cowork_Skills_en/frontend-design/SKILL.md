---
name: frontend-design
description: Build distinctive, production-grade frontend interfaces with a strong point of view. Use this skill when the user asks to design or implement a web component, page, landing site, dashboard, marketing site, or any UI surface. Generates working code with intentional aesthetic choices that avoid default AI-template looks.
---

This skill produces frontend code that looks like it was designed, not generated. Every output should have a clear aesthetic identity, polished execution, and details that reward a second look.

The user will describe what they want built — a component, a page, an entire app — and may include context about audience, brand, framework, or constraints. If brand or tone are unspecified, choose a direction and commit to it; do not default to a neutral template.

## Pre-flight: Commit to a Direction

Before writing any code, answer four questions internally:

- **Purpose**: What is this interface for, and who is the user? What action should they take?
- **Tone**: Pick one and commit. Options include — editorial/print-inspired, brutalist/raw HTML, swiss/typographic, retro-terminal, soft neumorphic, glassmorphic/aurora, vaporwave, art nouveau, bauhaus geometric, hand-drawn/sketchy, cyberpunk, monospace utilitarian, luxury/serif-heavy, ransom-note collage, isometric/3D, ambient/nature-inspired. Mix two if they reinforce each other; never blend three.
- **Constraints**: Framework, browser targets, accessibility floor (WCAG AA minimum unless told otherwise), performance budget, responsive breakpoints.
- **The Hook**: What is the one element a visitor will remember and describe to a friend? Every design needs one signature move — a typographic stunt, an unusual layout primitive, an unexpected interaction, a striking color pairing.

**CRITICAL**: Intentionality beats intensity. A restrained design executed with precision is stronger than a loud design executed sloppily. Pick a lane and own it.

## Output Requirements

Every deliverable must be:

- **Working**: real code that runs without modification — no pseudocode, no `// TODO: implement`
- **Accessible**: semantic HTML, keyboard navigable, sufficient contrast, focus states designed (not browser-default)
- **Responsive**: mobile-first or explicitly desktop-only by design choice, never "broken on mobile by accident"
- **Cohesive**: one design system, one motion language, one tonal voice across the whole output
- **Refined**: the small details — letter-spacing on headings, optical alignment, hover states, empty states, loading states — are intentional, not omitted

## Craft Guidelines

- **Typography**: Type is the loudest design choice. Use Google Fonts, Fontshare, or system fallbacks creatively. Pair a characterful display face with a readable text face — e.g. Fraunces + Inter Tight, PP Editorial New + JetBrains Mono, Instrument Serif + Geist, Söhne + Tiempos. Push variable font axes (weight, optical size, slant). Use real typographic detail: hanging punctuation, true small caps, tabular numerals where they belong, ligatures, drop caps on long-form content. Avoid the safe defaults — Inter alone, Roboto, Arial, Helvetica with no opinion.

- **Color**: One dominant color, one or two accents, and a deliberate neutral. Define everything as CSS custom properties. Light, dark, or duotone — decide upfront. Consider unusual palettes: warm off-white + ink black + a single saturated accent; deep navy + cream + brass; near-black + acid green; sand + terracotta + ocean. Avoid the AI tells: indigo-to-purple gradients on white, slate-50 backgrounds with slate-900 text and a blue-600 button.

- **Layout & Composition**: Grids exist to be used intentionally — to align, or to break against deliberately. Try asymmetry, deliberate overlap, oversized type that crops out of its container, sidebars that feel editorial, baseline grids on long-form text. Generous whitespace OR controlled density — pick one. Avoid the "three-column feature card grid abov