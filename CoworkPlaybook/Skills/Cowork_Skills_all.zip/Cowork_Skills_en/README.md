# Copilot Cowork Skill Pack (English)

The original English SKILL.md for 19 Copilot Cowork custom skills.

## How to use
1. Each folder is one skill; the `SKILL.md` inside is the skill itself.
2. Drop the folder into your Cowork skills directory, or upload the `SKILL.md` in Cowork.
3. The folder name must match the `name:` field in the file, or the skill fails to load.

## Skill list
- `30-60-90-plan`
- `contract-review`
- `cowork-cost-estimator`
- `cowork-library-search`
- `data-storyteller`
- `exec-summary`
- `file-organizer`
- `frontend-design`
- `hr-engagement-strategy`
- `inbox-triage`
- `meeting-followup`
- `newsletter-builder`
- `onboarding-checklist`
- `oof-prep`
- `permissions-audit`
- `sharepoint-finder`
- `snow-incident-rca`
- `teams-digest`
- `weekly-wrap`
