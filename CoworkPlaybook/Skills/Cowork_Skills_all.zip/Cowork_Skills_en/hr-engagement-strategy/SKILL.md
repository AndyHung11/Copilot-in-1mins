---
name: hr-engagement-strategy
description: |
  Turns an employee engagement survey export into a full executive deliverable set for HR:
  a five-theme summary, a CEO-ready strategy document with benchmarks, an SLT execution
  deck, a one-page brand-colored infographic, and a Copilot Create / Sora video script.
  Use when the user asks to "analyze our engagement survey", "summarize the engagement
  survey into themes", "build an engagement strategy for the CEO/SLT", "create an HR
  enablement deck", "turn survey results into a presentation", "make an engagement
  infographic", or "write a sales-enablement / Copilot-adoption strategy for HR".
  Emphasizes HRBP, Sales Leader, and L&D roles and Copilot-for-Sales adoption.
  Do NOT use for: scheduling HR meetings (use schedule-meeting), routine HR status emails
  (use stakeholder-comms), or evaluating individual employee performance (refuse).
cowork:
  category: analysis
  icon: People
---

## Overview

This skill runs a five-stage HR pipeline that converts a single engagement survey export
into an executive-ready package. Each stage grounds the next: themes come only from the
real survey data, the strategy builds on those themes, and every downstream deliverable
(deck, infographic, video script) reuses the same strategy so the story stays consistent.

The recurring narrative across all deliverables: identify employees — especially **top
sellers** — who use Copilot in advanced ways, capture their usage patterns, and let
**L&D** turn those into short, time-of-need training that **HRBPs** orchestrate with
**Sales Leadership** to lift revenue. CRM/Salesforce metrics are referenced as the
measurement frame, using user-provided numbers or clearly-marked placeholders — this skill
never pulls live CRM data.

## When to Use

- User uploads an engagement / pulse / culture survey export and wants it analyzed
- User needs a CEO or SLT presentation built from engagement findings
- User wants an HR-to-Sales enablement strategy centered on Copilot adoption
- User asks for the infographic or video script pieces individually

## When NOT to Use

- Scheduling or rescheduling HR meetings — use **schedule-meeting**
- A simple status email or announcement — use **stakeholder-comms**
- Ranking, rating, or comparing individual employees' performance — **refuse politely**
  ("I can't evaluate individual performance; I can summarize team/program outcomes instead")
- Filtering people by any protected characteristic — **refuse**, offer role/team/skill instead

## Quick Start

```
User: "Analyze our engagement survey and build the CEO strategy + SLT deck + infographic + video script"
1. Find the survey file in input/ (Glob input/**/*). If none, ask for it — never invent data.
2. Stage 1 — extract exactly 5 themes from the real survey data (xlsx skill).
3. Stage 2 — write the strategy doc (docx): trends, 3 strategies (short + ≤2yr), exec
   summary, benchmark vs a ~10k-employee peer (deep-research, cited).
4. Stage 3 — build the SLT execution deck (pptx) from the strategy doc.
5. Stage 4 — generate the one-page infographic (company branding, PNG via code).
6. Stage 5 — write the Copilot Create / Sora video script (docx).
7. Confirm each file landed in output/ before reporting done.
```

Create a Task per stage so the user sees progress. Stages 3–5 depend on Stage 2's strategy
content; Stage 1 must complete before Stage 2. Run nothing that needs survey data until the
survey is loaded.

## Core Instructions

### Stage 0 — Locate inputs (always first)

- `Glob input/**/*` to find the survey export (`.xlsx`, `.csv`, `.xls`). Match on names like
  *survey*, *engagement*, *pulse*, *export*.
- If no file is found, **stop and ask** the user to attach it. Do not proceed to Stage 1 on
  invented data. This is a hard gate.
- Ask once (only if unstated) whether they want all five deliverables or a subset.

### Stage 1 — Five key themes (xlsx skill)

- Read the survey with the **xlsx** skill. Inspect columns: question text, scores, free-text
  comments, segments (department, tenure, region).
- Derive **exactly five** themes grounded in the data. Each theme = a short title + the
  quantitative signal behind it (e.g., score, % favorable, top driver) + 1–2 representative
  verbatim snippets **only if** present in the file.
- Compute any number (averages, % favorable, deltas) with a code tool — never by hand.
- If the export lacks a dimension the user expects (e.g., no segment column), say so plainly.
- Output the themes inline as a ranked list; this becomes the spine of Stage 2.

### Stage 2 — Strategy document (docx skill)

Invoke the **docx** skill. Structure:

1. **Executive summary** (half page) — the engagement story in CEO language, leading with
   business impact.
2. **Workforce engagement trends** — the five themes plus recent macro trends in workforce
   engagement (use deep-research / web search for external trends; cite sources).
3. **Benchmark comparison** — our org vs a representative **~10,000-employee** peer set.
   Route this through the **deep-research** agent so every external figure is cited. Where an
   internal figure is unknown, insert a `[Add: our figure]` placeholder — never fabricate.
4. **Three actionable strategies** — a deliberate **mix of short-term and longer-term (up to
   2 years)**, framed **organization-wide**. For each: objective, time horizon, owner, and
   the **organizational metric** it moves (engagement, retention, productivity, revenue).
5. **Tie to org metrics** — explicit benefits to overall organizational metrics for the CEO.

Numbers rule: any total, %, average, or delta embedded in the doc is computed by code, not by
you. Recipients, quotes, and stats are real-or-placeholder, never invented.

### Stage 3 — SLT execution deck (pptx skill)

Invoke the **pptx** skill. Build an **executive-level execution plan** from the Stage 2
strategy (not a re-analysis). Required sections:

- Title + executive summary slide
- The three strategies as an execution roadmap (short-term vs ≤2-year swimlanes)
- **HR ↔ Sales alignment**: how HRBPs partner with Sales Leadership
- **Customized AI training for Sales** using sales-specific scenarios, mapped to the sales
  cycle (prospect → qualify → propose → close → expand)
- **Measurement**: Salesforce CRM + existing sales KPIs as the measurement frame
  (user-provided numbers or placeholders)
- **Economic justification** for Copilot for M365 across all employees — show the model
  structure (cost inputs, productivity/revenue levers, payback) with `[Add: figure]`
  placeholders for any number not supplied. State assumptions explicitly.
- **HRBP as liaison** to Sales Leadership orchestrating the transformation
- Next steps / asks of the SLT

### Stage 4 — One-page infographic (company branding, PNG via code)

Generate a single-page PNG to `output/` using Python (matplotlib/PIL — no image-generation
tool in session, no `pip install`).

**Resolve company branding first, in this order — do not hard-code one company's palette:**

1. **Brand asset the user provided** — if a brand guide, logo, or style file is in `input/`,
   read it and pull the hex colors / logo from there.
2. **Org template library** — check `@org-template-library` (the tenant's branded Office
   templates via `GetOrgTemplateLibrary` / `GetDriveChildren(drive_id="@org-template-library")`).
   Derive accent colors from a `.potx`/`.dotx`, and reuse the logo if present.
3. **Ask, briefly** — if neither yields colors, ask the user for their brand hex values (or a
   logo to sample). Offer a neutral professional default (a single primary + dark neutral +
   light gray) so the run isn't blocked, and label it as a placeholder palette.

Apply the resolved brand colors consistently (primary for headers/accents, neutral for body,
one secondary for callouts). If a logo is available, place it in the header. Never claim a
specific brand's colors unless they were actually resolved from steps 1–2 or supplied by the
user.

Content: the **three strategies** as the backbone, with a clear spotlight on three roles —
**HRBP** (orchestrator/liaison), **Sales Leader** (sponsor), **L&D** (builds training from
identified **sales champions** using Copilot). Emphasize the sales role driving additional
revenue. Keep it scannable: title, 3 strategy blocks, a role band, a metric callout.

### Stage 5 — Video script (docx skill, Copilot Create / Sora ready)

Invoke the **docx** skill. Audience: **SLT + Sales Leadership / CRO**. Deliver a script the
user can paste directly into **Copilot Create or Sora 2.0** — scene-by-scene with: scene
number, on-screen visual direction, voiceover/narration, and approximate duration. Keep total
runtime tight (target 60–120s). Narrative beats to hit:

- Identify **top sellers using Copilot in advanced ways** to win in each sales phase
- The opportunity: turn their patterns into **dynamic sales content** for other sellers
- Content **targeted to each portion of the sales cycle**; **short, time-of-need**, with
  **companion agents + pre-written prompts**
- **Sales Copilot Champions** as peer coaches to less-experienced users
- **HRBP as strategist** with Sales Managers, improving manager feedback/coaching via **OCM**
  to support sellers on Copilot for Sales excellence

## Guardrails

- **Survey-data gate:** never generate themes, stats, or quotes without the real survey file
  loaded. If it's missing or unreadable, say so and ask for re-upload.
- **Never fabricate:** benchmarks, ROI, KPIs, names, dates, quotes. Use `[Add: …]`
  placeholders and route external claims through deep-research with citations.
- **Numbers by code:** compute every embedded figure with a code tool before writing it.
- **No performance evaluation / no protected-characteristic profiling** — refuse and offer a
  compliant alternative.
- **Delivery gate:** after each file stage, `Glob output/**/*` to confirm the file exists
  before telling the user it's ready.
- **One run, staged:** if the user asks for everything at once, produce all five but keep the
  dependency order (survey → themes → strategy → deck/infographic/script).
- **Future plugin path:** this is built to be packaged later into a Cowork plugin (e.g., to add
  a live Salesforce connector and distribute to all HRBPs) via the plugin builder.
