---
name: snow-incident-rca
description: |
  Generates Root Cause Analysis reports from ServiceNow incident data.
  Use when user asks "generate RCA", "root cause analysis", "analyze this incident",
  "RCA report", "incident postmortem", "5 whys analysis", or "what caused this incident".
  User provides incident data by pasting, attaching export, or describing the incident.
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
  requires-connector: false
---

# ServiceNow Incident RCA Generator

Generate comprehensive Root Cause Analysis reports from ServiceNow incident data - no server deployment required.

## How This Works

1. User provides incident data (paste, attach, or describe)
2. Skill analyzes the data
3. Generates formatted RCA report with CMDB references

## No Server Required

This skill works with data you provide directly:
- Paste incident details from ServiceNow
- Attach exported CSV/Excel
- Copy from ServiceNow form
- Describe the incident verbally

## When to Use

- Post-incident reviews
- Major incident analysis
- Problem management
- Compliance documentation
- Service improvement

## How to Provide Data

### Option 1: Paste Incident Fields
Copy these fields from ServiceNow:
- Incident Number
- Short Description
- Description
- Priority / Impact / Urgency
- State
- Opened / Resolved dates
- Assignment Group / Assigned To
- Configuration Item (CI)
- Resolution Notes
- Work Notes (key entries)

### Option 2: Attach Export
Export from ServiceNow as CSV or Excel and attach the file.

### Option 3: Describe the Incident
Tell me:
- What happened?
- When did it start/end?
- What was affected?
- How was it resolved?
- What systems/CIs were involved?

## Workflow

1. **Parse Incident Data**
   - Extract key fields
   - Identify affected CI
   - Note timeline

2. **Structure Analysis**
   - Impact assessment
   - Timeline reconstruction
   - CI relationship mapping

3. **Generate RCA**
   - 5 Whys framework
   - Contributing factors
   - Recommendations

4. **Output Report**
   - Formatted markdown
   - Ready for documentation

## Output Format

# Root Cause Analysis Report

## Incident Overview

| Field | Value |
|-------|-------|
| **Incident Number** | {from provided data} |
| **Short Description** | {from provided data} |
| **Priority** | {P1/P2/P3/P4/P5} |
| **Impact** | {1-High/2-Medium/3-Low} |
| **Urgency** | {1-High/2-Medium/3-Low} |
| **State** | {New/In Progress/Resolved/Closed} |
| **Opened** | {date/time} |
| **Resolved** | {date/time} |
| **Duration** | {calculated} |
| **Assignment Group** | {group name} |
| **Assigned To** | {person} |
| **Caller/Affected User** | {user} |

---

## Impact Summary

### Business Impact
- **Users Affected:** {number or scope}
- **Services Affected:** {list services}
- **Business Processes Impacted:** {processes}
- **Financial Impact:** {if known}

### Technical Impact
- **Systems Affected:** {list}
- **Data Impact:** {none/read-only/data loss}
- **Integration Impact:** {downstream effects}

---

## Configuration Item (Affected CI)

| Attribute | Value |
|-----------|-------|
| **CI Name** | {from data or ask user} |
| **CI Class** | {Server/Application/Database/Network/Service} |
| **Environment** | {Production/Staging/Dev} |
| **Business Service** | {service name} |
| **Support Group** | {owning team} |

### CMDB Relationships
If user provides CI relationships:

**Upstream (This CI depends on):**
- {Parent CI 1}
- {Parent CI 2}

**Downstream (Depends on this CI):**
- {Child CI 1}
- {Child CI 2}

---

## Timeline

| Time | Event | Source |
|------|-------|--------|
| {time} | First symptom/alert | {monitoring/user report} |
| {time} | Incident created | ServiceNow |
| {time} | Team engaged | Assignment |
| {time} | Root cause identified | Investigation |
| {time} | Fix applied | Work notes |
| {time} | Service restored | Verification |
| {time} | Incident resolved | ServiceNow |

---

## Root Cause Analysis

### What Happened
{Detailed description of the incident based on provided data}

### Immediate Cause
{The direct trigger that caused the incident}

### Contributing Factors
| Factor | Category | Details |
|--------|----------|---------|
| {factor 1} | {Process/Tech/People/External} | {description} |
| {factor 2} | {category} | {description} |
| {factor 3} | {category} | {description} |

### 5 Whys Analysis

1. **Why did {incident symptom} occur?**
   → Because {immediate cause}

2. **Why did {immediate cause} happen?**
   → Because {contributing factor 1}

3. **Why did {contributing factor 1} happen?**
   → Because {contributing factor 2}

4. **Why did {contributing factor 2} happen?**
   → Because {underlying cause}

5. **Why did {underlying cause} happen?**
   → Because **{ROOT CAUSE}**

### Root Cause Statement
**{Clear, concise statement of the fundamental root cause}**

---

## Resolution

### How It Was Fixed
{Description of the resolution from provided data}

### Resolution Category
- [ ] Configuration change
- [ ] Code fix
- [ ] Infrastructure change
- [ ] Restart/reboot
- [ ] Rollback
- [ ] Vendor fix
- [ ] Process change
- [ ] Other: {specify}

### Verification
{How was the fix verified to be working?}

---

## Recommendations

### Immediate Actions (This Week)
| # | Action | Owner | Priority | Due |
|---|--------|-------|----------|-----|
| 1 | {specific action} | {assign} | High | {date} |
| 2 | {specific action} | {assign} | High | {date} |

### Short-term Improvements (This Month)
| # | Improvement | Category | Effort |
|---|-------------|----------|--------|
| 1 | {improvement} | {Process/Tech/Monitoring} | {H/M/L} |
| 2 | {improvement} | {category} | {effort} |

### Long-term Improvements (This Quarter)
| # | Improvement | Category | Effort |
|---|-------------|----------|--------|
| 1 | {strategic improvement} | {category} | {effort} |

---

## Prevention

### How to Prevent Recurrence
1. {Prevention measure 1}
2. {Prevention measure 2}
3. {Prevention measure 3}

### Monitoring Improvements
| What to Monitor | Alert Threshold | Owner |
|-----------------|-----------------|-------|
| {metric} | {threshold} | {team} |

### Process Changes
- {Process change 1}
- {Process change 2}

---

## Related Records

### Problem Ticket
**Create Problem?** Yes / No
**Problem Statement:** {if yes, suggested problem description}

### Change Requests
If changes are needed to prevent recurrence:
| Change | Type | Risk | Target Date |
|--------|------|------|-------------|
| {change} | {Normal/Standard/Emergency} | {H/M/L} | {date} |

### Knowledge Article
**Create KB?** Yes / No
**Suggested Title:** {title}
**Key Points:** {what to document}

---

## Lessons Learned

1. **What went well:**
   - {positive aspect of response}
   - {another positive}

2. **What could improve:**
   - {improvement area}
   - {another area}

3. **Key takeaway:**
   {Single most important lesson from this incident}

---

## Appendix

### Work Notes Summary
{Key work notes from incident if provided}

### Attachments Referenced
{List any attachments or evidence}

### Participants
| Role | Name |
|------|------|
| Incident Manager | {name} |
| Technical Lead | {name} |
| Resolver | {name} |

---

## Sign-off

| Role | Name | Date |
|------|------|------|
| RCA Author | | |
| Technical Reviewer | | |
| Service Owner | | |

---

*Generated by ServiceNow RCA Skill for Copilot Cowork*

## Example Prompts

"Generate RCA for this incident: [paste incident details]"

"Create root cause analysis - incident INC0010001, server crashed due to memory leak, affected 500 users for 2 hours"

"Analyze this incident and create RCA report [attach CSV export]"

"5 whys analysis for a database outage that happened yesterday"
