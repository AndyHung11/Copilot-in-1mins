---
name: teams-digest
description: |
  Summarizes Teams channels and chats you may have missed.
  Use when user asks "what did I miss in Teams", "Teams summary", "channel updates",
  "catch me up on Teams", "unread Teams messages", or "Teams digest".
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: teams-hub
  m365-services: [Teams, Graph]
---

# Teams Digest

Get a summary of Teams activity across channels and chats.

## M365 Integration

- **Microsoft Teams:** Channel posts, chat messages, reactions
- **Microsoft Graph:** Activity feed, mentions, replies

## What This Skill Does

Summarizes:
- Unread channel posts by importance
- Direct messages requiring attention
- @mentions and replies to you
- Key decisions and announcements
- Action items from conversations

## When to Use

- Returning from PTO or time off
- Morning catch-up routine
- After being in back-to-back meetings
- End of day review
- Before team meetings

## Workflow

1. **Scan Activity**
   - Check all channels you're a member of
   - Review direct messages and group chats
   - Find @mentions and replies

2. **Prioritize**
   - Urgent/important messages first
   - Messages requiring response
   - FYI items last

3. **Summarize**
   - Extract key points
   - Identify action items
   - Note decisions made

## Output Format

# Teams Digest

**Period:** {timeframe, e.g., "Last 24 hours" or "Since Monday"}
**Last checked:** {timestamp}

---

## 🔴 Requires Your Attention

### @Mentions
| Time | Channel/Chat | From | Message |
|------|--------------|------|---------|
| {time} | {location} | {person} | {summary + link} |

### Direct Messages Awaiting Reply
| From | Preview | Time |
|------|---------|------|
| {name} | {message preview} | {time} |

### Replies to Your Posts
| Thread | Latest Reply | From |
|--------|--------------|------|
| {topic} | {summary} | {name} |

---

## 📢 Important Updates by Channel

### #{channel-name-1}
**Activity level:** {High/Medium/Low} ({n} messages)

**Key posts:**
- **{Author}:** {Summary of important post}
  - Reactions: {👍 n, etc.}
  - {Link to message}

- **{Author}:** {Summary of another post}
  - {Link}

**Decisions made:**
- {Decision 1}
- {Decision 2}

---

### #{channel-name-2}
**Activity level:** {level}

**Key posts:**
- {summaries}

---

## 💬 Group Chats

### {Chat name or participants}
**Messages:** {n} new
**Summary:** {What was discussed}
**Action items:** {Any tasks mentioned}

---

## 📋 Action Items Found

| Item | Source | Assigned To | Deadline |
|------|--------|-------------|----------|
| {task} | #{channel} | {you/person} | {if mentioned} |
| {task} | {chat} | {person} | {date} |

---

## 📊 Activity Summary

| Channel | New Posts | Your Participation |
|---------|-----------|-------------------|
| #{channel1} | {n} | {replied/reacted/none} |
| #{channel2} | {n} | {status} |
| #{channel3} | {n} | {status} |

---

## 🎯 Suggested Actions

1. **Reply to {person}** in #{channel} about {topic}
2. **Acknowledge** {important announcement}
3. **Follow up** on {thread}

---

## ℹ️ FYI Only (Low Priority)

{Brief list of lower-priority updates that don't require action}

- #{channel}: {brief summary}
- #{channel}: {brief summary}
