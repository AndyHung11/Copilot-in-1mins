---
name: data-storyteller
description: |
  Transforms data and spreadsheets into narrative insights and recommendations.
  Use when user asks "analyze this data", "what does this spreadsheet show",
  "insights from this Excel", "explain these numbers", or "data summary".
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
---

# Data Storyteller

Transform raw data into compelling narratives with actionable insights.

## What This Skill Does

Analyzes data to provide:
- Plain-English summary
- Key trends and patterns
- Anomalies and outliers
- Comparative analysis
- Actionable recommendations
- Suggested visualizations

## When to Use

- Making sense of spreadsheet data
- Preparing data for presentations
- Finding insights in reports
- Explaining metrics to stakeholders
- Monthly/quarterly data reviews

## Workflow

1. **Understand the Data**
   - What does each column represent?
   - What time period does it cover?
   - What's the business context?

2. **Identify Patterns**
   - Trends (up, down, stable)
   - Seasonality or cycles
   - Correlations between variables

3. **Find the Story**
   - What's the headline?
   - What's surprising?
   - What's concerning?
   - What's the opportunity?

4. **Make it Actionable**
   - So what?
   - Now what?
   - What decisions does this inform?

## Output Format

# Data Analysis: {Dataset Name}

## The Headline

**{One sentence that captures the most important finding}**

---

## Executive Summary

{2-3 paragraph narrative summary written for a non-technical audience. Focus on what the data means, not just what it shows.}

---

## Key Metrics at a Glance

| Metric | Current | Previous | Change | Trend |
|--------|---------|----------|--------|-------|
| {metric 1} | {value} | {value} | {+/-}% | {↑↓→} |
| {metric 2} | {value} | {value} | {+/-}% | {↑↓→} |
| {metric 3} | {value} | {value} | {+/-}% | {↑↓→} |

---

## What the Data Shows

### Trend 1: {Title}
{Description of the trend with specific numbers}

**Why it matters:** {Business implication}

### Trend 2: {Title}
{Description of the trend with specific numbers}

**Why it matters:** {Business implication}

### Trend 3: {Title}
{Description of the trend with specific numbers}

**Why it matters:** {Business implication}

---

## 🔍 Notable Findings

### Highlights (Good News)
- {Positive finding 1 with data point}
- {Positive finding 2 with data point}

### Concerns (Watch These)
- ⚠️ {Concerning finding 1 with data point}
- ⚠️ {Concerning finding 2 with data point}

### Anomalies (Investigate)
- ❓ {Unexpected data point that needs explanation}

---

## Comparisons

### vs. Previous Period
{How does this compare to last month/quarter/year?}

### vs. Target/Goal
| Metric | Actual | Target | Gap |
|--------|--------|--------|-----|
| {metric} | {value} | {value} | {+/-} |

### vs. Benchmark
{How does this compare to industry/competitor benchmarks if known?}

---

## Correlations & Relationships

{Any interesting relationships between variables}

- When {X} increases, {Y} tends to {behavior}
- {Variable A} and {Variable B} appear {correlated/uncorrelated}

---

## 📊 Recommended Visualizations

1. **{Chart type}** - to show {what insight}
2. **{Chart type}** - to show {what insight}
3. **{Chart type}** - to show {what insight}

---

## 💡 Recommendations

Based on this analysis:

1. **{Action 1}**
   - Why: {rationale from data}
   - Impact: {expected outcome}

2. **{Action 2}**
   - Why: {rationale from data}
   - Impact: {expected outcome}

3. **{Action 3}**
   - Why: {rationale from data}
   - Impact: {expected outcome}

---

## Questions This Raises

- {Question that the data prompts but doesn't answer}
- {Additional data that would be helpful}
- {Follow-up analysis to consider}

---

## Data Quality Notes

- **Completeness:** {Any missing data?}
- **Timeframe:** {What period does this cover?}
- **Caveats:** {Any limitations to note?}