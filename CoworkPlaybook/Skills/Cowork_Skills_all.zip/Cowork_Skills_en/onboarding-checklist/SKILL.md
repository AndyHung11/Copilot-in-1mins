---
name: onboarding-checklist
description: |
  Creates a comprehensive onboarding checklist tracking all tasks across IT, HR, and team setup.
  Use when user asks "onboarding checklist", "new hire tasks", "onboarding tracker",
  "what do I need to set up", or "onboarding status".
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: onboarding-accelerator
---

# Onboarding Checklist

Generate and track a complete onboarding checklist for new hires.

## What This Skill Does

Creates a comprehensive checklist covering:
- Pre-arrival preparation
- Day 1 essentials
- Week 1 tasks
- First month milestones
- Compliance and training requirements

## When to Use

- Preparing for incoming employee
- New hire tracking their own progress
- Manager ensuring nothing falls through cracks
- HR auditing onboarding completion

## Required Information

1. New hire name and role
2. Department
3. Start date
4. Location (remote/hybrid/onsite)
5. Any role-specific requirements

## Output Format

# Onboarding Checklist: {Name}
**Role:** {title}
**Start Date:** {date}
**Manager:** {manager}
**Status:** {X}% Complete

---

## Pre-Arrival (Before Day 1)

### IT Setup
- [ ] Laptop ordered and configured
- [ ] Email account created
- [ ] Microsoft 365 license assigned
- [ ] Teams account provisioned
- [ ] Security groups added
- [ ] VPN access configured
- [ ] Required software installed

### HR & Admin
- [ ] Offer letter signed
- [ ] Background check complete
- [ ] I-9 / work authorization
- [ ] Benefits enrollment sent
- [ ] Payroll setup complete
- [ ] Emergency contact collected
- [ ] Org announcement drafted

### Workspace
- [ ] Desk/office assigned (if onsite)
- [ ] Building access badge
- [ ] Parking arranged
- [ ] Home office stipend (if remote)

### Team Prep
- [ ] Buddy assigned
- [ ] First week meetings scheduled
- [ ] Team notified of start date
- [ ] Welcome message drafted

---

## Day 1

### Morning
- [ ] Welcome meeting with manager
- [ ] Laptop and credentials working
- [ ] Email accessible
- [ ] Teams logged in
- [ ] Building/office tour (or virtual tour)

### Afternoon
- [ ] HR paperwork session
- [ ] Benefits overview
- [ ] IT security training
- [ ] Meet the team
- [ ] Lunch with buddy

### End of Day
- [ ] Calendar populated with key meetings
- [ ] Knows how to get help
- [ ] Has 1:1 scheduled with manager
- [ ] Feels welcomed!

---

## Week 1

### Access & Tools
- [ ] All required systems accessible
- [ ] Relevant SharePoint sites shared
- [ ] Added to team channels
- [ ] Calendar synced with team
- [ ] Can join video calls

### Meetings & People
- [ ] 1:1 with manager
- [ ] Met direct team members
- [ ] Introduced to key stakeholders
- [ ] Attended first team meeting
- [ ] Daily check-ins with buddy

### Learning
- [ ] Reviewed team documentation
- [ ] Completed required compliance training
- [ ] Understands team goals and priorities
- [ ] Knows where to find help

---

## First 30 Days

### Training & Compliance
- [ ] Security awareness training
- [ ] Code of conduct acknowledgment
- [ ] Role-specific certifications started
- [ ] Product/service overview complete
- [ ] Tools training complete

### Integration
- [ ] 30-day check-in with manager
- [ ] Feedback collected from buddy
- [ ] Cross-functional introductions made
- [ ] First contribution/deliverable
- [ ] 30-60-90 plan reviewed

### Administrative
- [ ] Benefits elections finalized
- [ ] Direct deposit confirmed
- [ ] Time tracking set up
- [ ] Expense system access
- [ ] Travel profile (if needed)

---

## Progress Summary

| Category | Complete | Total | Status |
|----------|----------|-------|--------|
| IT Setup | _ | _ | ⬜ |
| HR & Admin | _ | _ | ⬜ |
| Week 1 | _ | _ | ⬜ |
| Training | _ | _ | ⬜ |
| **Overall** | _ | _ | **_%** |
