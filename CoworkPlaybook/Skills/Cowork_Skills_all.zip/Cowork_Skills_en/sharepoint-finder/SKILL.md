---
name: sharepoint-finder
description: |
  Searches SharePoint and OneDrive to find documents, files, and information.
  Use when user asks "find document", "search SharePoint", "where is the file",
  "look for", "find the presentation", or "locate the spreadsheet".
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
  plugin: document-intelligence
  m365-services: [SharePoint, OneDrive, Graph, Search]
---

# SharePoint Finder

Search across SharePoint sites and OneDrive to locate files and information.

## M365 Integration

- **SharePoint:** Site content, document libraries, lists
- **OneDrive:** Personal files and shared items
- **Microsoft Search:** Unified search across M365
- **Graph:** File metadata, sharing info, recent activity

## What This Skill Does

Helps find:
- Documents by name, content, or topic
- Files by type (presentations, spreadsheets, etc.)
- Recent or frequently accessed files
- Files shared with or by specific people
- Content within specific sites or libraries

## When to Use

- Can't remember where a file is saved
- Looking for documents on a topic
- Finding files shared by someone
- Locating the latest version of a document
- Searching for templates or examples

## Search Strategies

1. **By Name:** Exact or partial filename
2. **By Content:** Words or phrases inside documents
3. **By Metadata:** Author, date, file type
4. **By Location:** Specific site or library
5. **By Activity:** Recently modified or shared

## Output Format

# Search Results

## Query
**Looking for:** {user's search intent}
**Search terms:** {actual search query used}
**Scope:** {All M365 / SharePoint / OneDrive / Specific site}

---

## 🎯 Best Matches

### 1. {Document Title}
| Property | Value |
|----------|-------|
| **Type** | {Word, Excel, PowerPoint, PDF, etc.} |
| **Location** | {Site > Library > Folder} |
| **Modified** | {date} by {person} |
| **Size** | {size} |

**Preview:** {First few lines of content or description}

**Actions:** [Open]({link}) | [Share]({link}) | [Copy link]({link})

---

### 2. {Document Title}
{Same structure}

---

### 3. {Document Title}
{Same structure}

---

## 📁 Related Locations

These locations might have what you're looking for:

| Site/Library | Description | Link |
|--------------|-------------|------|
| {Site name} | {what it contains} | [Open]({link}) |
| {Library name} | {description} | [Open]({link}) |

---

## 🕐 Recent Activity

Files you or your team recently worked on matching this search:

| File | Action | When | By |
|------|--------|------|-------|
| {file} | {Modified/Viewed/Shared} | {time} | {person} |

---

## 🔍 Search Tips

If these results aren't what you need, try:

1. **More specific:** Add "{suggested term}"
2. **By type:** "filetype:pptx {topic}"
3. **By author:** "author:{name}"
4. **By date:** "modified:last week"
5. **In location:** Search within {suggested site}

---

## No Results?

If the file doesn't appear in search:
- It may be in a private OneDrive (not shared with you)
- It might be newly created (search indexes can lag)
- Check if you have access to the site/library
- Try alternative spellings or related terms

---

## Quick Actions

- 🆕 **Create new document** in {suggested location}
- 📤 **Request access** to {restricted location}
- 👤 **Ask {person}** who might have this file