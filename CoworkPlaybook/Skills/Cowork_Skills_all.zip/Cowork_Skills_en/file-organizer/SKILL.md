---
name: file-organizer
description: |
  Suggests organization and cleanup for OneDrive and SharePoint files.
  Use when user asks "organize my files", "clean up OneDrive", "file structure",
  "folder organization", "declutter files", or "organize documents".
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: document-intelligence
  m365-services: [OneDrive, SharePoint, Graph]
---

# File Organizer

Analyze and suggest organization for your M365 files.

## M365 Integration

- **OneDrive:** Personal file analysis
- **SharePoint:** Library organization
- **Microsoft Graph:** File metadata, activity

## What This Skill Does

Provides:
- Current state analysis
- Duplicate file detection
- Old/stale file identification
- Folder structure recommendations
- Naming convention suggestions
- Cleanup action plan

## When to Use

- OneDrive is cluttered and hard to navigate
- Starting fresh organization
- Annual file cleanup
- Before migrating files
- Setting up new project structure

## Output Format

# File Organization Report

## Current State Analysis

### Location: {OneDrive or SharePoint site}

| Metric | Value |
|--------|-------|
| **Total Files** | {count} |
| **Total Size** | {GB} |
| **Folders** | {count} |
| **Max Folder Depth** | {levels} |
| **Files in Root** | {count} ⚠️ {if high} |

---

## 📊 File Distribution

### By Type
| Type | Count | Size | % of Total |
|------|-------|------|------------|
| Documents (.docx, .pdf) | {n} | {size} | {%} |
| Spreadsheets (.xlsx) | {n} | {size} | {%} |
| Presentations (.pptx) | {n} | {size} | {%} |
| Images | {n} | {size} | {%} |
| Other | {n} | {size} | {%} |

### By Age
| Age | Count | Recommendation |
|-----|-------|----------------|
| < 30 days | {n} | Active - keep organized |
| 30-90 days | {n} | Review for relevance |
| 90-365 days | {n} | Archive candidates |
| > 1 year | {n} | Archive or delete |

### By Size (Largest Files)
| File | Size | Location | Last Accessed |
|------|------|----------|---------------|
| {filename} | {size} | {path} | {date} |
| {filename} | {size} | {path} | {date} |
| {filename} | {size} | {path} | {date} |
