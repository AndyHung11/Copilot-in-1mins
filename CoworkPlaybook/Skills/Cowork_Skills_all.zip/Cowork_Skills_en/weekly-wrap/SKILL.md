---
name: weekly-wrap
description: |
  Aggregates the user's sent emails, accepted meetings, and Teams posts from the past week
  into a Friday status note. Use when user asks to "wrap my week", "weekly wrap", "write my
  weekly status", "what did I do this week", "Friday status note", or "summarize my week".
  Do NOT use for daily summaries — use daily-briefing instead.
  Do NOT use for forward-looking planning — this skill is retrospective only.
cowork:
  category: productivity
  icon: Flag
---

## Overview

Pulls the user's activity across Outlook (sent mail), calendar (accepted meetings), and Teams
(channel + chat posts) for the current work week, then produces a structured status note
the user can post to a team channel, email to a manager, or keep as a personal log.

## When to Use

- End-of-week status writing
- Catching up on what you accomplished
- Building a manager update or team digest from the week's activity

## When NOT to Use

- "What did I miss today" / morning briefing → use `daily-briefing`
- Multi-week or quarterly reports → use `stakeholder-comms`
- Single-meeting recap → use `meeting-followup`

## Quick Start

```
User: "wrap my week"
1. Compute week range (Monday 00:00 → now) in user's timezone
2. In parallel:
   - ListMessages with folder_id=sentitems, received_after=<Monday>
   - ListCalendarView for the same window, is_organizer filter both ways
   - SearchM365 sources=["teams"], from_user=<user email>, after=<Monday>
3. Group results into themes (projects, topics, people)
4. Produce a structured Friday status note
```

## Core Instructions

### Step 1: Resolve week range
- Use the user's current local time
- Week starts Monday 00:00 in user's timezone, ends now
- If it's Monday morning, ask whether they mean last week or the current partial week

### Step 2: Gather data in parallel
Run these three tool calls concurrently:
- `ListMessages(folder_id="sentitems", received_after=<Monday ISO>, top=100)`
- `ListCalendarView(start=<Monday>, end=<now>, top=50)` — keep only events the user attended (not declined)
- `SearchM365(sources=["teams"], from_user=<user email>, after=<Monday>, response_length="long")`

Follow `next_link` if any of these signal more data.

### Step 3: Classify and group
Group activity by theme. Detect themes from recurring subjects, attendee overlap, or channel names.
Typical buckets:
- **Projects shipped / progressed**
- **Key meetings**
- **Decisions made**
- **People I engaged with**

### Step 4: Output format

```markdown
# Week of <Mon date> – <Fri date>

## Highlights
- 3–5 bullets, most important things

## What I worked on
- Grouped by project/theme

## Meetings of note
- Only meetings with outcomes (not routine syncs)

## Next week
- 2–3 things rolling forward (only if obvious from open threads)
```

Render inline as markdown by default. If user asks for a file or wants to share it, offer to
draft a Teams post (`PostMessage`) or email (`CreateDraftMessage`) — never send without review.

## Guardrails

- Never include private appointments (sensitivity=private) — show only as time block
- Never include personnel/HR/compensation discussion in the public summary
- Never fabricate accomplishments — if a week was light, say so
- Default to inline markdown; only create a file or send a message on explicit request
