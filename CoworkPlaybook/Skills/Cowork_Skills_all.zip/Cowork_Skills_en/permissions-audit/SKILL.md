---
name: permissions-audit
description: |
  Reviews sharing and permissions for files and SharePoint sites.
  Use when user asks "who has access", "check permissions", "sharing audit",
  "who can see this file", "review access", or "permissions report".
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: document-intelligence
  m365-services: [SharePoint, OneDrive, Graph, Entra ID]
---

# Permissions Audit

Review and report on file and site sharing permissions.

## M365 Integration

- **SharePoint:** Site permissions, library settings
- **OneDrive:** Personal sharing settings
- **Microsoft Graph:** Sharing links, access details
- **Entra ID:** Group memberships, guest users

## What This Skill Does

Analyzes and reports:
- Who has access to files/folders/sites
- Types of access (view, edit, owner)
- External sharing status
- Sharing links (anonymous, org-wide)
- Permission inheritance
- Potential security concerns

## When to Use

- Before sharing sensitive documents
- Regular security reviews
- Offboarding employees
- Compliance audits
- Investigating unexpected access

## Output Format

# Permissions Audit Report

## Audit Target

| Property | Value |
|----------|-------|
| **Item** | {file/folder/site name} |
| **Type** | {File/Folder/Document Library/Site} |
| **Location** | {path} |
| **Owner** | {name} |
| **Created** | {date} |
| **Last Modified** | {date} |

---

## Access Summary

| Access Type | Count |
|-------------|-------|
| Owners | {n} |
| Editors | {n} |
| Viewers | {n} |
| External Users | {n} |
| Sharing Links | {n} |

**Overall Risk Level:** {🟢 Low / 🟡 Medium / 🔴 High}

---

## Direct Access

### Owners (Full Control)
| User/Group | Type | Source |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

### Editors (Can Edit)
| User/Group | Type | Source |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

### Viewers (Can View)
| User/Group | Type | Source |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

---

## 🔗 Sharing Links

| Link Type | Scope | Created By | Expiration |
|-----------|-------|------------|------------|
| {Anyone/Organization/Specific people} | {View/Edit} | {name} | {date or Never} |

### ⚠️ Anonymous Links
{List of "Anyone with the link" shares - security concern}

---

## 👥 External Sharing

### Guest Users
| Email | Access Level | Invited By | Date |
|-------|--------------|------------|------|
| {email} | {level} | {name} | {date} |

### External Domains
| Domain | Users | Risk |
|--------|-------|------|
| {domain.com} | {n} | {assessment} |

---

## 🏢 Group Access

| Group | Members | Access Level |
|-------|---------|--------------|
| {group name} | {n} members | {level} |

**Notable group memberships:**
- {Group} includes {notable members}

---

## 📊 Permission Inheritance

```
{Site/Library}
├── 📁 {Folder 1} - Inherits
│   └── 📄 {File} - Inherits
├── 📁 {Folder 2} - ⚠️ Unique permissions
│   └── 📄 {File} - Inherits from folder
└── 📄 {File} - ⚠️ Unique permissions
```

---

## ⚠️ Security Concerns

### High Priority
- 🔴 {Concern - e.g., "Anonymous link to sensitive file"}
- 🔴 {Concern}

### Medium Priority
- 🟡 {Concern - e.g., "External user with edit access"}
- 🟡 {Concern}

### Recommendations
1. **{Action}** - {reason}
2. **{Action}** - {reason}
3. **{Action}** - {reason}

---

## Recent Permission Changes

| Date | Change | Made By |
|------|--------|---------|
| {date} | {what changed} | {who} |

---

## Compliance Notes

- **External sharing:** {Enabled/Disabled} at site level
- **Guest access policy:** {policy status}
- **Sensitivity label:** {if applied}
- **Retention policy:** {if applied}

---

## Quick Actions

- 🔒 **Remove external access** to {items}
- ⏱️ **Set expiration** on sharing links
- 👤 **Remove** {user} access
- 📧 **Notify owner** about {concern}