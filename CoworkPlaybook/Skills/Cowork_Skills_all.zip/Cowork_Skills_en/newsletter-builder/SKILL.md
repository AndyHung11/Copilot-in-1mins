---
name: newsletter-builder
description: |
  Creates structured newsletter drafts for internal or external audiences.
  Use when user asks "write newsletter", "team update email", "monthly digest",
  "company newsletter", or "internal comms".
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: content-studio
---

# Newsletter Builder

Generate engaging newsletters with proper structure and compelling content.

## What This Skill Does

Creates newsletter drafts including:
- Attention-grabbing subject lines
- Clear section structure
- Scannable formatting
- Calls to action
- Engagement elements

## When to Use

- Weekly/monthly team updates
- Company-wide communications
- Customer newsletters
- Product updates
- Community digests

## Required Information

1. Newsletter type (internal/external)
2. Audience
3. Frequency (weekly, monthly, etc.)
4. Key topics/updates to include
5. Tone (formal, friendly, energetic)
6. Any recurring sections

## Newsletter Best Practices Applied

- **Subject line:** Clear value, under 50 chars
- **Preview text:** Complements subject
- **Scannable:** Headers, bullets, short paragraphs
- **One primary CTA:** Don't overwhelm
- **Mobile-first:** Most read on phones

## Output Format

# Newsletter Draft: {Edition/Date}

## Subject Line Options
1. {Option 1 - benefit-focused}
2. {Option 2 - curiosity-driven}
3. {Option 3 - news-focused}

**Preview text:** {The text that appears after subject in inbox}

---

## Newsletter Content

### Header
{Newsletter Name} | {Date/Edition}

---

### 👋 Hello {Name/Team},

{Brief, warm opening. 1-2 sentences that set the tone and preview what's inside.}

---

### 📣 Big News / Spotlight
**{Headline}**

{The most important update or story. 2-3 paragraphs max. Include why it matters to the reader.}

{CTA if applicable: Learn more → }

---

### 📊 Updates & Highlights

**{Update 1 Title}**
{Brief description. 2-3 sentences.}

**{Update 2 Title}**
{Brief description. 2-3 sentences.}

**{Update 3 Title}**
{Brief description. 2-3 sentences.}

---

### 🎉 Wins & Recognition

- {Shoutout or celebration 1}
- {Shoutout or celebration 2}
- {Milestone or achievement}

---

### 📅 Upcoming

| Date | Event |
|------|-------|
| {date} | {event} |
| {date} | {event} |
| {date} | {event} |

---

### 💡 Quick Tips / Did You Know?

> {Useful tip, fact, or insight relevant to your audience}

---

### 📚 Resources / Links

- [{Resource 1}]({link})
- [{Resource 2}]({link})
- [{Resource 3}]({link})

---

### 💬 Feedback Corner

{Question to engage readers or request for input}

[Reply to share your thoughts →]

---

### Closing

{Brief sign-off. Thank them, preview next edition, or inspiring close.}

Best,
{Name/Team}

---

## Footer
{Unsubscribe link if external} | {Contact info} | {Social links}

---

## Metrics to Track
- Open rate (aim: >40% internal, >20% external)
- Click rate (aim: >10%)
- Reply rate
- Unsubscribes

## Pre-Send Checklist
- [ ] Subject line tested
- [ ] All links working
- [ ] Images loading
- [ ] Mobile preview checked
- [ ] Sent test to yourself
- [ ] Scheduled for optimal time