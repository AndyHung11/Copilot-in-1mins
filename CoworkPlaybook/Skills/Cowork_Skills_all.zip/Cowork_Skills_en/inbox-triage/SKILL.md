---
name: inbox-triage
description: |
  Classifies unread emails into Reply / FYI / Delegate / Ignore buckets with reasoning.
  Use when user asks to "triage my inbox", "sort my unread mail", "what should I reply to",
  "clean up my inbox", "prioritize my emails", or "go through my unread".
  Do NOT use for searching specific emails — use SearchM365 directly.
  Do NOT use for drafting replies in bulk — this skill classifies only; user picks which
  to act on.
cowork:
  category: productivity
  icon: TaskListLtr
---

## Overview

Reads the user's unread inbox, classifies each message into one of four action buckets, and
presents them as a prioritized table. The user decides which to act on; this skill does not
auto-reply, auto-delete, or auto-file.

## Classification buckets

| Bucket | Meaning |
|--------|---------|
| **Reply** | Direct ask of the user, awaiting their response |
| **FYI** | Informational, no action needed but worth reading |
| **Delegate** | Better handled by someone else (named in the output) |
| **Ignore** | Newsletter, automated, low-signal — safe to archive |

## When to Use

- Morning inbox cleanup
- After PTO or a heavy meeting day
- User feels overwhelmed by unread count

## When NOT to Use

- Looking for one specific email → use `SearchM365` directly
- Daily briefing across email + calendar + Teams → use `daily-briefing`
- Setting up filters/rules → use Outlook rules tools directly

## Quick Start

```
User: "triage my inbox"
1. ListMessages(unread_only=true, top=50)
2. For each: classify by sender role, recipient pattern, body intent
3. Render table grouped by bucket, Reply first
4. Offer next step: open the first Reply item, draft replies, archive Ignores
```

## Core Instructions

### Step 1: Fetch unread
- `ListMessages(unread_only=true, top=50)`
- If `next_link` and the user has more, paginate up to 100 — beyond that ask if they want everything

### Step 2: Classify each message

Apply these heuristics in order:

1. **Reply** if:
   - User is in `to` (not just `cc`)
   - Body contains direct question, request, or `?` directed at user
   - Sender is the user's manager, skip-level, or a key stakeholder

2. **Delegate** if:
   - Sender asks for something a known team member typically handles
   - Use `GetDirectReportsDetails` if the user has reports — suggest by name
   - Otherwise leave blank — do NOT invent names

3. **FYI** if:
   - User is in `cc` only, or it's a forwarded thread for awareness
   - Status updates, announcements, read-only context

4. **Ignore** if:
   - Sender is a known automated address (no-reply, notifications, newsletters)
   - Marketing or external mass distribution
   - Calendar invitations that the user already responded to

### Step 3: Render output

Use `render-ui` to show a card with a table:

| Bucket | From | Subject | Why |
|--------|------|---------|-----|
| Reply | Piotr Dragan | Q2 review prep | Direct ask, manager |
| Delegate | … | … | Routine vendor follow-up |
| FYI | … | … | CC'd only |
| Ignore | … | … | Marketing |

Sort Reply first, then Delegate, then FYI, then Ignore. Include message aliases like
`[msg_3]` so the user can click through.

### Step 4: Next steps

After showing the table, offer:
- "Want me to draft replies for the Reply bucket?"
- "Want me to archive the Ignore bucket?" (requires explicit confirmation per message)

## Guardrails

- Never auto-archive, auto-reply, or auto-delete — classification only
- Never invent a delegate name — only suggest reports/teammates resolved via people tools
- If sender is the user's manager or skip-level, always classify as Reply or FYI (never Ignore)
- If unsure between two buckets, prefer the more cautious one (Reply over FYI, FYI over Ignore)
