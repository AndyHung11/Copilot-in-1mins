---
name: cowork-cost-estimator
description: |
  Estimates monthly and annual Microsoft Copilot Cowork licensing cost for the
  single signed-in user. Classifies that user by worker category, populates the
  Cowork cost estimator spreadsheet with the correct prompt-mix defaults,
  recalculates formulas, and delivers a cost summary card plus a filled-in
  Excel file and a ready-to-send admin report.

  Use when user asks to "estimate my Cowork cost", "how much would Cowork cost",
  "calculate my Copilot Credits", "how much would I pay for Cowork",
  "what is the Cowork budget", "cost calculator for Cowork",
  "model Cowork scenarios", "Cowork licensing cost",
  "how much does Cowork cost per user".

  Do NOT use for general Microsoft 365 subscription pricing, Azure cost management,
  Power BI licensing questions, or non-Cowork AI tool cost analysis (GitHub Copilot, Azure OpenAI).
cowork:
  category: analysis
  icon: Calculator
---

# Copilot Cowork Cost Estimator

Estimates monthly Copilot Credit consumption and USD cost for the single
signed-in user using the Microsoft Cowork pricing calculator spreadsheet.

## When NOT to Use

- General Microsoft 365 or Azure pricing questions — answer directly from product pages
- Non-Cowork AI licensing (GitHub Copilot, Azure OpenAI, Copilot for M365) — answer directly
- Actual invoice reconciliation or historical spend reporting — use the billing portal

## Workflow

### Step 1 — Ask three questions up front (blocking)

This skill always estimates for **a single user — the signed-in user**. Before anything else, ask these three questions (use `AskUserQuestion`). They gate the rest of the workflow — do not skip them:

1. **Estimator file** — Ask the user to upload the Cowork estimator workbook (`CustomerCoworkEstimator.xlsx`). First check `input/`; if it is already there, use it and skip this question. Otherwise wait for the upload before proceeding — do not substitute representative or placeholder data if it is missing.
2. **Calculation period** — Ask how many days the estimate should cover. Offer **30 days** (one month), **90 days** (a quarter), and **365 days** (a year) as options, and accept a custom number of days via "Other". Default to 30 days if the user declines to choose. Call this value `N` and carry it through Steps 3–4.
3. **Monthly limit** — Ask what monthly Copilot Credit limit (cap) the admin has set for the user. The limit is always expressed in **Copilot Credits per month** (never USD). Accept a custom number via "Other", and allow "No limit / not sure" to skip. Call this value `L`. When provided, use it in Step 4 to compare against the estimated monthly credits; when skipped, omit the limit comparison.

Then resolve the remaining inputs from context without asking:

1. **User identity**: Read the signed-in user's name, job title, and department from system context.
2. **Scope**: Always exactly 1 user — the signed-in user. Do not handle team or org-wide estimates here.
3. **Worker category mapping** — map the signed-in user's job title keywords to exactly one of the four calculator categories:

   | Job title keywords | Category | Calculator row |
   |--------------------|----------|----------------|
   | Architect, Engineer, Developer, SRE, DevOps, Data Scientist, IT, Technical | Technical Workers | D14 |
   | Sales, Account Executive, Customer Success, Account Manager, Pre-Sales, SE | Customer-Facing Knowledge Workers | D13 |
   | Manager, Director, VP, Head of, Principal, C-suite, Partner, GM, Lead | Managers & Senior Leaders | D15 |
   | All others (analyst, coordinator, HR, legal, finance, marketing, ops) | Corporate Knowledge Workers | D12 |

### Step 2 — Populate the calculator

Using `openpyxl`, open `input/CustomerCoworkEstimator.xlsx` and write user counts into the Budget sheet:

- `D12` = Corporate Knowledge Workers count
- `D13` = Customer-Facing Knowledge Workers count
- `D14` = Technical Workers count
- `D15` = Managers & Senior Leaders count

Keep all default prompt-mix values (D23:F26) and credits-per-prompt values (D33:D35) unless the user explicitly provides overrides.

Style conventions:
- Input cells: blue font (RGB `0000FF`, bold) per financial model convention
- Add a brief annotation in column H beside each populated row (e.g., `← 1 user: Rajesh Jayaraj, Cloud Solution Architect`)
- Widen column H to 52 characters so annotations are readable

Save output to `output/CoworkEstimator_<FirstName>.xlsx` (use the signed-in user's first name).

### Step 3 — Recalculate and spot-check

Run `python scripts/recalc.py output/CoworkEstimator_<FirstName>.xlsx` and confirm `status: success` with zero formula errors.

Verify key computed values against manual calculation before reporting:
- `G25` (Technical Workers credits/user) = `(D25×D33) + (E25×D34) + (F25×D35)`
- `D41` (total monthly credits) = `SUMPRODUCT(D12:D15, G23:G26)`
- `D42` (monthly USD) = `D41 / 100`
- `D43` (cost per user/month) = `D42 / SUM(D12:D15)`

Then prorate to the requested period of `N` days from Step 1. The calculator's figures cover a full month; convert using a 365-day year so that `N = 365` reconciles to the annual total:
- daily credits = `(D41 × 12) / 365`
- **period credits** = daily credits × `N`
- **period USD** = period credits / 100
Keep the monthly and annual figures as reference points; do not overwrite the sheet's monthly formulas to do this — compute the period values alongside.

### Step 4 — Display the results card (ALWAYS, on screen)

**Always render an on-screen `render_ui` summary card** (use the `render-ui` skill). This graphical card is the **primary output the user sees** — render it every run, and render it *before* generating the Word report in Step 5. Never skip the card and jump straight to the report. The card contains:
- User classification: role → worker category
- **Calculation period**: `N` days (as chosen in Step 1)
- **Cost for the requested period**: Copilot Credits and USD over `N` days
- Estimated monthly Credits
- Monthly cost (est)
- Annual cost (estd)
- Prompt mix used (Light / Medium / Heavy per month)
- **Monthly limit** (only when `L` was provided): the credit cap, **estimated monthly Credits** vs that cap, and **remaining** (or **over by**) credits. Compare against the *monthly* estimate (`D41`) — never against the `N`-day period figure, which is a different unit. Flag clearly if the estimate exceeds the limit.

**Include a chart in the same card** so the result is easy to read at a glance (use the `render-ui` skill's chart elements):
- **Monthly limit provided (`L`)** → a `Chart.Gauge` of **estimated monthly Credits against the limit `L`**, so it's instantly clear whether the user is within or over the cap.
- **No limit** → a `Chart.Donut` of **credits by prompt type** (Light / Medium / Heavy), so the heavy-prompt cost driver stands out.
- Label each segment with its credits (or USD) value and keep the prompt-type color order consistent across runs.

**Limit status color (only when `L` was provided)** — color the gauge value, the limit metric, and any status badge by how the estimated monthly credits compare to `L`:
- **Green** — within limit: estimate ≤ 80% of `L`
- **Amber** — reaching limit: estimate between 80% and 100% of `L` (inclusive)
- **Red** — exceeded limit: estimate > `L`

State the status in words next to the color (e.g., "Within limit", "Approaching limit", "Over limit") so it reads correctly without relying on color alone.

Follow the card with:
1. File reference: `output/CoworkEstimator_<FirstName>.xlsx`
2. One-line key insight: identify the single biggest cost driver (typically Heavy prompts for Technical Workers)
3. Disclosure note: actual session logs are not accessible via Microsoft 365 APIs — the Microsoft Frontier default prompt mix is used as a proxy
4. Scenario offer: "Want me to run Light-skew and Heavy-skew scenarios to see the cost range?"

### Step 5 — Generate the admin report (Word document ONLY)

After the card is on screen, generate the shareable report **only as a Word document** (`.docx`) — do not produce PDF, HTML, an inline copy, or an email version. Use the `docx` skill to generate `output/CoworkCostReport_<FirstName>.docx` — a clean one-pager the user can forward to their admin (e.g., to request a budget or a credit-limit decision), containing:

- **Header**: title ("Microsoft Copilot Cowork — Cost Estimate"), prepared-by (signed-in user's name, job title, department), and the date.
- **Purpose line**: one sentence stating why it's being shared (e.g., budget approval / monthly limit review).
- **Summary table**: the user (role + worker category), calculation period (`N` days), estimated cost for the period, estimated monthly Credits, monthly cost (est), and annual cost (estd).
- **Limit status callout** (only when `L` was provided): the monthly cap, estimated monthly Credits vs cap, remaining/over, and the status word — colored green / amber / red by the same 80% / 80–100% / over-cap thresholds.
- **Assumptions & disclosure**: the prompt mix used and the Frontier-default proxy note (session logs aren't accessible via M365 APIs; this is a directional estimate, not a billing commitment).
- **Requested action**: a short closing line (e.g., "Requesting approval for the above monthly limit / budget").

After the document is created, confirm to the user that the Word report is saved in `output/` and ready to share with their admin (by attaching it to an email or Teams message). Do not draft or send an email, and do not produce the report in any other format — the Word document is the only report artifact.

## Output Format

| Artifact | Location | Description |
|----------|----------|-------------|
| Excel file | `output/CoworkEstimator_<FirstName>.xlsx` | Filled calculator with blue input cells and column-H annotations |
| Summary card | Inline (`render_ui`) | **Always shown.** Period cost (over N days), estimated monthly Credits, monthly USD, annual USD, plus a chart (usage-vs-limit gauge, or prompt-type donut) |
| Admin report | `output/CoworkCostReport_<FirstName>.docx` | The only report artifact — a Word one-pager to share with an admin (no PDF/HTML/email versions) |
| Scenario offer | Inline text | Offer to model optimistic vs conservative prompt mix |

## Pricing Reference (Microsoft Frontier defaults, 5/27/2026)

**Credits per prompt (Step 3 of calculator):**

| Prompt type | Credits | Cost @ list price |
|-------------|---------|-------------------|
| Light | 125 | $1.25 |
| Medium | 500 | $5.00 |
| Heavy | 1,200 | $12.00 |

Conversion rate: **100 Copilot Credits = $1 USD** (list price). Model baseline: Anthropic Opus 4.8.

**Default monthly prompt mix per user (Step 2 of calculator):**

| Category | Light | Medium | Heavy | Credits/user/mo |
|----------|-------|--------|-------|-----------------|
| Corporate Knowledge Workers | 22 | 11 | 5 | 14,250 |
| Customer-Facing Knowledge Workers | 17 | 13 | 5 | 14,625 |
| Technical Workers | 12 | 9 | 14 | 22,800 |
| Managers & Senior Leaders | 13 | 6 | 3 | 8,225 |

## Guardrails

- Never fabricate user counts, prompt volumes, or cost figures — use only what the user provides or the Frontier defaults from the sheet.
- Do not hard-code calculated values into the Excel output — keep Excel formulas intact so the file remains editable.
- Always disclose that this is a directional budget estimate, not a billing commitment.
- Always disclose that actual session logs are not accessible via Microsoft 365 APIs; the default prompt mix is used as a proxy.
- Always ask the user to upload `CustomerCoworkEstimator.xlsx` first (unless it is already in `input/`) — this is a blocking question; do not substitute representative or placeholder data.
- Never fabricate the calculation period — use the number of days the user provides, defaulting to 30 days only if they decline to choose.
- Never fabricate the monthly limit — use only the cap the user provides. If they skip it, omit the limit comparison and the limit gauge entirely; do not assume a default cap.
- When a limit is provided, color and label the status consistently: green ≤ 80% of the cap, amber 80–100%, red over the cap — and always state the status in words, not color alone.
- Always display the graphical `render_ui` summary card on screen first — it is the primary user-facing output and must appear on every run, never skipped in favor of going straight to the report.
- Generate the admin report only as a Word document (`output/CoworkCostReport_<FirstName>.docx`) — never as PDF, HTML, an inline copy, or an email. Do not draft or send an email; the user shares the Word file themselves.
- This skill is single-user only — always estimate for the signed-in user and classify them into exactly one worker category. Do not handle team or org-wide estimates.
- The monthly limit is always in Copilot Credits (never USD) — do not convert or reinterpret it. Compare it only against the estimated *monthly* credits, not the period figure.
- "Estimated monthly Credits" and "Monthly cost (est)" are projections from the default prompt mix, not actual usage — label them as estimates and never present them as measured consumption.
- Always produce the admin report as a deliverable file the user can review; never auto-send it to an admin or guess the recipient. Only create an email draft after the user names the recipient, and leave it as a draft for them to send.
