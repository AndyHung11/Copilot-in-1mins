---
name: weekly-wrap
description: |
  汇总用户过去一周发送的邮件、已接受的会议和 Teams 帖子，
  生成周五状态笔记。当用户说“帮我整理这周”、“每周复盘”、“写我的每周状态”、“我这周做了什么”、“周五状态笔记”、“总结我这一周”、"wrap my week", "weekly wrap", "write my
  weekly status", "what did I do this week", "Friday status note", or "summarize my week" 时使用。
  不要用于每日摘要 — 请改用 daily-briefing。
  不要用于前瞻性规划 — 此 skill 只做回顾。
cowork:
  category: productivity
  icon: Flag
---

## 概览

拉取用户本工作周在 Outlook（已发送邮件）、日历（已接受会议）和 Teams（频道 + 聊天帖子）中的活动，然后生成一份结构化状态笔记，用户可发布到团队频道、发邮件给经理，或保留为个人记录。

## 适用场景

- 周末撰写状态更新
- 回顾自己完成了哪些工作
- 基于一周活动生成经理更新或团队摘要

## 不适用场景

- "What did I miss today" / 早间简报 → 使用 `daily-briefing`
- 多周或季度报告 → 使用 `stakeholder-comms`
- 单场会议复盘 → 使用 `meeting-followup`

## 快速开始

```
用户: “帮我整理这周”
1. 计算周范围（Monday 00:00 → now），使用用户时区
2. 并行执行：
   - ListMessages，使用 folder_id=sentitems, received_after=<Monday>
   - ListCalendarView 使用相同时间窗口，is_organizer filter both ways
   - SearchM365 sources=["teams"], from_user=<user email>, after=<Monday>
3. 将结果归组为主题（项目、话题、人员）
4. 生成结构化周五状态笔记
```

## 核心说明

### 步骤 1：解析周范围
- 使用用户当前本地时间
- 一周从用户时区的 Monday 00:00 开始，到 now 结束
- 如果是周一早上，询问用户指的是上周还是当前这个不完整周

### 步骤 2：并行收集数据
同时运行以下三个工具调用：
- `ListMessages(folder_id="sentitems", received_after=<Monday ISO>, top=100)`
- `ListCalendarView(start=<Monday>, end=<now>, top=50)` — 只保留用户已参加的事件（未拒绝）
- `SearchM365(sources=["teams"], from_user=<user email>, after=<Monday>, response_length="long")`

如果其中任何一个返回 `next_link`，继续翻页处理。

### 步骤 3：分类并分组
按主题归组活动。根据重复主题、参会人重叠或频道名称识别主题。
常见类别：
- **已交付 / 有进展的项目**
- **关键会议**
- **已做出的决策**
- **互动过的人员**

### 步骤 4：输出格式

```markdown
# <Mon date> – <Fri date> 周

## 亮点
- 3–5 条，列出最重要的事情

## 我做了什么
- 按项目/主题分组

## 值得关注的会议
- 只列有结果的会议（不包括例行同步）

## 下周
- 2–3 件延续事项（仅当可从开放线程中明显看出时）
```

默认以内联 markdown 呈现。如果用户要求文件或想分享，提供起草 Teams 帖子（`PostMessage`）或邮件（`CreateDraftMessage`）— 未经检查绝不发送。

## 护栏

- 绝不包含私人日程（sensitivity=private）— 只显示为时间块
- 绝不在公开摘要中包含人事/HR/薪酬讨论
- 绝不编造成果 — 如果一周活动较少，就如实说明
- 默认使用内联 markdown；只有在明确要求时才创建文件或发送信息
