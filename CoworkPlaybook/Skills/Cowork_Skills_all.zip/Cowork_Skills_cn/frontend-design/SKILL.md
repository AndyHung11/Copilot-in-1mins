---
name: frontend-design
description: 构建有鲜明观点、可直接用于生产环境的高质量前端界面。当用户要求设计或实现 Web component、页面、landing site、dashboard、marketing site 或任何 UI 界面时使用此技能；也可在用户说“设计一个 Web 组件”、“做一个落地页”、“设计仪表盘”、“重做这个 UI”、“搭建营销网站”时使用。生成可运行的代码，并做出有意识的美学选择，避免默认 AI-template 风格。
---

此技能会产出看起来像被真正设计过、而不是自动生成的前端代码。每个输出都应具备清晰的美学身份、打磨到位的执行，以及值得二次品味的细节。

用户会描述想要构建的内容 — 一个组件、一个页面、一个完整应用 — 也可能提供受众、品牌、框架或约束等背景。如果没有指定品牌或调性，请自行选择方向并坚持到底；不要默认套用中性模板。

## 前置准备：确定方向

编写任何代码前，先在内部回答四个问题：

- **目的**：这个界面用于什么场景，用户是谁？他们应该采取什么行动？
- **调性**：选定一种并坚持。可选方向包括 — 编辑/印刷风（editorial/print-inspired）、粗野主义/原始 HTML（brutalist/raw HTML）、瑞士排版风（swiss/typographic）、复古终端（retro-terminal）、柔和拟物（soft neumorphic）、玻璃拟态/极光（glassmorphic/aurora）、蒸汽波（vaporwave）、新艺术（art nouveau）、bauhaus 几何（bauhaus geometric）、手绘/草图（hand-drawn/sketchy）、赛博朋克（cyberpunk）、等宽实用风（monospace utilitarian）、奢华/重衬线（luxury/serif-heavy）、勒索信拼贴（ransom-note collage）、等距/3D（isometric/3D）、环境/自然灵感（ambient/nature-inspired）。如果两种方向能相互强化，可以混合两种；绝不要混合三种。
- **约束**：框架、浏览器目标、无障碍底线（除非另有说明，最低为 WCAG AA）、性能预算、响应式断点。
- **记忆点**：访客会记住并向朋友描述的那个元素是什么？每个设计都需要一个标志性动作 — 字体上的巧思、不寻常的排版原语、意料之外的交互、醒目的配色。

**CRITICAL**：明确意图胜过堆砌强度。精准执行的克制设计，比粗糙执行的高刺激设计更有力量。选定路线，并把它做透。

## 输出要求

每个交付物都必须：

- **可运行**：是真实代码，无需修改即可运行 — 没有 pseudocode，没有 `// TODO: implement`
- **无障碍**：语义化 HTML、支持键盘导航、对比度充足、焦点状态经过设计（不是浏览器默认样式）
- **响应式**：采用 mobile-first，或基于明确设计选择仅支持桌面；绝不能是“手机端意外坏掉”
- **一致**：整个输出使用一套设计系统、一种动效语言、一致的语气
- **精致**：小细节 — 标题字距、视觉对齐、hover 状态、空状态、加载状态 — 都经过有意设计，而不是被省略

## 工艺准则

- **字体**：字体是最响亮的设计选择。创造性地使用 Google Fonts、Fontshare 或系统回退字体。将有性格的展示字体与易读的正文字体配对 — 例如 Fraunces + Inter Tight、PP Editorial New + JetBrains Mono、Instrument Serif + Geist、Söhne + Tiempos。充分利用 variable font 轴（weight、optical size、slant）。使用真正的排版细节：悬挂标点、真正的小型大写、在合适位置使用表格数字、连字、长文内容的首字下沉。避开安全默认项 — 单独使用 Inter、Roboto、Arial、Helvetica 且没有观点。

- **颜色**：一个主色、一到两个强调色，以及一个刻意选择的中性色。所有颜色都定义为 CSS custom properties。浅色、深色或双色 — 一开始就决定。考虑不常见的配色：暖米白 + 墨黑 + 一个高饱和强调色；深海军蓝 + 奶油色 + 黄铜色；近黑 + 酸性绿；沙色 + 陶土色 + 海洋色。避开 AI 痕迹：白底上的靛蓝到紫色渐变、slate-50 背景配 slate-900 文本和 blue-600 按钮。

- **排版与构图**：网格要被有意使用 — 用来对齐，或被刻意打破。尝试不对称、刻意重叠、裁出容器外的超大字体、带有编辑感的侧栏、长文的 baseline grid。大留白或受控密度 — 二选一。避免那种“三栏功能卡片网格”的模板感
