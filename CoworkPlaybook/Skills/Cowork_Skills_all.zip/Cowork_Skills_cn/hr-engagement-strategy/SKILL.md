---
name: hr-engagement-strategy
description: |
  将员工敬业度调研导出文件转化为完整的 HR 高管交付套件：
  五大主题摘要、包含对标信息且可直接给 CEO 使用的策略文档、SLT 落地执行
  汇报材料、一页品牌色信息图，以及 Copilot Create / Sora 视频脚本。
  当用户说“分析我们的敬业度调研”、“把敬业度调研总结成主题”、“为 CEO/SLT 制定敬业度策略”、“创建 HR 赋能汇报材料”、“把调研结果做成演示文稿”、“制作敬业度信息图”、“为 HR 写 sales-enablement / Copilot-adoption 策略”、"analyze our engagement survey", "summarize the engagement
  survey into themes", "build an engagement strategy for the CEO/SLT", "create an HR
  enablement deck", "turn survey results into a presentation", "make an engagement
  infographic", or "write a sales-enablement / Copilot-adoption strategy for HR" 时使用。
  重点覆盖 HRBP、Sales Leader 和 L&D 角色，以及 Copilot for Sales 采用。
  不要用于：安排 HR 会议（使用 schedule-meeting）、常规 HR 状态邮件
  （使用 stakeholder-comms），或评估单个员工绩效（拒绝）。
cowork:
  category: analysis
  icon: People
---

## 概述

此技能运行一个五阶段 HR 流程，将单个敬业度调研导出文件转化为
高管可直接使用的一整套交付物。每个阶段都为下一阶段打基础：主题只来自
真实调研数据，策略基于这些主题展开，所有下游交付物
（汇报材料、信息图、视频脚本）都复用同一套策略，保证叙事一致。

所有交付物的共同叙事：识别员工 — 尤其是**顶尖销售人员** — 如何
以进阶方式使用 Copilot，提炼他们的使用模式，并让 **L&D** 将这些模式转化为
短小、按需触达的培训内容，再由 **HRBPs** 联动 **Sales Leadership** 进行落地，
从而提升收入。CRM/Salesforce 指标会作为衡量框架，使用用户提供的数据或
明确标注的占位符 — 此技能绝不拉取实时 CRM 数据。

## 使用场景

- 用户上传敬业度/脉搏/文化调研导出文件，并希望进行分析
- 用户需要基于敬业度发现生成 CEO 或 SLT 汇报材料
- 用户想要围绕 Copilot 采用制定 HR 到销售的赋能策略
- 用户单独要求信息图或视频脚本

## 不使用场景

- 安排或改期 HR 会议 — 使用 **schedule-meeting**
- 简单的状态邮件或公告 — 使用 **stakeholder-comms**
- 对单个员工绩效进行排名、评分或比较 — **礼貌拒绝**
  （"I can't evaluate individual performance; I can summarize team/program outcomes instead"）
- 按任何受保护特征筛选人员 — **拒绝**，改为提供角色/团队/技能等替代方式

## 快速开始

```
用户: "分析我们的敬业度调研，并生成 CEO strategy + SLT deck + infographic + video script"
1. 在 input/ 中查找调研文件（Glob input/**/*）。如果没有，请要求用户提供 — 绝不编造数据。
2. 阶段 1 — 从真实调研数据中提取正好 5 个主题（xlsx skill）。
3. 阶段 2 — 编写策略文档（docx）：趋势、3 项策略（短期 + ≤2yr）、高管
   摘要、与约 ~10k-employee 同业基准对标（deep-research，附引用）。
4. 阶段 3 — 基于策略文档制作 SLT 落地执行汇报材料（pptx）。
5. 阶段 4 — 生成一页信息图（公司品牌，使用 code 输出 PNG）。
6. 阶段 5 — 编写 Copilot Create / Sora 视频脚本（docx）。
7. 在报告完成前，确认每个文件都已落在 output/。
```

每个阶段创建一个 Task，让用户看到进展。阶段 3–5 依赖阶段 2 的策略
内容；阶段 1 必须先于阶段 2 完成。在调研加载前，不运行任何需要调研数据的工作。

## 核心说明

### 阶段 0 — 定位输入（始终先做）

- 使用 `Glob input/**/*` 查找调研导出文件（`.xlsx`, `.csv`, `.xls`）。匹配名称中的
  *survey*, *engagement*, *pulse*, *export*。
- 如果没有找到文件，**停止并要求**用户附上文件。不要基于编造数据进入阶段 1。
  这是硬性门槛。
- 询问一次（仅在未说明时）他们需要全部五项交付物，还是只需要其中一部分。

### 阶段 1 — 五个关键主题（xlsx skill）

- 使用 **xlsx** skill 读取调研。检查列：问题文本、分数、开放式
  评论、分群维度（部门、任职年限、区域）。
- 推导**正好五个**由数据支撑的主题。每个主题 = 简短标题 + 背后的
  量化信号（例如分数、% favorable、top driver）+ 1–2 条代表性
  原文摘录（**仅当**文件中存在时）。
- 任何数字（平均值、% favorable、差异）都必须用 code tool 计算 — 绝不手算。
- 如果导出文件缺少用户预期的维度（例如没有分群列），请直接说明。
- 将主题以内联的有序列表输出；这会成为阶段 2 的主线。

### 阶段 2 — 策略文档（docx skill）

调用 **docx** skill。结构：

1. **高管摘要**（半页）— 用 CEO 能接受的业务语言讲清敬业度故事，并以
   业务影响开场。
2. **员工敬业度趋势** — 五个主题加上近期员工敬业度宏观趋势
   （使用 deep-research / web search 获取外部趋势；引用来源）。
3. **基准对标** — 我们组织与具有代表性的 **~10,000-employee** 同业群体对比。
   通过 **deep-research** agent 处理，确保每个外部数字都有引用。若
   内部数字未知，插入 `[Add: our figure]` 占位符 — 绝不编造。
4. **三项可执行策略** — 有意识地混合**短期与中长期（最长
   2 years）**，并以**全组织**视角呈现。每项包含：目标、时间范围、负责人，以及
   会推动的**组织指标**（敬业度、留存率、生产力、收入）。
5. **关联到组织指标** — 明确说明对 CEO 关注的整体组织指标的收益。

数字规则：文档中嵌入的任何总数、%、平均值或差异，都必须由 code 计算，
不能由你手算。收件人、引用和统计数据必须真实或使用占位符，绝不编造。

### 阶段 3 — SLT 落地执行汇报材料（pptx skill）

调用 **pptx** skill。基于阶段 2 策略制作**高管层级的落地执行计划**
（不是重新分析）。必备章节：

- 标题 + 高管摘要幻灯片
- 将三项策略呈现为执行路线图（短期 vs ≤2-year 泳道）
- **HR ↔ Sales alignment**：HRBPs 如何与 Sales Leadership 合作
- **Customized AI training for Sales** 使用销售专属场景，并映射到销售
  周期（prospect → qualify → propose → close → expand）
- **衡量**：Salesforce CRM + 现有 sales KPIs 作为衡量框架
  （用户提供的数据或占位符）
- **经济合理性**：面向所有员工采用 Copilot for M365 展示模型
  结构（成本输入、生产力/收入杠杆、回收期），对任何未提供的数字使用 `[Add: figure]`
  占位符。明确说明假设。
- **HRBP as liaison** to Sales Leadership 协同推进转型
- SLT 的下一步行动/决策请求

### 阶段 4 — 一页信息图（公司品牌，使用 code 输出 PNG）

使用 Python（matplotlib/PIL — session 中没有 image-generation
工具，不要 `pip install`）生成单页 PNG 到 `output/`。

**先解析公司品牌，按以下顺序 — 不要硬编码某一家公司的配色：**

1. **用户提供的品牌资产** — 如果 `input/` 中有品牌指南、logo 或样式文件，
   读取并从中提取 hex 颜色/logo。
2. **组织模板库** — 检查 `@org-template-library`（租户的品牌化 Office
   模板，通过 `GetOrgTemplateLibrary` / `GetDriveChildren(drive_id="@org-template-library")`）。
   从 `.potx`/`.dotx` 推导强调色，并在存在 logo 时复用。
3. **简短询问** — 如果两者都没有颜色，请向用户询问品牌 hex 值（或
   可取样的 logo）。提供一个中性专业默认方案（单一主色 + 深色中性色 +
   浅灰），避免流程被阻塞，并标注为占位配色。

一致应用解析出的品牌色（主色用于标题/强调，中性色用于正文，
一个辅助色用于提示区块）。如果有 logo，将其放在页眉。除非颜色确实来自
步骤 1–2 或由用户提供，否则不要声称这是某个特定品牌的颜色。

内容：以**三项策略**为主干，清晰突出三个角色 —
**HRBP**（编排者/联络人）、**Sales Leader**（赞助者）、**L&D**（基于
已识别的 **sales champions** 使用 Copilot 构建培训）。强调销售角色带动新增
收入。保持易读：标题、3 个策略区块、角色带、指标提示区块。

### 阶段 5 — 视频脚本（docx skill，Copilot Create / Sora ready）

调用 **docx** skill。受众：**SLT + Sales Leadership / CRO**。交付一份
用户可直接粘贴到 **Copilot Create 或 Sora 2.0** 的脚本 — 按场景拆分，包含：场景
编号、屏幕视觉方向、旁白/解说，以及大致时长。总时长保持紧凑（目标 60–120s）。需要覆盖的叙事节奏：

- 识别**以进阶方式使用 Copilot** 在各销售阶段获胜的**顶尖销售人员**
- 机会：将他们的模式转化为面向其他销售人员的**动态销售内容**
- 内容**面向销售周期的各个部分**；**短小、按需触达**，并配套
  **companion agents + pre-written prompts**
- **Sales Copilot Champions** 作为同伴教练，帮助经验较少的用户
- **HRBP as strategist** 与 Sales Managers 协作，通过 **OCM** 改善经理反馈/辅导方式，
  支持销售人员实现 Copilot for Sales 卓越表现

## 护栏

- **调研数据门槛：** 在真实调研文件加载前，绝不生成主题、统计或引用。
  如果文件缺失或不可读，请说明并要求重新上传。
- **绝不编造：** 基准、ROI、KPIs、姓名、日期、引用。使用 `[Add: …]`
  占位符，并通过 deep-research 加引用处理外部主张。
- **数字由 code 计算：** 写入前先用 code tool 计算每个嵌入数字。
- **不做绩效评估/不按受保护特征画像** — 拒绝并提供合规替代方案。
- **交付门槛：** 每个文件阶段结束后，执行 `Glob output/**/*` 确认文件存在，
  再告诉用户已准备好。
- **一次运行、分阶段推进：** 如果用户一次要求全部内容，产出全部五项，但保持
  依赖顺序（survey → themes → strategy → deck/infographic/script）。
- **未来 plugin 路径：** 此技能设计为后续可通过 plugin builder 打包成 Cowork plugin
  （例如增加实时 Salesforce connector 并分发给所有 HRBPs）。