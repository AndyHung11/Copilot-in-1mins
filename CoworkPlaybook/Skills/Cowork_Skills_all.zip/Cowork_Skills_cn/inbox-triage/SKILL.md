---
name: inbox-triage
description: |
  将未读邮件归类到 Reply / FYI / Delegate / Ignore 四类，并说明原因。
  当用户说“帮我分流收件箱”、“整理未读邮件”、“哪些邮件要先回复”、“清理我的收件箱”、“给邮件排优先级”、“过一遍未读邮件”、"triage my inbox", "sort my unread mail", "what should I reply to",
  "clean up my inbox", "prioritize my emails", or "go through my unread" 时使用。
  不要用于搜索特定邮件 — 直接使用 SearchM365。
  不要用于批量起草回复 — 此 skill 只做分类；由用户选择要处理哪些
  邮件。
cowork:
  category: productivity
  icon: TaskListLtr
---

## 概览

读取用户收件箱中的未读邮件，将每封信息归类到四个行动类别之一，并以优先级表格呈现。用户决定处理哪些；此 skill 不会自动回复、自动删除或自动归档。

## 分类类别

| 类别 | 含义 |
|--------|---------|
| **Reply** | 直接向用户提出请求，等待用户回复 |
| **FYI** | 信息性内容，无需行动但值得阅读 |
| **Delegate** | 更适合由其他人处理（在输出中注明姓名） |
| **Ignore** | 简报、自动通知、低信号内容 — 可安全归档 |

## 适用场景

- 早上清理收件箱
- 休假后或会议密集的一天之后
- 用户被未读数量压得不知从何下手

## 不适用场景

- 查找某一封特定邮件 → 直接使用 `SearchM365`
- 跨邮件 + 日历 + Teams 的每日简报 → 使用 `daily-briefing`
- 设置筛选器/规则 → 直接使用 Outlook 规则工具

## 快速开始

```
用户: “帮我分流收件箱”
1. ListMessages(unread_only=true, top=50)
2. 逐封根据发件人角色、收件人模式、正文意图分类
3. 按类别分组渲染表格，Reply 优先
4. 提供下一步：打开第一个 Reply 项、起草回复、归档 Ignore
```

## 核心说明

### 步骤 1：获取未读邮件
- `ListMessages(unread_only=true, top=50)`
- 如果有 `next_link` 且用户还有更多邮件，最多翻页到 100 封 — 超过后询问是否要全部处理

### 步骤 2：逐封分类

按顺序应用这些启发式规则：

1. **Reply**，如果：
   - 用户在 `to` 中（不只是 `cc`）
   - 正文包含直接问题、请求，或指向用户的 `?`
   - 发件人是用户的经理、隔级领导或关键干系人

2. **Delegate**，如果：
   - 发件人请求的事项通常由已知团队成员处理
   - 如果用户有直接下属，使用 `GetDirectReportsDetails` — 按姓名建议
   - 否则留空 — 不要编造姓名

3. **FYI**，如果：
   - 用户只在 `cc` 中，或这是转发给用户了解情况的线程
   - 状态更新、公告、只读背景信息

4. **Ignore**，如果：
   - 发件人是已知自动发送地址（no-reply、notifications、newsletters）
   - 营销或外部群发内容
   - 用户已经响应过的日历邀请

### 步骤 3：渲染输出

使用 `render-ui` 显示带表格的卡片：

| 类别 | 发件人 | 主题 | 原因 |
|--------|------|---------|-----|
| Reply | Piotr Dragan | Q2 review prep | 直接请求，经理 |
| Delegate | … | … | 常规供应商跟进 |
| FYI | … | … | 仅抄送 |
| Ignore | … | … | 营销 |

排序为 Reply 优先，然后 Delegate、FYI、Ignore。包含类似 `[msg_3]` 的消息别名，方便用户点开查看。

### 步骤 4：下一步

显示表格后，提供：
- "Want me to draft replies for the Reply bucket?"
- "Want me to archive the Ignore bucket?"（每封邮件都需要明确确认）

## 护栏

- 绝不自动归档、自动回复或自动删除 — 只做分类
- 绝不编造转派对象姓名 — 只建议通过人员工具解析到的下属/团队成员
- 如果发件人是用户的经理或隔级领导，始终归类为 Reply 或 FYI（绝不 Ignore）
- 如果在两个类别之间不确定，选择更谨慎的一个（Reply 优先于 FYI，FYI 优先于 Ignore）
