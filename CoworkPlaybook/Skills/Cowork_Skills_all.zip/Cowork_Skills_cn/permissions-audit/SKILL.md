---
name: permissions-audit
description: |
  审查文件和 SharePoint 站点的共享与权限。
  当用户提出“谁有访问权限”、“检查权限”、“共享审计”、“谁能看到这个文件”、“审查访问权限”、“权限报告”、"who has access", "check permissions", "sharing audit",
  "who can see this file", "review access", 或 "permissions report" 时使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: document-intelligence
  m365-services: [SharePoint, OneDrive, Graph, Entra ID]
---

# 权限审计

审查并报告文件和站点的共享权限。

## M365 集成

- **SharePoint:** 站点权限、库设置
- **OneDrive:** 个人共享设置
- **Microsoft Graph:** 共享链接、访问详情
- **Entra ID:** 组成员身份、来宾用户

## 此技能的作用

分析并报告：
- 谁有文件/文件夹/站点的访问权限
- 访问类型（查看、编辑、所有者）
- 外部共享状态
- 共享链接（匿名、整个组织）
- 权限继承
- 潜在安全问题

## 使用场景

- 共享敏感文档前
- 定期安全审查
- 员工离职交接
- 合规审计
- 调查异常访问

## 输出格式

# 权限审计报告

## 审计目标

| 属性 | 值 |
|----------|-------|
| **项目** | {file/folder/site name} |
| **类型** | {File/Folder/Document Library/Site} |
| **位置** | {path} |
| **所有者** | {name} |
| **创建时间** | {date} |
| **上次修改** | {date} |

---

## 访问摘要

| 访问类型 | 数量 |
|-------------|-------|
| 所有者 | {n} |
| 编辑者 | {n} |
| 查看者 | {n} |
| 外部用户 | {n} |
| 共享链接 | {n} |

**整体风险等级：** {🟢 Low / 🟡 Medium / 🔴 High}

---

## 直接访问

### 所有者（完全控制）
| 用户/组 | 类型 | 来源 |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

### 编辑者（可编辑）
| 用户/组 | 类型 | 来源 |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

### 查看者（可查看）
| 用户/组 | 类型 | 来源 |
|------------|------|--------|
| {name} | {User/Group} | {Direct/Inherited} |

---

## 🔗 共享链接

| 链接类型 | 范围 | 创建者 | 到期时间 |
|-----------|-------|------------|------------|
| {Anyone/Organization/Specific people} | {View/Edit} | {name} | {date or Never} |

### ⚠️ 匿名链接
{List of "Anyone with the link" shares - security concern}

---

## 👥 外部共享

### 来宾用户
| 邮件 | 访问级别 | 邀请者 | 日期 |
|-------|--------------|------------|------|
| {email} | {level} | {name} | {date} |

### 外部域
| 域 | 用户数 | 风险 |
|--------|-------|------|
| {domain.com} | {n} | {assessment} |

---

## 🏢 组访问

| 组 | 成员 | 访问级别 |
|-------|---------|--------------|
| {group name} | {n} 名成员 | {level} |

**值得注意的组成员身份：**
- {Group} 包含 {notable members}

---

## 📊 权限继承

```
{Site/Library}
├── 📁 {Folder 1} - 继承
│   └── 📄 {File} - 继承
├── 📁 {Folder 2} - ⚠️ 唯一权限
│   └── 📄 {File} - 从文件夹继承
└── 📄 {File} - ⚠️ 唯一权限
```

---

## ⚠️ 安全问题

### 高优先级
- 🔴 {Concern - e.g., "Anonymous link to sensitive file"}
- 🔴 {Concern}

### 中优先级
- 🟡 {Concern - e.g., "External user with edit access"}
- 🟡 {Concern}

### 建议
1. **{Action}** - {reason}
2. **{Action}** - {reason}
3. **{Action}** - {reason}

---

## 最近权限变更

| 日期 | 变更 | 操作者 |
|------|--------|---------|
| {date} | {what changed} | {who} |

---

## 合规备注

- **外部共享：** {Enabled/Disabled} at site level
- **来宾访问策略：** {policy status}
- **敏感度标签：** {if applied}
- **保留策略：** {if applied}

---

## 快速操作

- 🔒 **移除** {items} 的外部访问权限
- ⏱️ **为共享链接设置到期时间**
- 👤 **移除** {user} 的访问权限
- 📧 **通知所有者** 关于 {concern}
