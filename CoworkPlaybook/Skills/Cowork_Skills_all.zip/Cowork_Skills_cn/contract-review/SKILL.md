---
name: contract-review
description: |
  分析合同和协议的关键条款、风险与义务。
  当用户提出“帮我审查这份合同”、“分析这份协议”、“检查合同条款”、“找出责任条款”、“总结这份 NDA”、“合同风险”、"review this contract", "analyze agreement", "check contract terms",
  "find liability clause", "summarize this NDA", 或 "contract risks" 时使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
---

# 合同审阅
分析合同，提取关键条款、识别风险并总结义务。

## 此技能的作用

审查合同并提供：
- 执行摘要
- 关键条款提取
- 重要日期和期限
- 风险识别
- 义务跟踪
- 不寻常或值得关注的条款

## 使用场景

- 审查供应商协议
- 签署前分析 NDA
- 检查客户合同
- 支持续约决策
- 尽职调查审查

## 工作流程

1. **文档分析**
   - 识别合同类型
   - 提取相关方
   - 找出生效日期和期限

2. **关键条款提取**
   - 付款条款
   - 交付物和范围
   - 终止条件
   - 续约条款

3. **风险评估**
   - 责任条款
   - 赔偿
   - 责任限制
   - IP 所有权
   - 保密范围

4. **义务映射**
   - 我方义务
   - 对方义务
   - 期限和里程碑

## 输出格式

# 合同审查摘要

## 文档概览
| 字段 | 值 |
|-------|-------|
| **合同类型** | {NDA, MSA, SOW, License, etc.} |
| **签约方** | {Party A} 和 {Party B} |
| **生效日期** | {date} |
| **期限** | {duration} |
| **管辖法律** | {jurisdiction} |

---

## 执行摘要

{2-3 sentence summary of what this contract does and its key implications}

---

## 关键条款

### 财务条款
| 条款 | 详细信息 |
|------|---------|
| **总价值** | {amount} |
| **付款条款** | {Net 30, milestone-based, etc.} |
| **逾期费用** | {if applicable} |
| **价格上调** | {annual increase clause if any} |

### 范围与交付物
- {Deliverable 1}
- {Deliverable 2}
- {Deliverable 3}

### 期限与终止
- **初始期限：** {duration}
- **自动续约：** {Yes/No, terms}
- **便利终止：** {notice period}
- **因故终止：** {conditions}

---

## ⚠️ 风险评估

### 高风险项
| 条款 | 位置 | 问题 | 建议 |
|--------|----------|---------|----------------|
| {clause} | Section {n} | {why it's risky} | {suggested action} |

### 中风险项
| 条款 | 位置 | 问题 |
|--------|----------|---------|
| {clause} | Section {n} | {concern} |

### 不寻常条款
- {Any non-standard clauses worth noting}

---

## 📋 我方义务

| 义务 | 期限 | 条款 |
|------------|----------|---------|
| {obligation 1} | {date/trigger} | §{n} |
| {obligation 2} | {date/trigger} | §{n} |
| {obligation 3} | {date/trigger} | §{n} |

---

## 📋 对方义务

| 义务 | 期限 | 条款 |
|------------|----------|---------|
| {obligation 1} | {date/trigger} | §{n} |
| {obligation 2} | {date/trigger} | §{n} |

---

## 重要日期

| 日期 | 事件 | 需要采取的行动 |
|------|-------|-----------------|
| {date} | {event} | {action} |
| {date} | 续约通知截止日期 | 决定续约或终止 |
| {date} | 合同到期 | {action} |

---

## 谈判要点

签署前可考虑谈判以下事项：

1. **{Item 1}:** {current state} → {suggested change}
2. **{Item 2}:** {current state} → {suggested change}
3. **{Item 3}:** {current state} → {suggested change}

---

## 与标准条款对比

| 条款 | 本合同 | 市场标准 | 评估 |
|--------|---------------|-----------------|------------|
| 责任上限 | {amount} | {typical} | {favorable/unfavorable} |
| 赔偿 | {scope} | {typical} | {favorable/unfavorable} |
| IP 所有权 | {terms} | {typical} | {favorable/unfavorable} |

---

## ⚠️ 免责声明

本分析仅供参考，不构成法律意见。
