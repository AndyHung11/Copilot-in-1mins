---
name: data-storyteller
description: |
  将数据和电子表格转化为叙事化洞察与建议。
  当用户提出“分析这些数据”、“这份电子表格说明了什么”、“这份 Excel 的洞察”、“解释这些数字”、“数据摘要”、"analyze this data", "what does this spreadsheet show",
  "insights from this Excel", "explain these numbers", 或 "data summary" 时使用。
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
---

# 数据讲故事
将原始数据转化为有说服力的叙事和可执行洞察。

## 此技能的作用

分析数据并提供：
- 通俗中文摘要
- 关键趋势和模式
- 异常值和离群点
- 对比分析
- 可执行建议
- 推荐可视化

## 使用场景

- 解读电子表格数据
- 为演示准备数据
- 从报告中发现洞察
- 向干系人解释指标
- 月度/季度数据复盘

## 工作流程

1. **理解数据**
   - 每列代表什么？
   - 覆盖哪个时间段？
   - 业务背景是什么？

2. **识别模式**
   - 趋势（上升、下降、稳定）
   - 季节性或周期
   - 变量之间的相关性

3. **找到故事**
   - 核心标题是什么？
   - 有什么令人意外？
   - 有什么值得担心？
   - 机会在哪里？

4. **转化为行动**
   - 这说明什么？
   - 接下来做什么？
   - 这能支持哪些决策？

## 输出格式

# 数据分析：{Dataset Name}

## 核心结论

**{One sentence that captures the most important finding}**

---

## 执行摘要

{2-3 paragraph narrative summary written for a non-technical audience. Focus on what the data means, not just what it shows.}

---

## 关键指标速览

| 指标 | 当前 | 上期 | 变化 | 趋势 |
|--------|---------|----------|--------|-------|
| {metric 1} | {value} | {value} | {+/-}% | {↑↓→} |
| {metric 2} | {value} | {value} | {+/-}% | {↑↓→} |
| {metric 3} | {value} | {value} | {+/-}% | {↑↓→} |

---

## 数据显示了什么

### 趋势 1：{Title}
{Description of the trend with specific numbers}

**为什么重要：** {Business implication}

### 趋势 2：{Title}
{Description of the trend with specific numbers}

**为什么重要：** {Business implication}

### 趋势 3：{Title}
{Description of the trend with specific numbers}

**为什么重要：** {Business implication}

---

## 🔍 重要发现

### 亮点（好消息）
- {Positive finding 1 with data point}
- {Positive finding 2 with data point}

### 关注点（请留意）
- ⚠️ {Concerning finding 1 with data point}
- ⚠️ {Concerning finding 2 with data point}

### 异常（需调查）
- ❓ {Unexpected data point that needs explanation}

---

## 对比

### 与上一周期相比
{How does this compare to last month/quarter/year?}

### 与目标相比
| 指标 | 实际 | 目标 | 差距 |
|--------|--------|--------|-----|
| {metric} | {value} | {value} | {+/-} |

### 与基准相比
{How does this compare to industry/competitor benchmarks if known?}

---

## 相关性与关系

{Any interesting relationships between variables}

- 当 {X} 增加时，{Y} 往往会 {behavior}
- {Variable A} 和 {Variable B} 看起来 {correlated/uncorrelated}

---

## 📊 推荐可视化

1. **{Chart type}** - 用于呈现 {what insight}
2. **{Chart type}** - 用于呈现 {what insight}
3. **{Chart type}** - 用于呈现 {what insight}

---

## 💡 建议

基于此分析：

1. **{Action 1}**
   - 原因：{rationale from data}
   - 影响：{expected outcome}

2. **{Action 2}**
   - 原因：{rationale from data}
   - 影响：{expected outcome}

3. **{Action 3}**
   - 原因：{rationale from data}
   - 影响：{expected outcome}

---

## 此数据引出的问题

- {Question that the data prompts but doesn't answer}
- {Additional data that would be helpful}
- {Follow-up analysis to consider}

---

## 数据质量备注

- **完整性：** {Any missing data?}
- **时间范围：** {What period does this cover?}
- **注意事项：** {Any limitations to note?}
