---
name: snow-incident-rca
description: |
  根据 ServiceNow 事件数据生成 Root Cause Analysis 报告。
  当用户提出“生成 RCA”、“根因分析”、“分析这个事件”、
  “RCA 报告”、“事件复盘”、“5 whys 分析”、“这个事件是什么原因导致的”、"generate RCA", "root cause analysis", "analyze this incident",
  "RCA report", "incident postmortem", "5 whys analysis", or "what caused this incident" 时使用。
  用户可通过粘贴、附加导出文件，或描述事件来提供事件数据。
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
  requires-connector: false
---

# ServiceNow 事件 RCA 生成器

根据 ServiceNow 事件数据生成完整的 Root Cause Analysis 报告 - 无需部署服务器。

## 工作方式

1. 用户提供事件数据（粘贴、附加或描述）
2. 技能分析数据
3. 生成带 CMDB 引用的格式化 RCA 报告

## 无需服务器

此技能使用你直接提供的数据：
- 从 ServiceNow 粘贴事件详情
- 附加导出的 CSV/Excel
- 从 ServiceNow 表单复制
- 口头描述事件

## 适用场景

- 事件后复盘
- 重大事件分析
- 问题管理
- 合规文档
- 服务改进

## 如何提供数据

### 选项 1：粘贴事件字段
从 ServiceNow 复制这些字段：
- Incident Number
- Short Description
- Description
- Priority / Impact / Urgency
- State
- Opened / Resolved dates
- Assignment Group / Assigned To
- Configuration Item (CI)
- Resolution Notes
- Work Notes（关键条目）

### 选项 2：附加导出文件
从 ServiceNow 导出为 CSV 或 Excel，并附加该文件。

### 选项 3：描述事件
告诉我：
- 发生了什么？
- 什么时候开始/结束？
- 影响了什么？
- 如何解决的？
- 涉及哪些系统/CI？

## 工作流

1. **解析事件数据**
   - 提取关键字段
   - 识别受影响的 CI
   - 记录时间线

2. **结构化分析**
   - 影响评估
   - 时间线还原
   - CI 关系映射

3. **生成 RCA**
   - 5 Whys 框架
   - 促成因素
   - 建议

4. **输出报告**
   - 格式化 markdown
   - 可直接用于文档归档

## 输出格式

# Root Cause Analysis 报告

## 事件概览

| 字段 | 值 |
|-------|-------|
| **Incident Number** | {from provided data} |
| **Short Description** | {from provided data} |
| **Priority** | {P1/P2/P3/P4/P5} |
| **Impact** | {1-High/2-Medium/3-Low} |
| **Urgency** | {1-High/2-Medium/3-Low} |
| **State** | {New/In Progress/Resolved/Closed} |
| **Opened** | {date/time} |
| **Resolved** | {date/time} |
| **Duration** | {calculated} |
| **Assignment Group** | {group name} |
| **Assigned To** | {person} |
| **Caller/Affected User** | {user} |

---

## 影响摘要

### 业务影响
- **受影响用户：** {number or scope}
- **受影响服务：** {list services}
- **受影响业务流程：** {processes}
- **财务影响：** {if known}

### 技术影响
- **受影响系统：** {list}
- **数据影响：** {none/read-only/data loss}
- **集成影响：** {downstream effects}

---

## Configuration Item（受影响 CI）

| 属性 | 值 |
|-----------|-------|
| **CI Name** | {from data or ask user} |
| **CI Class** | {Server/Application/Database/Network/Service} |
| **Environment** | {Production/Staging/Dev} |
| **Business Service** | {service name} |
| **Support Group** | {owning team} |

### CMDB 关系
如果用户提供 CI 关系：

**上游（此 CI 依赖）：**
- {Parent CI 1}
- {Parent CI 2}

**下游（依赖此 CI）：**
- {Child CI 1}
- {Child CI 2}

---

## 时间线

| 时间 | 事件 | 来源 |
|------|-------|--------|
| {time} | 首个症状/告警 | {monitoring/user report} |
| {time} | 事件创建 | ServiceNow |
| {time} | 团队介入 | Assignment |
| {time} | 识别根因 | Investigation |
| {time} | 应用修复 | Work notes |
| {time} | 服务恢复 | Verification |
| {time} | 事件解决 | ServiceNow |

---

## 根因分析

### 发生了什么
{Detailed description of the incident based on provided data}

### 直接原因
{The direct trigger that caused the incident}

### 促成因素
| 因素 | 类别 | 详情 |
|--------|----------|---------|
| {factor 1} | {Process/Tech/People/External} | {description} |
| {factor 2} | {category} | {description} |
| {factor 3} | {category} | {description} |

### 5 Whys 分析

1. **为什么 {incident symptom} 会发生？**
   → 因为 {immediate cause}

2. **为什么 {immediate cause} 会发生？**
   → 因为 {contributing factor 1}

3. **为什么 {contributing factor 1} 会发生？**
   → 因为 {contributing factor 2}

4. **为什么 {contributing factor 2} 会发生？**
   → 因为 {underlying cause}

5. **为什么 {underlying cause} 会发生？**
   → 因为 **{ROOT CAUSE}**

### 根因陈述
**{Clear, concise statement of the fundamental root cause}**

---

## 解决方案

### 如何修复
{Description of the resolution from provided data}

### 解决方案类别
- [ ] 配置变更
- [ ] 代码修复
- [ ] 基础设施变更
- [ ] 重启/reboot
- [ ] 回滚
- [ ] 厂商修复
- [ ] 流程变更
- [ ] 其他：{specify}

### 验证
{How was the fix verified to be working?}

---

## 建议

### 立即行动（本周）
| # | 行动 | 负责人 | 优先级 | 到期日 |
|---|--------|-------|----------|-----|
| 1 | {specific action} | {assign} | High | {date} |
| 2 | {specific action} | {assign} | High | {date} |

### 短期改进（本月）
| # | 改进 | 类别 | 工作量 |
|---|-------------|----------|--------|
| 1 | {improvement} | {Process/Tech/Monitoring} | {H/M/L} |
| 2 | {improvement} | {category} | {effort} |

### 长期改进（本季度）
| # | 改进 | 类别 | 工作量 |
|---|-------------|----------|--------|
| 1 | {strategic improvement} | {category} | {effort} |

---

## 预防

### 如何防止再次发生
1. {Prevention measure 1}
2. {Prevention measure 2}
3. {Prevention measure 3}

### 监控改进
| 监控项 | 告警阈值 | 负责人 |
|-----------------|-----------------|-------|
| {metric} | {threshold} | {team} |

### 流程变更
- {Process change 1}
- {Process change 2}

---

## 相关记录

### Problem Ticket
**创建 Problem？** Yes / No
**Problem Statement：** {if yes, suggested problem description}

### Change Requests
如果需要通过变更防止再次发生：
| 变更 | 类型 | 风险 | 目标日期 |
|--------|------|------|-------------|
| {change} | {Normal/Standard/Emergency} | {H/M/L} | {date} |

### Knowledge Article
**创建 KB？** Yes / No
**Suggested Title：** {title}
**Key Points：** {what to document}

---

## 经验教训

1. **做得好的方面：**
   - {positive aspect of response}
   - {another positive}

2. **可以改进的方面：**
   - {improvement area}
   - {another area}

3. **关键启示：**
   {Single most important lesson from this incident}

---

## 附录

### Work Notes 摘要
{Key work notes from incident if provided}

### 引用的附件
{List any attachments or evidence}

### 参与人员
| 角色 | 姓名 |
|------|------|
| Incident Manager | {name} |
| Technical Lead | {name} |
| Resolver | {name} |

---

## 签署确认

| 角色 | 姓名 | 日期 |
|------|------|------|
| RCA 作者 | | |
| 技术评审人 | | |
| 服务负责人 | | |

---

*由 Copilot Cowork 的 ServiceNow RCA Skill 生成*

## 示例提示

"Generate RCA for this incident: [paste incident details]"

"Create root cause analysis - incident INC0010001, server crashed due to memory leak, affected 500 users for 2 hours"

"Analyze this incident and create RCA report [attach CSV export]"

"5 whys analysis for a database outage that happened yesterday"
