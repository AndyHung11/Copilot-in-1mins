# Copilot Cowork 技能包（简体中文）

这里是 19 个 Copilot Cowork 自定义技能的简体中文版 SKILL.md。

## 怎么用
1. 每个目录就是一个技能，里面的 `SKILL.md` 就是技能本体。
2. 把整个目录放进 Cowork 的技能目录，或在 Cowork 里直接上传该 `SKILL.md`。
3. 目录名必须与文件内 `name:` 字段一致，否则技能会加载失败。

## 关于中文版
- `name:` 一律保持英文 kebab-case —— 那是技能的标识符，Cowork 不接受中文或大写。
- `description:` 同时保留原文的英文触发词并补上中文触发词，所以中英文都能调用。
- 工具名称、参数、字段名、文件路径一律保持英文，因为那些是实际要调用的东西。

## 技能清单
- `30-60-90-plan`
- `contract-review`
- `cowork-cost-estimator`
- `cowork-library-search`
- `data-storyteller`
- `exec-summary`
- `file-organizer`
- `frontend-design`
- `hr-engagement-strategy`
- `inbox-triage`
- `meeting-followup`
- `newsletter-builder`
- `onboarding-checklist`
- `oof-prep`
- `permissions-audit`
- `sharepoint-finder`
- `snow-incident-rca`
- `teams-digest`
- `weekly-wrap`
