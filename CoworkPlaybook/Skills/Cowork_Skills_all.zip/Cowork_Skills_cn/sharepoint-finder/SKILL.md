---
name: sharepoint-finder
description: |
  搜索 SharePoint 和 OneDrive，查找文档、文件和信息。
  当用户询问“找文档”、“搜索 SharePoint”、“文件在哪里”、“帮我找”、“找演示文稿”、“定位电子表格”、"find document", "search SharePoint", "where is the file",
  "look for", "find the presentation", or "locate the spreadsheet" 时使用。
license: MIT
metadata:
  author: Ash Sisalem
  version: "1.0"
  plugin: document-intelligence
  m365-services: [SharePoint, OneDrive, Graph, Search]
---

# SharePoint 文件搜索
跨 SharePoint 站点和 OneDrive 搜索，以定位文件和信息。

## M365 集成

- **SharePoint:** 站点内容、文档库、列表
- **OneDrive:** 个人文件和共享项目
- **Microsoft Search:** 跨 M365 的统一搜索
- **Graph:** 文件元数据、共享信息、近期活动

## 此 Skill 的功能

帮助查找：
- 按名称、内容或主题查找文档
- 按类型查找文件（演示文稿、电子表格等）
- 最近或经常访问的文件
- 与特定人员共享或由特定人员共享的文件
- 特定站点或文档库中的内容

## 适用场景

- 记不起文件保存在哪里
- 查找某个主题的文档
- 查找某人共享的文件
- 定位文档的最新版本
- 搜索模板或示例

## 搜索策略

1. **按名称：** 精确或部分文件名
2. **按内容：** 文档内的词语或短语
3. **按元数据：** 作者、日期、文件类型
4. **按位置：** 特定站点或文档库
5. **按活动：** 最近修改或共享

## 输出格式

# 搜索结果

## 查询
**查找内容：** {user's search intent}
**搜索词：** {actual search query used}
**范围：** {All M365 / SharePoint / OneDrive / Specific site}

---

## 🎯 最佳匹配

### 1. {Document Title}
| 属性 | 值 |
|----------|-------|
| **类型** | {Word, Excel, PowerPoint, PDF, etc.} |
| **位置** | {Site > Library > Folder} |
| **修改时间** | {date}，由 {person} 修改 |
| **大小** | {size} |

**预览：** {First few lines of content or description}

**操作：** [打开]({link}) | [共享]({link}) | [复制链接]({link})

---

### 2. {Document Title}
{Same structure}

---

### 3. {Document Title}
{Same structure}

---

## 📁 相关位置

这些位置可能包含你要找的内容：

| 站点/文档库 | 描述 | 链接 |
|--------------|-------------|------|
| {Site name} | {what it contains} | [打开]({link}) |
| {Library name} | {description} | [打开]({link}) |

---

## 🕐 近期活动

你或你的团队最近处理过且匹配此搜索的文件：

| 文件 | 操作 | 时间 | 人员 |
|------|--------|------|-------|
| {file} | {Modified/Viewed/Shared} | {time} | {person} |

---

## 🔍 搜索提示

如果这些结果不是你需要的，可以尝试：

1. **更具体：** 添加 "{suggested term}"
2. **按类型：** "filetype:pptx {topic}"
3. **按作者：** "author:{name}"
4. **按日期：** "modified:last week"
5. **按位置：** 在 {suggested site} 中搜索

---

## 没有结果？

如果文件没有出现在搜索结果中：
- 它可能在私人 OneDrive 中（未与你共享）
- 它可能是新创建的（搜索索引可能有延迟）
- 检查你是否有该站点/文档库的访问权限
- 尝试其他拼写或相关词

---

## 快速操作

- 🆕 **新建文档** 于 {suggested location}
- 📤 **请求访问权限** 至 {restricted location}
- 👤 **询问 {person}** 可能谁有这个文件
