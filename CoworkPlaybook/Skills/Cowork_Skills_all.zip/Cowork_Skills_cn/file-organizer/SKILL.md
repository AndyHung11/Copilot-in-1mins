---
name: file-organizer
description: |
  为 OneDrive 和 SharePoint 文件提供整理与清理建议。
  当用户提出“整理我的文件”、“清理 OneDrive”、“文件结构”、
  “文件夹整理”、“清理杂乱文件”、“整理文档”、"organize my files", "clean up OneDrive", "file structure",
  "folder organization", "declutter files", or "organize documents" 时使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: document-intelligence
  m365-services: [OneDrive, SharePoint, Graph]
---

# 文件整理建议
分析你的 M365 文件，并给出整理建议。

## M365 集成

- **OneDrive:** 个人文件分析
- **SharePoint:** 文档库整理
- **Microsoft Graph:** 文件元数据、活动

## 此技能的作用

提供：
- 当前状态分析
- 重复文件检测
- 旧文件/长期未用文件识别
- 文件夹结构建议
- 命名规范建议
- 清理行动计划

## 适用场景

- OneDrive 杂乱，难以浏览
- 从零开始整理
- 年度文件清理
- 文件迁移前
- 设置新的项目结构

## 输出格式

# 文件整理报告

## 当前状态分析

### 位置：{OneDrive or SharePoint site}

| 指标 | 值 |
|--------|-------|
| **文件总数** | {count} |
| **总大小** | {GB} |
| **文件夹** | {count} |
| **最大文件夹深度** | {levels} |
| **根目录中的文件** | {count} ⚠️ {if high} |

---

## 📊 文件分布

### 按类型
| 类型 | 数量 | 大小 | 占总量百分比 |
|------|-------|------|------------|
| 文档（.docx, .pdf） | {n} | {size} | {%} |
| 电子表格（.xlsx） | {n} | {size} | {%} |
| 演示文稿（.pptx） | {n} | {size} | {%} |
| 图片 | {n} | {size} | {%} |
| 其他 | {n} | {size} | {%} |

### 按时间
| 时间 | 数量 | 建议 |
|-----|-------|----------------|
| < 30 days | {n} | 活跃 - 保持有序 |
| 30-90 days | {n} | 复核相关性 |
| 90-365 days | {n} | 可归档候选项 |
| > 1 year | {n} | 归档或删除 |

### 按大小（最大文件）
| 文件 | 大小 | 位置 | 上次访问 |
|------|------|----------|---------------|
| {filename} | {size} | {path} | {date} |
| {filename} | {size} | {path} | {date} |
| {filename} | {size} | {path} | {date} |
