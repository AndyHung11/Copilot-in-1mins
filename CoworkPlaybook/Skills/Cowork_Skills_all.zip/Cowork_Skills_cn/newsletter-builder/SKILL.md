---
name: newsletter-builder
description: |
  面向内部或外部受众创建结构化的新闻简报草稿。
  当用户说“写新闻简报”、“团队更新邮件”、“月度简报”、“公司内刊”、“内部沟通”、
  "write newsletter", "team update email", "monthly digest",
  "company newsletter", or "internal comms" 时使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: content-studio
---

# 电子报草稿生成器
生成结构清晰、内容有吸引力的新闻简报。

## 此技能的作用

创建新闻简报草稿，包括：
- 吸引注意力的主题行
- 清晰的版块结构
- 便于快速浏览的格式
- 行动号召
- 互动元素

## 使用时机

- 每周/月度团队更新
- 面向全公司的沟通
- 客户新闻简报
- 产品更新
- 社区动态汇总

## 必要信息

1. 新闻简报类型（内部/外部）
2. 受众
3. 频率（每周、每月等）
4. 需要包含的关键主题/更新
5. 语气（正式、友好、有活力）
6. 任何固定栏目

## 已应用的新闻简报最佳实践

- **主题行:** 价值清晰，少于 50 chars
- **预览文本:** 与主题行互补
- **便于快速浏览:** 标题、项目符号、短段落
- **一个主要 CTA:** 不让读者负担过重
- **移动端优先:** 大多数人在手机上阅读

## 输出格式

# 新闻简报草稿: {Edition/Date}

## 主题行选项
1. {Option 1 - benefit-focused}
2. {Option 2 - curiosity-driven}
3. {Option 3 - news-focused}

**预览文本:** {The text that appears after subject in inbox}

---

## 新闻简报正文

### 页眉
{Newsletter Name} | {Date/Edition}

---

### 👋 你好 {Name/Team},

{Brief, warm opening. 1-2 sentences that set the tone and preview what's inside.}

---

### 📣 重大新闻 / 焦点
**{Headline}**

{The most important update or story. 2-3 paragraphs max. Include why it matters to the reader.}

{CTA if applicable: Learn more → }

---

### 📊 更新与亮点

**{Update 1 Title}**
{Brief description. 2-3 sentences.}

**{Update 2 Title}**
{Brief description. 2-3 sentences.}

**{Update 3 Title}**
{Brief description. 2-3 sentences.}

---

### 🎉 成果与认可

- {Shoutout or celebration 1}
- {Shoutout or celebration 2}
- {Milestone or achievement}

---

### 📅 即将发生

| 日期 | 活动 |
|------|-------|
| {date} | {event} |
| {date} | {event} |
| {date} | {event} |

---

### 💡 快速提示 / 你知道吗？

> {Useful tip, fact, or insight relevant to your audience}

---

### 📚 资源 / 链接

- [{Resource 1}]({link})
- [{Resource 2}]({link})
- [{Resource 3}]({link})

---

### 💬 反馈角

{Question to engage readers or request for input}

[回复分享你的想法 →]

---

### 结尾

{Brief sign-off. Thank them, preview next edition, or inspiring close.}

祝好,
{Name/Team}

---

## 页脚
{Unsubscribe link if external} | {Contact info} | {Social links}

---

## 需跟踪的指标
- 打开率（目标: >40% internal, >20% external）
- 点击率（目标: >10%）
- 回复率
- 退订数

## 发送前检查清单
- [ ] 主题行已测试
- [ ] 所有链接可正常访问
- [ ] 图片可正常加载
- [ ] 已检查移动端预览
- [ ] 已向自己发送测试邮件
- [ ] 已安排在最佳时间发送