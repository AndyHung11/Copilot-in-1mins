---
name: meeting-followup
description: |
  从用户最近一次会议中提取行动项和决策，并起草发给参会人的
  会后跟进邮件。当用户说“发送我上个电话会的跟进”、“帮我起草上次会议纪要”、“跟进那场会”、“发送站会行动项”、“给参会人写一封复盘邮件”、"send the follow-up from my last call",
  "draft a recap of my last meeting", "follow up on that meeting", "send action items from
  the standup", or "write a recap email to attendees" 时使用。
  不要用于主动会议准备 — 请改用 meeting-intel 或 schedule-meeting。
  不要用于与特定会议无关的通用干系人更新 — 请改用
  stakeholder-comms。
cowork:
  category: communication
  icon: Mail
---

## 概览

识别用户最近完成的会议，从会议转录中提取决策和行动项（如果没有转录，则从该时间窗口周边的聊天/邮件上下文中提取），然后起草一封发给参会人的复盘邮件，供用户检查并发送。

## 适用场景

- 用户刚结束一个电话会，想发送复盘
- 用户说“跟进”、“复盘”、“行动项”，但没有指明哪场会议
- 用户希望提醒参会人各自承诺的事项

## 不适用场景

- 为即将召开的会议做准备 → 使用 `meeting-intel`
- 与会议无关的通用团队更新 → 使用 `stakeholder-comms`
- 安排新会议 → 使用 `schedule-meeting`

## 快速开始

```
用户: “发送我上个电话会的跟进”
1. ListCalendarView 查询过去 6 小时 → 选择最近结束的会议
2. ListMeetingTranscripts 查询该会议 → 如可用则 GetMeetingTranscript
3. 如无转录：搜索该时间窗口周边的 Teams/邮件上下文
4. 提取：决策、行动项（负责人 + 截止日期）、开放问题
5. 使用 CreateDraftMessage 起草发给参会人的邮件，并展示给用户检查
```

## 核心说明

### 步骤 1：识别会议
- 根据用户上下文解析当前时间
- 调用 `ListCalendarView`，start = 8 hours ago，end = now，不设置 `is_organizer=false`（两类都包含）
- 选择用户参加过且最近结束的事件（跳过已拒绝/已取消）
- 如果有多个近期会议，使用 `AskUserQuestion`，将候选会议作为选项让用户选择

### 步骤 2：获取内容
- 如果事件有 `onlineMeeting.joinUrl`，调用 `ListMeetingTranscripts`，然后调用 `GetMeetingTranscript`
- 如果没有转录：调用 `SearchM365`，使用 `sources=["teams","email"]`，范围限定当天，并以会议主题作为查询
- 如果仍然找不到内容：告知用户未找到内容，并提供仅根据会议主题 + 参会人起草的选项

### 步骤 3：提取结构
从转录或上下文中提取：
- **决策** — 已达成一致的事项
- **行动项** — 负责人、任务、截止日期（如果提到）
- **开放问题** — 仍未解决的事项
- **下一步** — 后续会议或检查点

绝不编造负责人或日期。如果不清楚，标记为 `[owner TBD]`。

### 步骤 4：起草邮件
使用 `CreateDraftMessage`，并设置：
- **To:** 原始参会人（排除用户）
- **Subject:** `Recap: <meeting subject>`
- **Body** 结构：
  ```
  感谢大家参加今天的 <meeting>。简要复盘如下。

  决策
  - ...

  行动项
  - <Owner>: <task> — <due date>

  开放问题
  - ...

  如有遗漏，请告诉我。
  ```

将草稿展示给用户，并让他们在发送前编辑。除非用户明确说 "send it"，否则不要调用 `SendDraftMessage`。

## 护栏

- 绝不编造来源中没有的行动项、负责人或日期
- 始终创建草稿（`CreateDraftMessage`）— 绝不直接发送
- 如果会议是私密/1:1，起草前先确认，确保用户希望留下书面记录
- 对任何敏感人事讨论（薪酬、绩效）进行遮蔽 — 改为提示用户
