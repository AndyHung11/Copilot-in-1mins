---
name: teams-digest
description: |
  汇总你可能错过的 Teams 频道帖子和聊天信息。
  当用户说“Teams 我错过了什么”、“Teams 摘要”、“频道更新”、“帮我补一下 Teams 进展”、
  “未读 Teams 信息”、“Teams 简报”、"what did I miss in Teams", "Teams summary", "channel updates",
  "catch me up on Teams", "unread Teams messages", or "Teams digest" 时使用。
license: MIT
metadata:
  author: Cowork Library
  version: "1.0"
  plugin: teams-hub
  m365-services: [Teams, Graph]
---

# Teams 未读摘要
汇总频道和聊天中的 Teams 活动情况。

## M365 集成

- **Microsoft Teams:** 频道帖子、聊天信息、回应
- **Microsoft Graph:** 活动动态、提及、回复

## 此技能的作用

汇总：
- 按重要程度排序的未读频道帖子
- 需要关注的私聊信息
- 对你的 @提及和回复
- 关键决策和公告
- 对话中的待办事项

## 使用时机

- 休假或请假返岗后
- 早晨补进展例行处理
- 连续开会之后
- 每日收尾复盘
- 团队会议前

## 工作流

1. **扫描活动**
   - 检查你所在的所有频道
   - 查看私聊信息和群聊
   - 找出 @提及和回复

2. **确定优先级**
   - 先处理紧急/重要信息
   - 找出需要回复的信息
   - 最后处理 FYI 事项

3. **生成摘要**
   - 提取关键点
   - 识别待办事项
   - 记录已作出的决策

## 输出格式

# Teams 摘要

**时间范围:** {timeframe, e.g., "Last 24 hours" or "Since Monday"}
**上次检查:** {timestamp}

---

## 🔴 需要你关注

### @提及
| 时间 | 频道/聊天 | 来自 | 信息 |
|------|--------------|------|---------|
| {time} | {location} | {person} | {summary + link} |

### 等待回复的私聊信息
| 来自 | 预览 | 时间 |
|------|---------|------|
| {name} | {message preview} | {time} |

### 你帖子的回复
| 话题串 | 最新回复 | 来自 |
|--------|--------------|------|
| {topic} | {summary} | {name} |

---

## 📢 按频道列出的重要更新

### #{channel-name-1}
**活动量:** {High/Medium/Low} ({n} messages)

**关键帖子:**
- **{Author}:** {Summary of important post}
  - 回应: {👍 n, etc.}
  - {Link to message}

- **{Author}:** {Summary of another post}
  - {Link}

**已作出的决策:**
- {Decision 1}
- {Decision 2}

---

### #{channel-name-2}
**活动量:** {level}

**关键帖子:**
- {summaries}

---

## 💬 群聊

### {Chat name or participants}
**信息数:** {n} new
**摘要:** {What was discussed}
**待办事项:** {Any tasks mentioned}

---

## 📋 发现的待办事项

| 事项 | 来源 | 分配给 | 截止日期 |
|------|--------|-------------|----------|
| {task} | #{channel} | {you/person} | {if mentioned} |
| {task} | {chat} | {person} | {date} |

---

## 📊 活动摘要

| 频道 | 新帖子 | 你的参与情况 |
|---------|-----------|-------------------|
| #{channel1} | {n} | {replied/reacted/none} |
| #{channel2} | {n} | {status} |
| #{channel3} | {n} | {status} |

---

## 🎯 建议操作

1. **回复 {person}** 在 #{channel} 关于 {topic}
2. **确认收到** {important announcement}
3. **跟进** {thread}

---

## ℹ️ 仅供参考（低优先级）

{Brief list of lower-priority updates that don't require action}

- #{channel}: {brief summary}
- #{channel}: {brief summary}