---
name: cowork-cost-estimator
description: |
  为当前登录的单个用户估算 Microsoft Copilot Cowork 的月度和年度授权成本。根据工作者类别对该用户进行分类，用正确的提示词组合默认值填写 Cowork 成本估算表，重新计算公式，并交付成本摘要卡、已填写的 Excel 文件以及可直接发送的管理员报告。

  当用户提出“估算我的 Cowork 费用”、“Cowork 大概要多少钱”、“计算我的 Copilot Credits”、“我用 Cowork 要花多少钱”、“Cowork 预算是多少”、“Cowork 成本计算器”、“模拟 Cowork 场景”、“Cowork 授权成本”、“每个用户的 Cowork 成本是多少”、"estimate my Cowork cost", "how much would Cowork cost",
  "calculate my Copilot Credits", "how much would I pay for Cowork",
  "what is the Cowork budget", "cost calculator for Cowork",
  "model Cowork scenarios", "Cowork licensing cost",
  "how much does Cowork cost per user" 时使用。

  不要用于一般 Microsoft 365 订阅价格、Azure 成本管理、Power BI 授权问题，或非 Cowork AI 工具成本分析（GitHub Copilot、Azure OpenAI）。
cowork:
  category: analysis
  icon: Calculator
---

# Copilot Cowork 成本估算器

使用 Microsoft Cowork 定价计算器表格，估算当前登录的单个用户每月 Copilot Credit 消耗量和 USD 成本。

## 不适用场景

- 一般 Microsoft 365 或 Azure 定价问题 — 直接参考产品页面回答
- 非 Cowork AI 授权（GitHub Copilot、Azure OpenAI、Copilot for M365）— 直接回答
- 实际发票核对或历史支出报告 — 使用计费门户

## 工作流

### 步骤 1 — 先询问三个问题（阻塞）

此技能始终只估算 **单个用户 — 当前登录用户**。开始其他操作前，先询问这三个问题（使用 `AskUserQuestion`）。它们决定后续工作流是否继续 — 不得跳过：

1. **估算器文件** — 请用户上传 Cowork 估算器工作簿（`CustomerCoworkEstimator.xlsx`）。先检查 `input/`；如果已经存在，就直接使用并跳过此问题。否则等待上传后再继续 — 如果缺失，不得用代表性数据或占位数据替代。
2. **计算周期** — 询问估算覆盖多少天。提供 **30 days**（一个月）、**90 days**（一个季度）和 **365 days**（一年）作为选项，并通过 "Other" 接受自定义天数。如果用户不选择，默认用 30 days。将此值记为 `N`，并在步骤 3–4 中持续沿用。
3. **月度上限** — 询问管理员为该用户设置的月度 Copilot Credit 上限。该上限始终以 **每月 Copilot Credits** 表示（绝不使用 USD）。通过 "Other" 接受自定义数字，并允许选择 "No limit / not sure" 跳过。将此值记为 `L`。如果已提供，在步骤 4 中用它与估算的月度 Credits 比较；如果跳过，则省略上限比较。

然后根据上下文解析其余输入，不再询问：

1. **用户身份**：从系统上下文读取当前登录用户的姓名、职务和部门。
2. **范围**：始终正好是 1 个用户 — 当前登录用户。此处不要处理团队或组织级估算。
3. **工作者类别映射** — 将当前登录用户职务中的关键词映射到计算器四个类别中的且仅一个类别：

   | 职务关键词 | 类别 | 计算器行 |
   |--------------------|----------|----------------|
   | Architect, Engineer, Developer, SRE, DevOps, Data Scientist, IT, Technical | Technical Workers | D14 |
   | Sales, Account Executive, Customer Success, Account Manager, Pre-Sales, SE | Customer-Facing Knowledge Workers | D13 |
   | Manager, Director, VP, Head of, Principal, C-suite, Partner, GM, Lead | Managers & Senior Leaders | D15 |
   | 所有其他职能（analyst, coordinator, HR, legal, finance, marketing, ops） | Corporate Knowledge Workers | D12 |

### 步骤 2 — 填写计算器

使用 `openpyxl` 打开 `input/CustomerCoworkEstimator.xlsx`，并在 Budget 工作表中写入用户数量：

- `D12` = Corporate Knowledge Workers count
- `D13` = Customer-Facing Knowledge Workers count
- `D14` = Technical Workers count
- `D15` = Managers & Senior Leaders count

除非用户明确提供覆盖值，否则保留所有默认提示词组合值（D23:F26）和每次提示词的 Credits 值（D33:D35）。

样式约定：
- 输入单元格：按财务模型惯例使用蓝色字体（RGB `0000FF`、加粗）
- 在每个已填写行旁边的 H 列添加简短注释（例如 `← 1 user: Rajesh Jayaraj, Cloud Solution Architect`）
- 将 H 列加宽到 52 个字符，确保注释便于阅读

将输出保存到 `output/CoworkEstimator_<FirstName>.xlsx`（使用当前登录用户的名字）。

### 步骤 3 — 重新计算并抽查

运行 `python scripts/recalc.py output/CoworkEstimator_<FirstName>.xlsx`，并确认 `status: success` 且公式错误为零。

报告前，先通过手工计算核对关键计算值：
- `G25`（Technical Workers credits/user）= `(D25×D33) + (E25×D34) + (F25×D35)`
- `D41`（月度总 Credits）= `SUMPRODUCT(D12:D15, G23:G26)`
- `D42`（月度 USD）= `D41 / 100`
- `D43`（每用户/月成本）= `D42 / SUM(D12:D15)`

然后按步骤 1 请求的 `N` 天周期进行折算。计算器中的数字覆盖完整月份；使用 365 天年度口径换算，确保 `N = 365` 能与年度总额对齐：
- 每日 Credits = `(D41 × 12) / 365`
- **周期 Credits** = 每日 Credits × `N`
- **周期 USD** = 周期 Credits / 100
保留月度和年度数字作为参考；不要为了这个周期计算而覆盖表格中的月度公式 — 只需在旁边计算周期值。

### 步骤 4 — 显示结果卡片（始终在屏幕上）

**始终渲染屏幕上的 `render_ui` 摘要卡**（使用 `render-ui` skill）。这张图形卡片是**用户看到的主要输出** — 每次运行都要渲染，并且必须在步骤 5 生成 Word 报告之前渲染。绝不能跳过卡片直接生成报告。卡片包含：
- 用户分类：角色 → 工作者类别
- **计算周期**：`N` days（按步骤 1 的选择）
- **请求周期的成本**：`N` 天内的 Copilot Credits 和 USD
- 估算月度 Credits
- 月度成本（估算）
- 年度成本（估算）
- 使用的提示词组合（每月 Light / Medium / Heavy）
- **月度上限**（仅在已提供 `L` 时）：Credit 上限、**估算月度 Credits** 与该上限的对比，以及**剩余**（或**超出**）Credits。请与*月度*估算值（`D41`）比较 — 绝不要与 `N` 天周期数字比较，因为它们不是同一口径。若估算值超出上限，请明确标注。

**在同一张卡片中加入图表**，让结果一目了然（使用 `render-ui` skill 的图表元素）：
- **已提供月度上限（`L`）** → 使用 `Chart.Gauge` 展示**估算月度 Credits 相对于上限 `L`**，让用户立即判断是否在上限内或已超出。
- **无上限** → 使用 `Chart.Donut` 展示**按提示词类型划分的 Credits**（Light / Medium / Heavy），突出 Heavy 提示词这一成本驱动项。
- 用 Credits（或 USD）数值标注每个分段，并在每次运行中保持提示词类型颜色顺序一致。

**上限状态颜色（仅在已提供 `L` 时）** — 按估算月度 Credits 与 `L` 的对比，为仪表值、上限指标和任何状态徽章着色：
- **绿色** — 未超上限：估算值 ≤ `L` 的 80%
- **琥珀色** — 接近上限：估算值在 `L` 的 80% 到 100% 之间（含）
- **红色** — 已超上限：估算值 > `L`

在颜色旁用文字说明状态（例如 "Within limit", "Approaching limit", "Over limit"），确保不依赖颜色也能正确理解。

卡片后接：
1. 文件引用：`output/CoworkEstimator_<FirstName>.xlsx`
2. 一行关键洞察：指出最大的单一成本驱动项（通常是 Technical Workers 的 Heavy 提示词）
3. 披露说明：无法通过 Microsoft 365 APIs 访问实际会话日志 — 使用 Microsoft Frontier 默认提示词组合作为代理
4. 场景建议："Want me to run Light-skew and Heavy-skew scenarios to see the cost range?"

### 步骤 5 — 生成管理员报告（仅 Word 文档）

卡片显示在屏幕后，生成可共享的报告，且**只能生成 Word 文档**（`.docx`）— 不要生成 PDF、HTML、内联副本或邮件版本。使用 `docx` skill 生成 `output/CoworkCostReport_<FirstName>.docx` — 这是一页式清晰报告，用户可转发给管理员（例如用于申请预算或确定 Credit 上限），包含：

- **页眉**：标题（"Microsoft Copilot Cowork — Cost Estimate"）、编制人（当前登录用户的姓名、职务、部门）和日期。
- **目的行**：一句话说明分享目的（例如预算审批 / 月度上限复核）。
- **摘要表**：用户（角色 + 工作者类别）、计算周期（`N` days）、周期估算成本、估算月度 Credits、月度成本（估算）和年度成本（估算）。
- **上限状态提示**（仅在已提供 `L` 时）：月度上限、估算月度 Credits 与上限对比、剩余/超出，以及状态文字 — 按相同的 80% / 80–100% / 超上限阈值，使用绿色 / 琥珀色 / 红色标注。
- **假设与披露**：使用的提示词组合，以及 Frontier 默认代理说明（无法通过 M365 APIs 访问会话日志；这是方向性估算，不构成计费承诺）。
- **请求事项**：简短收尾句（例如“请求审批上述月度上限 / 预算”）。

文档创建后，向用户确认 Word 报告已保存在 `output/`，可以分享给管理员（通过附加到邮件或 Teams 信息）。不要起草或发送邮件，也不要用任何其他格式生成报告 — Word 文档是唯一报告交付物。

## 输出格式

| 交付物 | 位置 | 说明 |
|----------|----------|-------------|
| Excel 文件 | `output/CoworkEstimator_<FirstName>.xlsx` | 已填写的计算器，包含蓝色输入单元格和 H 列注释 |
| 摘要卡 | 内联（`render_ui`） | **始终显示。** 周期成本（N 天内）、估算月度 Credits、月度 USD、年度 USD，以及图表（用量对上限仪表，或提示词类型环形图） |
| 管理员报告 | `output/CoworkCostReport_<FirstName>.docx` | 唯一报告交付物 — 可分享给管理员的 Word 一页式报告（无 PDF/HTML/email 版本） |
| 场景建议 | 内联文本 | 建议模拟乐观与保守提示词组合 |

## 定价参考（Microsoft Frontier 默认值，5/27/2026）

**每次提示词的 Credits（计算器步骤 3）：**

| 提示词类型 | Credits | Cost @ list price |
|-------------|---------|-------------------|
| Light | 125 | $1.25 |
| Medium | 500 | $5.00 |
| Heavy | 1,200 | $12.00 |

Conversion rate: **100 Copilot Credits = $1 USD**（list price）。Model baseline: Anthropic Opus 4.8。

**每用户默认月度提示词组合（计算器步骤 2）：**

| Category | Light | Medium | Heavy | Credits/user/mo |
|----------|-------|--------|-------|-----------------|
| Corporate Knowledge Workers | 22 | 11 | 5 | 14,250 |
| Customer-Facing Knowledge Workers | 17 | 13 | 5 | 14,625 |
| Technical Workers | 12 | 9 | 14 | 22,800 |
| Managers & Senior Leaders | 13 | 6 | 3 | 8,225 |

## 护栏

- 绝不编造用户数量、提示词数量或成本数字 — 只能使用用户提供的信息，或表格中的 Frontier 默认值。
- 不要把计算值硬编码到 Excel 输出中 — 保留 Excel 公式，确保文件仍可编辑。
- 始终披露这是方向性预算估算，不构成计费承诺。
- 始终披露无法通过 Microsoft 365 APIs 访问实际会话日志；默认提示词组合会作为代理使用。
- 始终先要求用户上传 `CustomerCoworkEstimator.xlsx`（除非它已在 `input/` 中）— 这是阻塞问题；不得用代表性数据或占位数据替代。
- 绝不编造计算周期 — 使用用户提供的天数；仅当用户不选择时，默认用 30 days。
- 绝不编造月度上限 — 只使用用户提供的上限。如果用户跳过，请省略上限比较和上限仪表，且不要假设默认上限。
- 提供上限时，始终按一致规则着色并标注状态：绿色 ≤ 上限的 80%，琥珀色 80–100%，红色为超出上限 — 并始终用文字说明状态，不只靠颜色表达。
- 始终先在屏幕上显示图形化 `render_ui` 摘要卡 — 这是面向用户的主要输出，每次运行都必须出现，绝不能跳过并直接生成报告。
- 管理员报告只能生成 Word 文档（`output/CoworkCostReport_<FirstName>.docx`）— 绝不能是 PDF、HTML、内联副本或邮件。不要起草或发送邮件；由用户自己分享 Word 文件。
- 此技能仅支持单用户 — 始终估算当前登录用户，并将其分类到且仅一个工作者类别。不要处理团队或组织级估算。
- 月度上限始终以 Copilot Credits 表示（绝不使用 USD）— 不要转换或重新解释。只将它与估算的*月度* Credits 比较，不要与周期数字比较。
- "Estimated monthly Credits" 和 "Monthly cost (est)" 是基于默认提示词组合的预测，不是实际使用量 — 请标注为估算值，绝不要表述为已测量消耗。
- 始终将管理员报告作为用户可审阅的交付文件生成；不要自动发送给管理员，也不要猜测收件人。只有在用户指定收件人后，才创建邮件草稿，并保留为草稿由用户发送。
