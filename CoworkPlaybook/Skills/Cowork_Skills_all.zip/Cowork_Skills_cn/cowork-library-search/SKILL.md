---
name: cowork-library-search
description: |
  搜索 ABS GSA SharePoint 站点上的 Copilot Cowork Library，并返回匹配项目，以及指向存放附加技能文件的 SharePoint 项目页的 "Download" 链接。
  支持的筛选条件：category（Skill / Plugin / Prompt）、persona（Knowledge workers, Sales, Management, Executives, Operations 等）、industry（Cross Industry, Legal, Retail 等）、customer-ready 标记（true/false）、匹配 Title 或 Description 的关键词，以及用于查看近期内容的 modified-after 日期（"what's new this week"）。
  当用户说“搜索 cowork library”、“在 gallery 里找技能”、“有哪些 sales 可用的 plugins”、“列出 executives 的 prompts”、“查找会议相关的 cowork 项目”、“显示 customer-ready skills”、“retail 的 cowork gallery 里有什么”、“有没有 managers 用的 plugins”、“查询 [topic] 相关 library items”、“这周 cowork library 有什么新内容”、"search the cowork library", "find skills in the gallery", "what plugins are available for sales", "list prompts for executives", "find cowork items about meetings", "show customer-ready skills", "what's in the cowork gallery for retail", "any plugins for managers", "look up library items about [topic]", or "what's new in the cowork library this week" 时使用。
  不要使用此技能来 (a) 列出用户的个人 skills — 请使用 `skills` skill；(b) 描述内置系统 skills — 直接回答；(c) 泛化搜索 OneDrive 或 SharePoint 文件 — 改用 `SearchM365` 并设置 `sources=["files"]`。此技能仅限于 Copilot Cowork Library SharePoint 列表。
cowork:
  category: research
  icon: Search
---

# Cowork Library 搜索

搜索 Copilot Cowork Library SharePoint 列表，并返回匹配项目及下载链接。

## Library 位置

- **站点:** ABS - Global Solution Architects
- **站点 ID:** `microsoft.sharepoint-df.com,243ad53f-1b98-4147-8162-7b1557299391,8b86e36e-e48e-4fda-9fe8-c1d6eab2b3ab`
- **列表:** Copilot Cowork Library
- **列表 ID:** `list_7` (alias) / `6c667e0a-5882-453e-9127-d70532841e28` (GUID)
- **Gallery URL:** https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/Cowork%20Full%20Gallery.aspx
- **项目查看模式:** `https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/DispForm.aspx?ID={id}` — 这是 "Download" 目标（可访问附加技能文件的 SharePoint 页面）。

## 工作流

### 步骤 1 — 捕获条件

将用户请求解析成结构化筛选条件。支持的条件：

| 条件 | 取值 |
|-----------|--------|
| `category` | `Skill`, `Plugin`, `Prompt` |
| `persona` | `Knowledge workers`, `Sales`, `Management`, `Executives`, `Operations`, etc. |
| `industry` | `Cross Industry`, `Legal`, `Retail`, etc. |
| `customer_ready` | `true` / `false` |
| `keyword` | 自由文本 — 与 `Title` 和 `Description` 进行匹配（不区分大小写） |
| `modified_after` | ISO 日期（例如 `2026-05-20`）— 仅保留 `Modified >= date` 的项目 |

如果用户只提供了一个主题短语（例如 "find something for meeting follow-ups"），按 `keyword` 处理。对于相对时间说法（"this week", "last 7 days", "since Monday"），基于用户本地时区解析为绝对 ISO 日期，再用作 `modified_after`。如果条件含糊，选择合理默认值并继续 — 不要因为澄清而阻塞。

### 步骤 2 — 查询列表

使用 `ListListItems` 获取项目，然后在客户端筛选。拉取较大的页面（top=100）— 这个库规模不大。

```
ListListItems(
  site_id="microsoft.sharepoint-df.com,243ad53f-1b98-4147-8162-7b1557299391,8b86e36e-e48e-4fda-9fe8-c1d6eab2b3ab",
  list_id="list_7",
  top=100
)
```

如果分页返回 `next_link`，先继续拉取完整数据集，再应用筛选。

### 步骤 3 — 应用筛选

对每个项目，读取 `fields` 区块；只有在**所有**指定条件都匹配时才保留该项目：

- `Category` 等于请求的 category（不区分大小写）
- `Persona` 等于请求的 persona（不区分大小写）
- `Industry` 等于请求的 industry（不区分大小写）
- `CustomerReady` 等于请求的布尔值
- `keyword` 出现在 `Title` 或 `Description` 任一字段中（不区分大小写的子字符串匹配）
- `Modified`（ISO datetime）≥ `modified_after`

如果没有匹配项，直接说明，并建议放宽一个条件（例如去掉 industry 筛选或扩大日期范围）。

### 步骤 4 — 呈现结果

对于 2 个及以上匹配项的结果集，默认通过 `render_ui` 呈现 **Adaptive Card**。如果只有一个匹配项，则使用一行 markdown 作为兜底（一行数据没必要使用卡片）。

**卡片呈现（2 个及以上匹配项）:**

1. 先调用 `render-ui` skill，加载 schema 和验证规则，然后调用 `render_ui`。
2. 按如下方式构建卡片正文：
   - 开头的 `TextBlock`（`size: Large`, `weight: Bolder`）标题为 `"Cowork Library — N 个匹配项"`。
   - 第二个 `TextBlock`（`isSubtle: true`, `wrap: true`）总结已应用的筛选条件，例如 _"筛选条件: category = Skill · persona = Knowledge workers"_。
   - 每个结果一个 `Container`，使用 `separator: true` 分隔，每个 Container 包含：
     - 一个 `ColumnSet`，包含两列：第 1 列（`width: stretch`）放标题（`TextBlock`, `weight: Bolder`, `size: Medium`）和描述（`TextBlock`, `wrap: true`，用省略号截断到约 140 chars）；第 2 列（`width: auto`）放 `ActionSet`，其中只有一个 `Action.OpenUrl`，其 `title` 是字面字符串 `"Download"`，其 `url` 是该项目的 `DispForm.aspx?ID={id}`。
     - 在列下方放 `FactSet`，facts 包括：`Category`, `Persona`, `Industry`, `Customer Ready`（是 / 否）, `Modified`（格式化为 `YYYY-MM-DD`）。
3. 按 Category、再按 Title 对结果容器排序。
4. 在 `render_ui` 调用之后，在卡片下方补充一行简短纯文本：_"Download 按钮会打开 SharePoint 项目页面，可在该页面下载附加的技能文件。"_

**Markdown 兜底（单个匹配项或 `render_ui` 不可用）:**

呈现一行 markdown 表格，包含相同列。**Link** 列必须是 markdown 链接，字面文本为 `Download`，指向该项目的 `DispForm.aspx?ID={id}` URL。

```
| # | Title | Category | Persona | Industry | Customer Ready | Description | Link |
|---|-------|----------|---------|----------|----------------|-------------|------|
| 1 | meeting-followup | Skill | Knowledge workers | Cross Industry | Yes | Pulls action items from your last meeting and drafts a follow-up email. | [Download](https://microsoft.sharepoint-df.com/sites/ABSGSA/Lists/CopilotCoworkLibrary/DispForm.aspx?ID=1) |
```

规则（适用于两种呈现方式）：
- 始终使用字面动作文本 `Download` — 不是 "Open"，不是 "Link"，也不是项目标题。
- 描述超过约 140 chars 时，用省略号截断。
- 将 `Customer Ready` 显示为 `是` / `否`（不是 `true` / `false`）。
- 按 Category、再按 Title 排序。

### 步骤 5 — 提供下一步

表格后提供 1–2 个合理的后续操作：
- “要我再按 industry 或 customer-ready 状态进一步缩小范围吗？”
- “要我打开其中一个项目，并从附件中提取详细信息吗？”

## 输出格式

始终内联输出 markdown。除非用户明确要求创建文件，否则不要创建文件。

## 护栏

- **绝不编造项目。** 只返回来自 `ListListItems` 的行。如果调用失败或返回为空，如实说明 — 不要虚构匹配项。
- **绝不编造下载 URL。** 始终使用项目实际的 `id` 字段，并按 `DispForm.aspx?ID={id}` 模式构造 URL。
- **字段名安全。** 列表中的字段名是 `Title`, `Category`, `Persona`, `Industry`, `CustomerReady`, `Description`, `ShortDescription`, `Modified`。请使用这些精确键名。
- **分页。** 如果存在 `next_link`，先继续拉取再筛选 — 只处理部分页面会给出错误的“无匹配”答案。
- **只读。** 此技能不会创建、更新或删除项目。如果用户要求新增或修改 library 项目，请让他们使用 SharePoint UI。

## 不使用时机

- 用户询问 `/mnt/user-config/.claude/skills/` 中的**个人** skills → 改用 `skills` skill。
- 用户询问**内置**系统 skills（pdf、docx、calendar-management 等）→ 直接说明。
- 用户想向 library **新增**项目 → 此技能只读；请引导他们使用 SharePoint UI。
- 用户要求泛化搜索 OneDrive 或 SharePoint → 改用 `SearchM365` 并设置 `sources=["files"]`。