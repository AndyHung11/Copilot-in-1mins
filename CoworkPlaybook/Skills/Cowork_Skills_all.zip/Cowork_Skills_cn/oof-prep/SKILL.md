---
name: oof-prep
description: |
  为用户准备休假：起草 OOF 自动回复、创建交接文档，并标记 PTO 期间需要谢绝或委派的会议。
  当用户提出“帮我准备 PTO”、“我要休假”、“设置我的 OOF”、“我下周不在”、“休假前交接”、“休假交接”、"prep me for PTO", "going on vacation", "set up my OOF",
  "I'm out next week", "out of office prep", 或 "handoff before I leave" 时使用。
  不要用于一天病假替岗 — 直接用 SetAutoReply 设置 OOF 即可。
  不要用于永久岗位交接 — 请改用 stakeholder-comms。
cowork:
  category: productivity
  icon: Calendar
---

## 概览

三部分 PTO 准备：(1) 为内部和外部对象起草 OOF 自动回复，
(2) 生成交接文档，汇总进行中的工作和关键联系人，
(3) 扫描 PTO 时间段内的会议，并标记哪些应谢绝、委派或保留。

## 使用场景

- 用户表示即将 PTO / 休假 / 请假
- 离岗 2+ 个工作日
- 需要为替岗人员准备交接

## 不适用场景

- 单日病假 → 直接调用 `SetAutoReply`
- 永久离职 / 岗位变更 → 使用 `stakeholder-comms`
- OOF 已启用 → 使用 `GetAutoReplySettings` / `DisableAutoReply`

## 快速开始

```
用户：“帮我准备 5 月 30 日到 6 月 6 日的 PTO”
1. 询问替岗联系人和任何关键背景（一次性汇总提问）
2. 起草 OOF（内部 + 外部）— 展示给用户审核
3. 针对 PTO 时间段调用 ListCalendarView → 标记会议（谢绝 / 委派 / 保留）
4. 生成交接文档：进行中的项目、关键联系人、资料位置
5. 提议：启用 OOF、发送谢绝说明、将交接内容发布到团队频道
```

## 核心说明

### 步骤 1：澄清最少必要背景

提出 ONE 个汇总式 `AskUserQuestion`，覆盖：
- 替岗联系人（紧急事项应转给谁）
- 用户希望完全不回复，还是愿意查看邮件
- 是自动谢绝会议，还是只先标记

不要多轮来回提问 — 在一张卡片中一次收集完整信息。

### 步骤 2：起草 OOF 信息

使用 `SetAutoReply`，设置 `status="scheduled"`、PTO 开始/结束时间，以及：
- **内部信息：** 语气温和，提到替岗联系人姓名和返回日期
- **外部信息：** 简短、专业，包含返回日期和 "for urgent matters contact <X>"

调用 `SetAutoReply` 前，先向用户展示草稿。未经确认，绝不启用 OOF。

### 步骤 3：扫描日历

`ListCalendarView(start=<PTO start>, end=<PTO end>)` — 对每个事件分类：
- **谢绝** — 例行周期同步、可选会议、用户可以缺席的任何会议
- **委派** — 替岗联系人可以参加的会议
- **保留在日历上（但发出提示）** — 用户组织的会议；转发给代理人
- **重要 — 需要行动** — 用户必须在 PTO 前/后处理的会议

以 `render-ui` 表格呈现。不要自动谢绝 — 先向用户展示建议并获得审批。

### 步骤 4：交接文档

创建包含以下部分的 markdown 文档：

```markdown
# 交接 — <name> OOF <start> 至 <end>

## 替岗联系人
<Name, email, focus areas>

## 进行中的项目
- <Project> — 当前状态、下一个检查点、关键联系人

## 需要关注的关键邮件线程
- <Email subject> — 如果 X 发生时该怎么做

## 可以忽略的事项
- <Bucket> — 我不在期间不会产生影响

## 资料位置
- <Files, channels, dashboards>
```

数据来源：近期已发送邮件、过去一周已接受的会议、活跃 Teams 聊天。
默认以内嵌 markdown 保存；可提议另存为文件或发布到团队频道。

### 步骤 5：确认后执行

只有在用户审核全部三项产出后：
- 调用 `SetAutoReply` 排程 OOF
- 对于谢绝项：对每个已审批的会议使用 `DeclineEvent`，并附上简短评论
- 对于委派转发：使用 `ForwardEvent`

## 护栏

- 未展示草稿并获得确认前，绝不启用 OOF
- 绝不自动谢绝会议 — 始终先展示列表供用户审批
- 外部 OOF 不得提及替岗联系人，除非用户确认（隐私）
- 如果用户在 PTO 期间组织周期性会议系列，建议转交组织权，默认不要取消
