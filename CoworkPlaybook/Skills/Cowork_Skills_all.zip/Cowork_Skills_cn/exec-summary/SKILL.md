---
name: exec-summary
description: |
  将较长的文档、邮件线程或转录浓缩成一页高管摘要。
  当用户说“帮我做 TL;DR”、“给我高管摘要”、“给领导总结这份内容”、“一页摘要”、“帮我精简一下”、“给忙碌读者的简短版”、"TL;DR this", "give me the exec summary", "summarize this for
  leadership", "one-page summary", "condense this", or "make this shorter for a busy
  reader" 时使用。
  不要用于总结会议转录 — 请使用 meeting-intel。
  不要用于整个收件箱摘要 — 请使用 inbox-triage 或 daily-briefing。
cowork:
  category: writing
  icon: DocumentText
---

## 概览

接收一段较长内容（文档、线程、转录、报告），面向忙碌的资深读者产出一页高管摘要：讲的是什么、为什么重要、需要哪些决策、建议的下一步。

## 适用场景

- 用户分享长文件或粘贴长线程，希望快速抓住要点
- 任何材料的 "TL;DR"
- 基于较长来源，为领导阅读准备简报摘要

## 不适用场景

- 专门总结会议转录 → 使用 `meeting-intel`
- 跨邮件/Teams 的多来源综合 → 使用 `daily-briefing` 或 `weekly-wrap`
- 从零起草*新的*高管更新（没有来源）→ 使用 `stakeholder-comms`

## 快速开始

```
用户: “帮我做 TL;DR”（附有文件或引用了文档）
1. 确定来源 — 上传的文件、Web URL 或粘贴的文本
2. 读取来源（文件用 Read tool，SharePoint 用 ReadFileContent，URL 用 web_fetch）
3. 提取：核心主张、关键证据、决策/请求、风险
4. 将一页摘要以内联 markdown 呈现
```

## 核心说明

### 步骤 1：定位来源
优先级：
1. **消息中的附件文件** — 直接对路径使用 `Read`
2. **消息中粘贴的文本** — 直接使用
3. **引用的 M365 文件** — 使用 `SearchM365` 或 `ReadFileContent`
4. **URL** — 使用 `web_fetch`
5. 如果以上都没有，请让用户分享内容

### 步骤 2：完整读取
- 对于超过 10 页的 PDF，使用带 `pages` 参数的 `Read`，并遍历整个文档
- 对于 SharePoint 文档：如果可用，使用带 `download_url` 的 `ReadFileContent`
- 对于较长的 Teams 线程：使用 `ListChatMessages` 并拼接内容
- 读取整个来源 — 不要只根据第一页总结

### 步骤 3：提取结构

整理到工作笔记：
- **核心主张** — 最重要的单一观点（一句话）
- **为什么重要** — 业务影响和利害关系
- **关键证据** — 3–5 个支撑事实/数字/引用
- **决策或请求** — 希望读者做什么
- **风险 / 未决问题** — 可能出问题的地方
- **下一步** — 建议行动

### 步骤 4：输出

以内联 markdown 呈现 — 高管摘要用于阅读，不用于下载，除非用户明确要求 Word 文档。使用以下结构：

```markdown
# <Document title> — 高管摘要

**一句话结论：** <one-sentence core claim>

## 为什么重要
<2–3 sentence stakes/context>

## 关键点
- <point 1 with number/fact>
- <point 2>
- <point 3>

## 决策 / 请求
- <what is being requested>

## 风险
- <key risk>

## 建议下一步
<one sentence>
```

目标：250 字以内。如果来源中有关键数字，尽可能标注来源行号或页码。

### 步骤 5：提供文件转换

显示内联摘要后，询问："Want this as a Word doc or PDF?" 只有在用户确认后，才调用 `docx` 或 `pdf` skills。

## 护栏

- 绝不编造数字、姓名或引用 — 每个事实都必须能追溯到来源
- 如果来源存在缺口或矛盾，在风险部分说明，不要掩盖
- 控制在一页内（≤250 words）— 这就是价值所在。如果内容无法压缩到这个程度，请说明并询问优先保留什么
- 对于敏感文档（财务、人事），除非用户明确受众是内部人员，否则姓名一律泛化
