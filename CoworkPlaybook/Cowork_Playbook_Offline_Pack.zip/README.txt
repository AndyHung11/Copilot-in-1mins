Cowork 練習手冊 — 離線包
========================

1. 開啟 Cowork練習手冊_v2_單檔.html，內容（含截圖）已全部內嵌，離線可直接瀏覽。
2. 範例檔依產業分別放在 samples_<產業>/ 底下：
     samples_generic/  通用      samples_fin/   金融
     samples_mfg/      製造業    samples_mfgx/  製造業（進階）
     samples_gov/      公部門    samples_ret/   零售通路
     samples_tel/      電信業    samples_air/   航空業
3. 素材有兩種用法，看該情境的〈練習前準備〉：
   - 下載後上傳到對話（多數情境）
   - 先放進 OneDrive 與信箱，讓 Cowork 自己去找（進階情境）
4. 進階產業的目錄含 OneDrive_種入用/、信箱_種入用/、技能/ 三個子資料夾，
   請先讀該產業的〈課前環境準備指南.md〉。
