Cowork 练习手册 — 离线包
========================

1. 打开 playbook-manufacturing-adv.html，内容（含截图）已全部内嵌，离线可以直接看。
2. 示例文件放在 samples_mfgx/ 下。
3. 这个行业的素材要「课前先放进 OneDrive 和邮箱」，练习时 Cowork 会自己去找。开始前请先读目录里的〈课前环境准备指南〉。
