Cowork Playbook - offline pack
==============================

1. Open playbook-generic.html - screenshots are embedded, so it works offline.
2. Sample files are in samples_generic/.
3. Upload them into the conversation when a step asks for them.
