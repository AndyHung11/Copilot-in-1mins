# Inbox Triage & Daily Brief Rules

> Hand these rules to Cowork so it organizes your inbox, plans your week, and produces a morning brief with the same standard every day.

## 1. Four-Quadrant Triage
Sort every inbox message into one of these categories:

| Category | Criteria | Suggested action |
|----------|----------|------------------|
| 🔴 Needs my reply | Names me directly, asks a question, or needs my decision | Reply today; add to to-do |
| 🟡 Track | I delegated it; waiting on someone's reply or progress | Set reminder; add to tracking list |
| 🟢 Delegate | Someone else can handle it | Reassign and cc me |
| ⚪ FYI only | Announcements, newsletters, auto-notifications | Archive; no action |

## 2. Urgency Flags
- From "Needs my reply," pick up to 3 that are "must-do today" and mark them ⭐ top priority.
- Basis: sent by a client or executive, has a clear deadline (today/tomorrow), or blocks others.

## 3. Weekly Planning Principles
- Against calendar gaps, schedule to-dos across the week; focus on one "most important task" per day.
- Avoid deep work on meeting-heavy days; batch quick replies into fixed time slots.

## 4. Daily Brief Format (a 5-minute morning read)
1. **Today's focus**: one sentence on the single most important thing today
2. **Today's meetings**: time + topic + what I need to prepare
3. **Must reply**: the ⭐ list (who, plus a one-line point)
4. **Waiting on**: who I'm waiting to hear back from
5. **Reminders**: anything due today or needing a decision

## 5. Schedule Settings
Once this flow is on a schedule, Cowork runs it by itself using these settings:

| Item | Setting |
|------|---------|
| Run time | **08:30** every morning (change it to when you actually start work) |
| Scope | New mail since 17:00 on the previous working day |
| Weekends | Skip; on Monday morning include everything from the weekend |
| Delivery | Email the brief **to myself** |
| If there is no new mail | Still send the brief, noting "nothing new to action today" |

> ⚠️ **Pause it when you are done practising**: this is a real schedule and it will genuinely
> run tomorrow morning. Set it to paused on the Automations page — no need to delete it.
