---
name: leadership-update
description: |
  Writes a concise monthly leadership update that translates working-team
  detail into a leadership-grade message — outcomes first, mechanism second,
  constrained to ~250 words.

  Use when the user says "write my monthly update", "leadership update for
  [period]", "draft my monthly status for leadership", or asks to summarize
  a period of work for their manager or skip-level.

  Do NOT use for: spoken speaker notes (use talking-points), board one-pagers
  (use board-prep), formal risk escalations (use risk-callout), or peer/team
  status that does not roll up the chain.
license: MIT
metadata:
  author: Microsoft
  version: "1.0"
---

# Leadership Update

Turn a month of working-team detail into a tight, leadership-grade update.
Lead with outcomes; explain mechanism only enough to make the outcome credible.

## When NOT to Use

- Speaker scripts for a deck → `talking-points`
- Board one-pagers → `board-prep`
- Formal risk escalation memos → `risk-callout`
- Lateral/team status that is not written up-the-chain

## Core Principles

- **Outcomes first, mechanism second.** Open each item with the result and its
  business impact, then one clause on how. Cut process narration.
- **Leadership tone.** Plain, confident, specific. No hedging, no jargon, no
  play-by-play. Quantify impact wherever a number exists.
- **~250 words.** Hard ceiling. If it runs long, cut mechanism detail before
  cutting outcomes.

## Workflow

1. **Resolve the period.** Convert "this month" / "[period]" to explicit dates.
2. **Collect source material.** Pull the user's recent shipped work, open
   initiatives, and risks from the conversation and any M365 sources the user
   points at (recent emails, meeting notes, project docs). Do not fabricate —
   if a category is empty, ask the user or leave a clear placeholder.
3. **Classify each item** into Headlines (shipped/landed), In Flight (open
   initiatives), Risks (what could slip), and Ask (decisions/help needed).
4. **Rewrite to leadership tone.** Each line: outcome + impact, then a short
   mechanism clause. Strip status-meeting language.
5. **Trim to ~250 words.**

## Output Format

A formatted update with exactly these headers:

```
## Headlines
- <outcome + impact>, <one mechanism clause>

## In Flight
- <initiative> — <current state, expected outcome, ETA>

## Risks
- <risk> — <likely impact, what you're doing about it>

## Ask
- <specific decision or help needed, from whom>
```

Keep Headlines to the 3–5 items that matter most. If there is no Ask, say
"No asks this period" rather than padding.

## Confirmation Gate

If the user has not specified the period, ask once. Otherwise draft directly
and let the user edit.
