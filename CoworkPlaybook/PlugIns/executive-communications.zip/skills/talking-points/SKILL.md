---
name: talking-points
description: |
  Writes a spoken-style speaker script for a deck or outline — one segment per
  slide, targeted at 30-45 seconds each, with transitions flagged between
  slides.

  Use when the user says "talking points for these slides", "speaker notes for
  this deck", "write a script for my presentation", or provides a deck/outline
  and wants something they can read aloud.

  Do NOT use for: written leadership updates (use leadership-update), board
  one-pagers (use board-prep), or risk memos (use risk-callout). Not for
  building the slides themselves.
license: MIT
metadata:
  author: Microsoft
  version: "1.0"
---

# Talking Points

Turn a deck or outline into a spoken-style script the presenter can read aloud,
one segment per slide, paced for 30–45 seconds each.

## When NOT to Use

- Written leadership updates → `leadership-update`
- Board one-pagers → `board-prep`
- Risk escalation memos → `risk-callout`
- Authoring the slides themselves (this skill scripts existing slides)

## Core Principles

- **Spoken, not written.** Short sentences, natural cadence, contractions.
  Write the way a confident presenter actually speaks.
- **30–45 seconds per slide.** Roughly 75–110 spoken words. Trim anything that
  reads like a paragraph.
- **One idea per slide.** Land the slide's single point; do not narrate every
  bullet.
- **Flag transitions.** Bridge each slide to the next so the talk flows.

## Workflow

1. **Ingest the deck or outline.** Accept a pasted outline, an attached file,
   or a list of slide titles. Read the actual content — do not guess what a
   slide says.
2. **For each slide**, identify its single key message.
3. **Write the spoken segment** for that slide (~30–45s), leading with the
   message and supporting it conversationally.
4. **Add a transition line** that hands off to the next slide.
5. **Keep the speaker's voice** consistent and on-tone throughout.

## Output Format

A per-slide script the speaker can read aloud:

```
### Slide 1 — <title>
<spoken script, ~30-45 seconds>
> Transition: <one line bridging to slide 2>

### Slide 2 — <title>
<spoken script>
> Transition: <bridge to slide 3>
```

The final slide gets a close instead of a transition. If a slide's content is
missing or ambiguous, note it inline rather than inventing material.

## Confirmation Gate

If no deck or outline is provided, ask for it once before scripting.
