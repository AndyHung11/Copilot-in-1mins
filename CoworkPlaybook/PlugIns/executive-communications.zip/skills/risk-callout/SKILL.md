---
name: risk-callout
description: |
  Structures a risk description into a formal risk-callout memo suitable for
  forwarding to leadership — Situation, Impact, Probability, Mitigation
  Options, Recommended Action. Tone is calm and factual, never alarmist.

  Use when the user says "call out this risk", "escalate this risk formally",
  "write a risk memo", or wants to surface a risk up-the-chain in a structured,
  forwardable form.

  Do NOT use for: monthly leadership updates (use leadership-update), board
  one-pagers (use board-prep), or speaker notes (use talking-points). Not for
  casual mentions of risk inside a broader status message.
license: MIT
metadata:
  author: Microsoft
  version: "1.0"
---

# Risk Callout

Turn a risk description into a formal, forwardable memo that leadership can act
on. Calm and factual — the goal is a clear-eyed decision, not alarm.

## When NOT to Use

- Monthly leadership updates → `leadership-update`
- Board one-pagers → `board-prep`
- Speaker scripts → `talking-points`
- A passing risk mention inside a broader update

## Core Principles

- **Calm and factual.** State the risk plainly. No catastrophizing, no
  minimizing. Let the facts carry the weight.
- **Decision-oriented.** Every memo ends with a clear recommended action and
  what you need from the reader.
- **Honest probability and impact.** Be specific about likelihood and
  consequence; flag uncertainty rather than overstating confidence.
- **Forwardable.** Self-contained — a leader should be able to forward it
  without adding context.

## Workflow

1. **Capture the risk** from the user's description and any source material.
2. **Assess impact** — what is affected, how badly, who feels it.
3. **Assess probability** — likelihood in plain terms (e.g. low / moderate /
   high) with the reasoning behind the rating.
4. **Lay out mitigation options**, each with cost and residual risk.
5. **Recommend an action** and state what decision or support is needed.
6. **Set the tone** — review the draft and strip any alarmist or hedging
   language before delivering.

## Output Format

A formal risk-callout memo with these sections:

```
## Situation
<what the risk is, in plain terms>

## Impact
<what is affected and how severely>

## Probability
<likelihood + brief reasoning>

## Mitigation Options
1. <option> — cost / residual risk
2. <option> — cost / residual risk

## Recommended Action
<the recommended path and the decision or support needed, from whom and by when>
```

## Confirmation Gate

If the risk description is too thin to assess impact or probability, ask one
clarifying question. Otherwise draft directly.
