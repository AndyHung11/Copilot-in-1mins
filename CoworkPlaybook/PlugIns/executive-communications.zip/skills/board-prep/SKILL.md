---
name: board-prep
description: |
  Produces a tight board-style one-pager from a topic and source materials —
  opens with the recommendation, then evidence, then options, in board memo
  format.

  Use when the user says "prep for the board", "board one-pager", "board memo
  on [topic]", or asks to turn a topic and supporting materials into a single
  page for a board or executive committee.

  Do NOT use for: monthly leadership updates (use leadership-update), spoken
  speaker notes (use talking-points), or risk escalation memos (use
  risk-callout). Not for full decks or multi-page strategy docs.
license: MIT
metadata:
  author: Microsoft
  version: "1.0"
---

# Board Prep

Turn a topic plus source materials into a single, decision-ready board memo.
The reader is a board member with two minutes — the recommendation comes first.

## When NOT to Use

- Monthly leadership updates → `leadership-update`
- Spoken speaker scripts → `talking-points`
- Risk escalation memos → `risk-callout`
- Anything longer than one page (decks, strategy docs)

## Core Principles

- **Recommendation first.** State what you are asking the board to endorse in
  the first two sentences. Everything after exists to support it.
- **Evidence over narrative.** Use the strongest 3–5 facts, figures, or
  precedents. Cite their source; never invent numbers.
- **Honest options.** Present real alternatives with trade-offs, not strawmen.
- **One page.** Tight prose, scannable structure.

## Workflow

1. **Capture the topic and the decision being sought.** If the ask is unclear,
   confirm it once — a board memo without a clear ask is not a board memo.
2. **Ingest source materials** the user provides (docs, data, prior decisions).
   Extract the load-bearing evidence; discard background that does not move the
   decision.
3. **Frame 2–3 options**, each with upside, cost/risk, and a one-line verdict.
4. **Write the memo** in the format below, recommendation-first.
5. **Pressure-test** every claim against the source material before delivering.

## Output Format

A one-pager in board memo style with these sections:

```
## TL;DR
<2-3 sentences: the recommendation and the decision sought>

## Context
<the minimum background needed to understand the decision>

## Options
1. <Option> — upside / cost / verdict
2. <Option> — upside / cost / verdict
3. <Option> — upside / cost / verdict

## Recommendation
<which option and why, tied to the evidence>

## Risks
<key risks of the recommended path and how they are managed>
```

## Confirmation Gate

Confirm the decision being sought if it is ambiguous. Otherwise draft directly.
