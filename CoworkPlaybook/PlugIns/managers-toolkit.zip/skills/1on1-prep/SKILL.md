---
name: 1on1-prep
description: |
  Prepares a focused agenda for a manager's recurring 1:1 with a named person. Pulls
  recent emails, chats, and shared docs exchanged with that person, identifies recurring
  topics, open asks, and decisions still pending, and proposes 3–5 talking points plus a
  tailored "how are you" opener grounded in recent context. Uses only the host's email,
  calendar, and chat surfaces; no external connectors. Use when the user says "prep me
  for my 1:1 with [name]", "1:1 agenda for [name]", "what should I cover with [name]", or
  "get me ready for my one-on-one with [name]". Do NOT use for a whole-team digest (use
  team-pulse), for an upward roll-up to the user's own manager (use skip-level-prep), for
  drafting written feedback (use feedback-drafter), or for evaluating the person's
  performance.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# 1:1 Prep

Builds a short, context-aware agenda for a manager's one-on-one with a specific person.

## When NOT to Use

- Whole team → use `team-pulse`.
- Upward update to the user's own manager → use `skip-level-prep`.
- Writing feedback or perf comments → use `feedback-drafter`.
- Rating or evaluating the person → decline; this skill prepares a conversation, not an
  assessment.

## Core Concepts

- **Person resolution first.** Resolve `[name]` to a single directory match before
  pulling anything. If multiple people match, ask which one.
- **Recurring topics** are themes that appear across more than one recent message or doc.
- **Open asks / pending decisions** are items raised but not visibly closed.

## Workflow

1. **Resolve the person.** Map `[name]` to one directory contact. Ambiguous → ask.
2. **Set the window.** Default to the last 2–3 weeks (since the previous 1:1 if
   detectable from the calendar).
3. **Gather in parallel** from the host surfaces, scoped to the manager + that person:
   - recent emails both ways,
   - recent chat messages,
   - docs shared between them.
4. **Synthesize.** Cluster into recurring topics, list open asks and pending decisions,
   and note anything time-sensitive.
5. **Draft the agenda.** Produce 3–5 talking points, an open-items list, and one tailored
   "how are you" opener that references something specific and recent (a shipped item, a
   tough week, a milestone).

## Output Format

```
# 1:1 with <Name> — <date>

## Opener
<One tailored "how are you" prompt grounded in recent context.>

## Talking points
1. <point>
2. <point>
3. <point>

## Open items
- <ask or pending decision> — <status / who owes what>
```

Keep talking points crisp. Each should tie to an observed email, chat, or doc.

## Confirmation Gates

- Read-only by default. If the user asks to send the agenda to the person, confirm first.

## Errors

- Name not resolvable or multiple matches → ask which person.
- No recent interactions found → say so; offer a generic check-in agenda instead.
