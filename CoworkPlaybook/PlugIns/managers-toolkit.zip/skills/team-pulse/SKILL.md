---
name: team-pulse
description: |
  Builds a weekly pulse digest of a people manager's direct reports. Resolves the
  manager's direct reports, then for each person summarizes visible activity from the
  past week — shipped work, meetings led, and blockers mentioned in chats — and flags
  anyone with low signal or rising stress (frequent late-night messages, declined focus
  time). Uses only the host's email, calendar, and chat surfaces; no external connectors.
  Use when the user says "team pulse", "what is my team up to", "weekly digest of my
  reports", "how is my team doing this week", or "give me a read on my reports". Do NOT
  use for a single person (use 1on1-prep), for an upward roll-up to the user's own
  manager (use skip-level-prep), for writing performance feedback (use feedback-drafter),
  or for ranking, rating, or evaluating individual employee performance.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Team Pulse

Weekly activity digest across a people manager's direct reports, built from the host's
email, calendar, and chat surfaces only.

## When NOT to Use

- One person only → use `1on1-prep`.
- Upward summary for the user's own manager → use `skip-level-prep`.
- Writing feedback or perf comments → use `feedback-drafter`.
- Comparing, ranking, or evaluating employee performance → decline; this skill reports
  activity signals for the manager's own awareness, not assessment.

## Core Concepts

- **Direct reports** are resolved from the org directory, never guessed.
- **Signal** = observable work artifacts (sent updates, docs shared, meetings led,
  decisions, blockers raised). Absence of signal is reported as "low visibility," not as
  a judgment about the person.
- **Stress indicators** are pattern-based and tentative: clusters of late-night messages,
  repeatedly declined focus time, or blocker language. Always phrased as "worth a check-in."

## Workflow

1. **Resolve the team.** Get the signed-in user's direct reports from the directory.
   If none are found, tell the user and stop.
2. **Set the window.** Default to the last 7 days in the user's local time zone.
3. **Gather per person, in parallel.** For each report, collect from the host surfaces:
   - email they sent/received with the manager or the team,
   - calendar events they organized or led in the window,
   - chat messages mentioning blockers, risks, or asks,
   - timestamps of activity to detect late-night patterns and declined focus blocks.
4. **Summarize each report** into one short paragraph: what they shipped or drove, who
   they worked with, and any open blocker. Keep it factual and traceable.
5. **Build the watch list.** Flag reports with low visibility this week or stress
   indicators. Each flag names the signal observed (e.g., "5 messages after 22:00") and
   suggests a light-touch action.

## Output Format

```
# Team Pulse — week of <date range>

## <Report name>
<One short paragraph: shipped work, meetings led, collaborators, open blockers.>

## <Report name>
...

## Watch list
- <Name> — <signal observed> → <suggested check-in>
```

Keep each paragraph to 2–4 sentences. If a report has no visible activity, say so plainly
rather than inferring inactivity.

## Confirmation Gates

- None for read-only digest generation. If the user asks to send the digest to anyone,
  confirm recipients before sending.

## Errors

- No direct reports found → report it; offer to run for a named list instead.
- A surface returns nothing for a person → mark "low visibility," do not fabricate.
