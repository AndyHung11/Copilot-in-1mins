---
name: skip-level-prep
description: |
  Produces a concise upward one-pager for a manager preparing a skip-level update or a
  briefing for their own manager. Aggregates team-pulse-style activity across the whole
  team, then distills it into 3 highlights, 2 risks, and 1 ask, formatted for a leadership
  audience in tight, outcome-focused language. Uses only the host's email, calendar, and
  chat surfaces; no external connectors. Use when the user says "skip-level update", "prep
  for my manager", "roll up the team", "leadership update for my org", or "summarize my
  team for my boss". Do NOT use for a detailed per-person digest the manager keeps for
  themselves (use team-pulse), for a single 1:1 (use 1on1-prep), for writing individual
  feedback (use feedback-drafter), or for ranking or evaluating individuals.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Skip-Level Prep

Rolls the team's week up into a leadership-ready one-pager: 3 highlights, 2 risks, 1 ask.

## When NOT to Use

- Detailed per-report digest for the manager's own use → use `team-pulse`.
- Single-person 1:1 → use `1on1-prep`.
- Individual feedback → use `feedback-drafter`.
- Performance ranking of individuals → decline; summarize team outcomes, not people.

## Core Concepts

- **Upward framing.** The audience is the user's manager or skip. Lead with outcomes and
  business impact, not activity logs or individual names unless naming adds clarity.
- **Highlights** = shipped outcomes or wins worth surfacing upward.
- **Risks** = things that could slip, with a one-line mitigation or status.
- **Ask** = the single most valuable thing leadership can unblock or decide.

## Workflow

1. **Resolve the team.** Get the signed-in user's direct reports from the directory.
2. **Aggregate.** Gather the same week's signal as `team-pulse` across all reports —
   shipped work, meetings led, blockers — from the host surfaces, in parallel.
3. **Distill upward.** Select the 3 strongest highlights, the 2 most material risks, and
   the single highest-leverage ask. Collapse detail; favor impact over completeness.
4. **Translate to leadership language.** Short sentences, concrete outcomes, no internal
   jargon. Quantify where the data supports it.

## Output Format

```
# Team Roll-Up — week of <date range>

## Highlights
1. <outcome + impact>
2. <outcome + impact>
3. <outcome + impact>

## Risks
1. <risk> — <status / mitigation>
2. <risk> — <status / mitigation>

## Ask
- <the one thing leadership can unblock or decide>
```

Keep the whole thing to one screen. Every line should be defensible from observed signal.

## Confirmation Gates

- Read-only by default. If the user asks to send or post the roll-up upward, confirm the
  recipient and channel first.

## Errors

- No direct reports → report it; offer to build from a named list.
- Thin signal for the week → say so and present what is available rather than padding.
