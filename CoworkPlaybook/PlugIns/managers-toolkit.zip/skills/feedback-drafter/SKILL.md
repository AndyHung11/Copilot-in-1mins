---
name: feedback-drafter
description: |
  Turns a manager's rough notes about a person into a polished, structured feedback draft
  the manager can paste into any HR or performance tool. Organizes input into Strengths,
  Growth Areas, and Examples, tightens the language, and removes vague or non-specific
  phrasing so each point is concrete and actionable. Works from the notes the user
  provides; uses host surfaces only if the user asks it to pull supporting examples. Use
  when the user says "draft feedback for [name]", "help me write a perf comment", "polish
  my feedback notes", or "structure this feedback". Do NOT use to generate a numeric
  rating, ranking, or comparison of employees; to invent accomplishments the user did not
  mention; for a team digest (use team-pulse); for 1:1 prep (use 1on1-prep); or for an
  upward roll-up (use skip-level-prep).
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Feedback Drafter

Structures and tightens a manager's rough feedback notes into a clean, paste-ready draft.

## When NOT to Use

- Producing a rating, score, or ranking → decline; this drafts narrative feedback only.
- Team digest → use `team-pulse`. 1:1 prep → use `1on1-prep`. Upward roll-up → use
  `skip-level-prep`.

## Core Concepts

- **Notes in, structure out.** The manager's observations are the source of truth. Do not
  invent strengths, growth areas, or examples the user did not provide.
- **Three sections:** Strengths, Growth Areas, Examples — each grounded in a specific,
  observable behavior or outcome.
- **De-vague pass.** Replace soft phrasing ("good communicator," "needs to step up") with
  concrete behavior + impact ("ran the launch sync and kept three teams aligned").

## Workflow

1. **Collect notes.** If the user pasted notes, use them. If notes are thin, ask for a
   few specifics (one strength, one growth area, one example) before drafting.
2. **Optional sourcing.** Only if the user asks, pull supporting examples from host
   surfaces; otherwise stay within the provided notes.
3. **Bucket** each note into Strengths, Growth Areas, or Examples.
4. **Tighten.** Rewrite each point as behavior + impact. Cut hedging and clichés. Keep a
   constructive, specific, professional tone.
5. **Assemble** the draft and flag any place the user should add a concrete example
   (`[add example]`) rather than fabricating one.

## Output Format

```
# Feedback — <Name>

## Strengths
- <behavior + impact>

## Growth Areas
- <behavior + concrete next step>

## Examples
- <specific situation → action → result>
```

Mark gaps with `[add example]`. Never fabricate accomplishments, dates, or quotes.

## Confirmation Gates

- This skill drafts text only; it does not submit to any HR system. The manager pastes
  the result wherever they choose.

## Errors

- Notes too sparse to structure → ask for one strength, one growth area, one example.
- User requests a rating or comparison → decline and offer narrative feedback instead.
