---
name: stakeholder-update
description: |
  Turns the latest project state into two stakeholder-ready drafts in a
  single response: a concise executive version (~150 words, outcomes only)
  and a detailed working-team version (full status plus open issues). Pulls
  the current state from the host's existing email, calendar, file, and chat
  surfaces; never fabricates outcomes, metrics, or dates.

  Use when the user says "update the stakeholders", "write the project
  update", "draft the exec summary and team update", or "send a project
  status to leadership and the team".

  Do NOT use for: a RAG roll-up table (use status-roundup), editing the
  risk log (use risk-register-update), or milestone-vs-baseline tracking
  (use milestone-tracker). No external connector — host surfaces only.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Stakeholder Update

Produces two audience-tuned drafts of the same project update in one
response — an executive version and a working-team version.

## When NOT to Use

- RAG status table → `status-roundup`
- Risk log entry → `risk-register-update`
- Milestone slippage report → `milestone-tracker`

## Core Concepts

**Two audiences, two registers:**

| | Exec version | Working-team version |
|---|---|---|
| Length | ~150 words | As long as needed |
| Focus | Outcomes, decisions, asks | Full status + open issues |
| Detail | No task-level minutiae | Task-level detail, owners, dates |
| Tone | Confident, outcome-led | Candid, operational |

**Single source of truth** — both drafts describe the same project state.
Do not let the exec version claim an outcome the detailed version
contradicts. Every figure or date must trace to a sourced update.

## Workflow

1. **Assemble current state** from the host surfaces: latest status
   roundup, recent owner emails, the project channel, key files. Reuse a
   `status-roundup` result if one already exists in the conversation.
2. **Identify outcomes** (what shipped / what was decided) for the exec
   draft, and **open issues** (blockers, risks, decisions pending) for the
   team draft.
3. **Write the exec draft** — ~150 words, outcomes and asks only, no
   process detail.
4. **Write the team draft** — full status per workstream plus an Open
   Issues section.
5. **Mark any gap** where state is unknown as `[needs confirmation]`
   rather than inventing it.

## Output Format

Both drafts in one response, clearly separated:

```
=== EXECUTIVE UPDATE (~150 words) ===
<outcome-led summary, decisions, asks>

=== WORKING-TEAM UPDATE ===
<full status per workstream>

Open Issues:
- <issue> — <owner> — <next step>
```

## Confirmation Gates

- These are drafts, not sends. Present both for review; only send/post if
  the user explicitly asks.
- Keep the exec version to roughly 150 words unless the user sets another
  length.

## Errors

- Project state thin or missing → produce the drafts with
  `[needs confirmation]` placeholders and list what's missing, rather than
  blocking.
