---
name: risk-register-update
description: |
  Adds a new risk or applies a status change to an existing risk, returning
  a clean register entry ready to paste into the project's risk log. Ensures
  every entry carries the five required fields — Likelihood, Impact, Owner,
  Mitigation, and Next Review — and explicitly flags any field the user did
  not supply instead of inventing a value.

  Use when the user says "update the risk register", "add a risk to the
  log", "log a new risk", "change the status of a risk", or "what's missing
  on this risk".

  Do NOT use for: rolling up workstream status (use status-roundup),
  tracking milestone slippage (use milestone-tracker), or writing a
  stakeholder narrative (use stakeholder-update). Works off the host's
  existing file and chat surfaces only — no external risk-tool connector.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Risk Register Update

Produces a complete, paste-ready risk register entry — either a brand-new
risk or a status change to an existing one — with all required fields
validated.

## When NOT to Use

- Workstream RAG roll-up → `status-roundup`
- Milestone dates vs. baseline → `milestone-tracker`
- Exec / team narrative → `stakeholder-update`

## Core Concepts

**Required fields** — every register entry MUST have all five:

| Field | Meaning |
|---|---|
| Likelihood | Probability the risk materialises (e.g. High/Med/Low or 1–5) |
| Impact | Severity if it occurs (e.g. High/Med/Low or 1–5) |
| Owner | Single accountable person |
| Mitigation | The action reducing likelihood or impact |
| Next Review | Date the risk is next re-assessed |

**Flag, don't fabricate** — if the user omits a field, output the entry
with the field marked `[MISSING — please provide]`. Never guess a
likelihood, owner, or review date.

## Workflow

1. **Determine the operation**: new risk vs. status change to an existing
   one. For a status change, locate the existing entry (in the file or
   message the user references) before editing.
2. **Collect the five fields** from the user's request and any referenced
   source.
3. **Validate completeness.** For each missing field, insert the
   `[MISSING — please provide]` placeholder and collect them into a
   "Fields needing input" list.
4. **Assign a risk ID** if the log uses them (continue the existing
   sequence; otherwise suggest one and note it's provisional).
5. **Render the entry** in paste-ready form.

## Output Format

A single register entry block:

```
Risk ID:      <id or [provisional]>
Title:        <short risk statement>
Likelihood:   <value or [MISSING — please provide]>
Impact:       <value or [MISSING — please provide]>
Owner:        <name or [MISSING — please provide]>
Mitigation:   <action or [MISSING — please provide]>
Next Review:  <date or [MISSING — please provide]>
Status:       <Open / Mitigating / Closed>
```

Followed by **Fields needing input:** a bullet list of every flagged gap
(or "None — entry is complete").

## Confirmation Gates

- For a status change, confirm you found the correct existing risk before
  rewriting it.
- Do not silently overwrite an owner or date the user did not mention.

## Errors

- Existing risk not found → say so, offer to create it as new instead.
- Ambiguous likelihood/impact scale → mirror the scale already used in the
  log; if none is visible, default to High/Med/Low and note the choice.
