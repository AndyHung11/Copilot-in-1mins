---
name: milestone-tracker
description: |
  Compares current milestone dates against the baseline plan and reports
  each milestone as On Track, At Risk, Slipped, or Done — with the delta
  from baseline and a one-line cause for anything that is off track. Reads
  the plan and current dates from the host's existing file, email, and chat
  surfaces; never assumes a date that isn't sourced.

  Use when the user says "milestone check", "what is slipping", "are we on
  track", "milestone status", or "how do we stand against the plan".

  Do NOT use for: RAG status of workstreams (use status-roundup), logging
  risks (use risk-register-update), or composing a stakeholder update (use
  stakeholder-update). No external project-tool connector — relies on the
  host surfaces only.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Milestone Tracker

Compares current milestone dates to the baseline plan and categorises each
one, showing the slip/lead delta and a cause for anything off track.

## When NOT to Use

- Workstream RAG roll-up → `status-roundup`
- Risk log edits → `risk-register-update`
- Exec / team narrative → `stakeholder-update`

## Core Concepts

**Baseline vs. current** — the baseline is the originally committed date;
the current date is the latest forecast or actual. The **delta** is
current minus baseline, expressed in days (negative = ahead, positive =
slipped).

**Categories:**
- **Done** — milestone completed (actual date recorded).
- **On Track** — current date ≤ baseline, not yet complete.
- **At Risk** — current date trending past baseline, or a blocker
  threatens it, but not yet confirmed late.
- **Slipped** — current date is confirmed later than baseline.

## Workflow

1. **Locate the baseline plan** — the file, message, or table the user
   points at. If no baseline is available, say so and ask for it; do not
   treat the current date as its own baseline.
2. **Gather current dates** from status updates, the plan file, or chat.
3. **Compute the delta** for each milestone (current − baseline, in days).
4. **Categorise** each milestone using the rules above.
5. **Add a one-line cause** for every milestone that is At Risk or Slipped
   (drawn from the source update, not inferred).

## Output Format

A milestone status list, one line per milestone:

| Milestone | Baseline | Current | Delta | Status | Cause (if off track) |
|---|---|---|---|---|---|
| <name> | <date> | <date> | <+/−N days> | On Track / At Risk / Slipped / Done | <one line or —> |

Summarise underneath: counts per category (e.g. "3 On Track, 1 At Risk,
1 Slipped, 2 Done").

## Confirmation Gates

- If the baseline cannot be found, stop and ask for it — a tracker without
  a baseline is meaningless.
- Never label a milestone Slipped without a sourced current date.

## Errors

- Missing baseline date for one milestone → mark its delta as
  `[no baseline]` and exclude it from slip counts.
- Date format ambiguity → mirror the format used in the source plan.
