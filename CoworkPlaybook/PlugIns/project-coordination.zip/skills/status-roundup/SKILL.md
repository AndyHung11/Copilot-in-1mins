---
name: status-roundup
description: |
  Rolls up written status updates from workstream owners into a single
  Red/Amber/Green (RAG) summary table. Gathers updates from owner emails,
  Teams channel posts, and shared documents, then produces one row per
  workstream with status colour, owner, a one-line update, and blockers.
  Preserves the owner's original phrasing wherever they cited specific
  numbers or dates — never paraphrases a metric.

  Use when the user says "roll up status", "weekly project status",
  "status roundup", "pull together the workstream updates", or
  "give me a RAG summary".

  Do NOT use for: drafting an outbound stakeholder message (use
  stakeholder-update), tracking milestone dates against a baseline (use
  milestone-tracker), or editing the risk log (use risk-register-update).
  Relies only on the host's existing email, chat, and file surfaces — no
  external connectors.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Status Roundup

Aggregates written status updates from multiple workstream owners into a
single RAG (Red / Amber / Green) summary table.

## When NOT to Use

- Drafting an outbound message for execs or the team → `stakeholder-update`
- Checking milestone dates vs. the baseline plan → `milestone-tracker`
- Adding or changing a risk entry → `risk-register-update`

## Core Concepts

**RAG status** — each workstream is classified:
- **Green** — on track, no material blockers.
- **Amber** — at risk; a blocker or slip is emerging but recoverable.
- **Red** — off track; a blocker needs escalation or a date will miss.

**Source fidelity** — when an owner writes a specific number, percentage,
or date ("82% of test cases pass", "demo on June 12"), carry that phrasing
verbatim into the one-line update. Do not round, restate, or infer.

## Workflow

1. **Identify the workstreams and owners.** If the user names them, use
   that list. Otherwise ask once for the workstream/owner list, or infer
   from a project file the user points at.
2. **Gather updates in parallel** from the host surfaces:
   - Email: search each owner's recent messages for status language.
   - Teams: scan the relevant project channel(s) for status posts.
   - Files: read any shared status doc the user references.
3. **Classify each workstream** Green / Amber / Red based on the owner's
   own words. If an owner gave no update, mark the status **Grey — no
   update** rather than guessing.
4. **Extract one blocker line** per workstream (or "None").
5. **Preserve verbatim metrics** in the one-line update.

## Output Format

A single RAG summary table:

| Workstream | Status | Owner | One-line update | Blockers |
|---|---|---|---|---|
| <name> | 🟢/🟡/🔴/⚪ | <owner> | <verbatim-preserving summary> | <blocker or None> |

Below the table, list any workstreams with **no update received** so the
user knows where coverage is missing.

## Confirmation Gates

- If owners/workstreams are unknown and cannot be inferred, ask once
  before searching.
- Never invent a status for a workstream with no source update — mark it
  Grey / no update.

## Errors

- No updates found for an owner → mark Grey, note the gap in the output.
- Conflicting updates (two posts disagree) → surface both and flag the
  conflict rather than picking one.
