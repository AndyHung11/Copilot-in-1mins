---
name: faq-builder
description: |
  Turns a question and its answer into a polished FAQ block written for someone who
  wasn't in the original conversation. Rewrites the answer to stand on its own, adds a
  one-line short answer, and suggests 2–3 related questions the reader is likely to ask
  next. Produces paste-ready Markdown: Question / Short Answer / Detail / See Also.

  Trigger phrases: "add this to the FAQ", "FAQ entry for", "make an FAQ from this",
  "turn this into an FAQ", "write a FAQ answer", "document this question and answer".

  Do NOT use for: glossary term definitions (use glossary-entry); restructuring meeting
  notes (use meeting-notes-to-wiki); answering a question you don't have an answer for
  (this reshapes a provided answer, it does not research one). Only reshapes a Q&A the
  user supplies.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# FAQ Builder

Rewrite a question and answer into a clean, self-contained FAQ entry that helps a
reader who has none of the original context.

## When NOT to Use

- The user wants a term defined, not a question answered — use glossary-entry.
- The user is asking you to research or invent an answer — this skill reshapes an
  answer the user already has; it does not source new facts.
- The answer depends on private context the reader won't have and the user can't
  share — flag that the entry will be incomplete.

## Core Concepts

The reader of an FAQ arrives **cold**: no shared meeting, no thread, no assumed
jargon. A good entry therefore (1) leads with a one-line short answer for skimmers,
(2) expands into a self-contained Detail section that resolves pronouns and spells out
acronyms on first use, and (3) anticipates the next 2–3 questions so the reader doesn't
have to come back. Rewrite — don't paste the raw chat answer.

## Workflow

1. **Capture the Question.** Phrase it as a clean, standalone question. Strip
   conversational lead-ins ("hey quick one —").
2. **Write a Short Answer.** One sentence that resolves the question for a skimmer.
3. **Expand the Detail.** Rewrite the provided answer for a cold reader: resolve "it",
   "that", "we"; expand acronyms on first mention; remove references to "as we
   discussed" or "like I said in the call."
4. **Anticipate See Also.** Suggest 2–3 related questions the reader is likely to ask
   next, given the topic. Phrase them as questions.
5. **Assemble** the block in the output format and present it in a Markdown code block.

## Output Format

```markdown
### <Question, phrased as a standalone question>

**Short answer:** <one sentence>

**Detail:**
<self-contained explanation, 1–3 short paragraphs, acronyms expanded on first use>

**See also:**
- <related question 1>
- <related question 2>
- <related question 3>
```

## Confirmation Gates

- If the provided answer assumes context the reader won't have (an internal tool, a
  prior decision), make it explicit in the Detail or flag that the user should add it.
- If the See Also questions would require facts you don't have, suggest the questions
  but don't fabricate answers to them.

## Errors

- **Answer is too terse to expand** → write the best Detail you can and ask the user
  to add the missing specifics, marking gaps as `[add detail]`.
- **No clear question provided, only an answer** → infer the question, show it, and ask
  the user to confirm the phrasing.
- **Never invent facts** to flesh out the answer or the related questions.
