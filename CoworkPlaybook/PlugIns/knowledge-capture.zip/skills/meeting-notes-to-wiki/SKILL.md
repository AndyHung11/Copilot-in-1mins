---
name: meeting-notes-to-wiki
description: |
  Restructures a meeting transcript or raw notes into a clean, paste-ready wiki page.
  Extracts and organizes Topic, Attendees, Key Points, Decisions, Action Items, and
  Open Questions into consistent Markdown that drops straight into Loop, Confluence,
  or SharePoint.

  Trigger phrases: "turn these notes into a wiki page", "structure my meeting notes",
  "make a wiki page from this transcript", "clean up my meeting notes", "write this
  meeting up", "format these notes for the team wiki".

  Do NOT use for: live meeting transcription or recording (no audio capture here —
  paste the text); summarizing a meeting you did not attend without notes; pulling a
  transcript from a calendar event (use the meeting tools for that). This skill only
  reshapes content the user provides in the conversation.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Meeting Notes to Wiki

Turn messy meeting notes or a transcript into a structured wiki page a teammate
who wasn't there can read and act on.

## When NOT to Use

- The user wants live transcription or to capture audio — this skill only works on
  text the user pastes or points to.
- The user wants a one-line summary, not a structured page — just summarize inline.
- The source is a calendar/online-meeting transcript that hasn't been fetched yet —
  retrieve it first, then feed the text here.

## Core Concepts

A good wiki page is **self-contained**: someone who skipped the meeting should
understand what was discussed, what was decided, and what they owe. Six sections
carry that load: Topic, Attendees, Key Points, Decisions, Action Items, Open
Questions. Decisions and actions are the high-value content — never bury them.

## Workflow

1. **Read the input.** Accept a transcript, bullet dump, or freeform notes. If the
   user references an uploaded file, read it first.
2. **Extract a Topic.** Infer a short, descriptive title from the content. If a date
   is present, keep it.
3. **Identify Attendees.** Pull named participants. If none are stated, omit the line
   rather than inventing names.
4. **Distill Key Points.** Group related discussion into 3–8 concise bullets. Merge
   duplicates; drop filler.
5. **Separate Decisions from discussion.** A decision is a settled choice ("we will
   use X"). List each as its own bullet.
6. **Capture Action Items.** For each, record the owner and, if stated, the due date.
   Format: `- [ ] <action> — <owner> (<due>)`. If no owner is given, write
   `— owner: TBD`. Never assign an owner who wasn't named.
7. **List Open Questions.** Anything unresolved, parked, or flagged for follow-up.
8. **Assemble** the page in the output format below and present it in a Markdown code
   block so it copies cleanly.

## Output Format

```markdown
# <Topic>

**Date:** <date if known>
**Attendees:** <comma-separated names>

## Key Points
- <point>
- <point>

## Decisions
- <decision>

## Action Items
- [ ] <action> — <owner> (<due>)

## Open Questions
- <question>
```

Omit any section that genuinely has no content rather than padding it. If a section
is empty because the input didn't cover it, note `_None captured_` so the reader
knows it was considered, not forgotten.

## Confirmation Gates

- If the input is ambiguous about who owns an action, mark it `owner: TBD` — do not
  guess.
- If the notes are too sparse to fill most sections, say so and ask the user for the
  missing context rather than fabricating.

## Errors

- **No clear decisions or actions in the source** → produce the page with those
  sections marked `_None captured_` and tell the user.
- **Input is a file that can't be read** → ask the user to paste the text directly.
- **Never invent attendees, decisions, owners, or dates** that aren't in the source.
