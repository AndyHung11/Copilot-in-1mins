---
name: glossary-entry
description: |
  Turns a term and its local meaning into a clean glossary entry. Produces a crisp
  1–2 sentence definition, a concrete example of how the term is used in context, and
  a References section when the user provides links or sources. Paste-ready Markdown:
  Term / Definition / Example / References.

  Trigger phrases: "define [term] for the glossary", "add [term] to the glossary",
  "write a glossary entry for", "what's our definition of", "document this term",
  "glossary entry for [term]".

  Do NOT use for: answering a how-to question (use faq-builder); general dictionary
  definitions divorced from the team's usage (this captures the LOCAL meaning the user
  gives); restructuring notes (use meeting-notes-to-wiki). Only reshapes a term and
  meaning the user supplies.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Glossary Entry

Capture a team's shared vocabulary: a precise definition plus a concrete example so the
term means the same thing to everyone.

## When NOT to Use

- The user wants a generic dictionary definition — this skill captures the *local*,
  team-specific meaning the user provides, which often differs from the public one.
- The user is really asking a how-to or conceptual question — use faq-builder.
- No actual meaning is supplied and the term is genuinely ambiguous — ask before
  inventing a definition.

## Core Concepts

A glossary exists to **kill ambiguity**. The same word ("environment", "ready",
"customer") often means different things across teams. A strong entry pins down the
local meaning in 1–2 sentences and then anchors it with a concrete example of the term
in use — the example is what prevents drift. References let a reader go deeper.

## Workflow

1. **Identify the Term.** Capitalize as the team writes it; preserve casing for
   acronyms (e.g., "TUB", "CSA").
2. **Write the Definition.** 1–2 sentences, precise, in the team's local sense. Avoid
   circular definitions (don't use the term to define itself).
3. **Add an Example.** A concrete sentence or short scenario showing the term used in
   context. If the user gave one, refine it; if not, construct a plausible one and mark
   it clearly so the user can replace it.
4. **Collect References.** Only if the user provides links, doc names, or sources. Do
   not invent URLs. Omit the section if none are given.
5. **Note synonyms / "not to be confused with"** (optional) if the user flags a common
   mix-up.
6. **Assemble** the entry in the output format and present it in a Markdown code block.

## Output Format

```markdown
### <Term>

**Definition:** <1–2 sentence local definition>

**Example:** <concrete usage in context>

**References:**
- <link or source>
```

Omit **References** entirely when the user supplies none — do not leave an empty
heading or a fabricated link.

## Confirmation Gates

- If you had to construct the Example yourself, mark it (e.g., `<!-- example inferred
  — please verify -->`) so the user knows to confirm it reflects real usage.
- If the term has a well-known public meaning that differs from the local one, capture
  the local meaning the user gave and optionally note the contrast.

## Errors

- **Term supplied with no meaning** → ask the user for the local definition rather than
  defaulting to a dictionary entry.
- **User provides a source name but no link** → list the source by name under
  References; never fabricate a URL.
- **Never invent references** or stretch a one-word hint into a confident definition.
