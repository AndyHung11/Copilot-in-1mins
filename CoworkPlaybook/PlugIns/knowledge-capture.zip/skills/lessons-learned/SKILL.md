---
name: lessons-learned
description: |
  Turns a short story about something the team tried into a structured retro entry.
  Takes a "we tried X, Y happened, here's what we'd change" narrative and reshapes it
  into Context / What Happened / Lesson / Recommendation — consistent, paste-ready
  Markdown for the team's lessons-learned log or retro doc.

  Trigger phrases: "log a lesson learned", "add to the retro", "capture this lesson",
  "write up a retro entry", "record what we learned", "add this to our lessons log".

  Do NOT use for: evaluating or blaming individuals (keep it about the work, not the
  people); full post-incident/RCA reports with timelines and severity (this is a
  lightweight retro entry, not an incident review); summarizing a meeting (use
  meeting-notes-to-wiki). This skill only reshapes a short narrative the user provides.
license: MIT
metadata:
  author: Michal Slowikowski
  version: "1.0"
---

# Lessons Learned

Convert a quick war story into a durable, blameless retro entry the team can learn
from later.

## When NOT to Use

- The user wants a formal incident review / RCA with timeline, impact, and severity —
  that's a heavier artifact.
- The narrative singles out a person's performance — reframe around the decision or
  process, never the individual.
- There's no actual outcome to learn from yet (the work is still in progress).

## Core Concepts

A useful lesson is **transferable**: someone facing a similar situation next quarter
should be able to act differently because of it. Four parts make it transferable —
Context (the situation and constraints), What Happened (the outcome, good or bad),
Lesson (the generalizable insight), and Recommendation (what to do next time).
Keep it blameless: describe choices and conditions, not people.

## Workflow

1. **Read the story.** Accept a short narrative — typically "we tried X, Y happened,
   here's what we'd change."
2. **Extract Context.** The situation, goal, and any constraints that shaped the
   decision. Keep it to 1–3 sentences.
3. **Extract What Happened.** The actual outcome — what worked, what broke, what
   surprised the team. State it factually.
4. **Derive the Lesson.** Generalize past this one instance into a transferable
   insight. One or two sentences.
5. **Write a Recommendation.** A concrete, actionable next-time guidance. Prefer an
   imperative ("Spike the integration before committing to the sprint scope").
6. **Tag (optional).** If the user mentions a project, area, or theme, add a short
   tag line so the log is filterable.
7. **Assemble** the entry in the output format and present it in a Markdown code block
   ready to append to the log.

## Output Format

```markdown
### <Short lesson title> — <date>

**Context:** <situation, goal, constraints>

**What Happened:** <the outcome, stated factually>

**Lesson:** <the transferable insight>

**Recommendation:** <concrete next-time guidance>

_Tags: <project / area / theme>_
```

## Confirmation Gates

- If the story implies fault on a named person, rewrite around the decision or
  condition and keep the entry blameless.
- If the "what we'd change" part is missing, derive a reasonable recommendation from
  the outcome and flag that you inferred it, so the user can adjust.

## Errors

- **Story has an outcome but no clear lesson** → propose a candidate Lesson and
  Recommendation and ask the user to confirm.
- **Input is too vague to structure** → ask one clarifying question (what was the
  goal? what changed?) rather than guessing.
- **Never attribute blame to an individual** or invent details not in the narrative.
